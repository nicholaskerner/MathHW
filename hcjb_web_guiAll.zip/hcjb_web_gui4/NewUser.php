<?php 

session_start();
	include('config.php');
	
	$dbhandle = mysql_connect($hostname, $username, $password)
			or die("Unable to connect to MySQL");
			
	mysql_select_db($databaseName,$dbhandle);
	$numUser = mysql_query("SELECT COUNT(*) FROM UserInfo");
	$row = mysql_fetch_array($numUser);
	
	$newUserID=$row["COUNT(*)"]+1;
	$name=$_POST[username];
	$password=$_POST[password];
	$passwordHash=hash('whirlpool', $password);
	$UserType=$_POST['userType'];
	$email=$_POST[email];
	$sql="INSERT INTO  UserInfo (
	`Username` ,
	`PasswordHashed` ,
	`UserType` ,
	`AutoSaveID` ,
	`UserID` ,
	`email` ,
	`ViewType`
	)
	VALUES (
	'$name' ,  '$passwordHash',  '$UserType',  '0',  '$newUserID',  '$email', 'test'
	)
	";
	mysql_query($sql,$dbhandle);
	echo "$newUserID $name $password ";
	mysql_close($con);
	$_SESSION['Action']="Create";
	header("Location: ActionComplete.php");
?>