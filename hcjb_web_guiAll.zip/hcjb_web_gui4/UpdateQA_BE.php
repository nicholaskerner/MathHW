<?php //This function allows the user to update their password

session_start();
	include('config.php');
	
	$dbhandle = mysql_connect($hostname, $username, $password)
			or die("Unable to connect to MySQL");
			
	mysql_select_db($databaseName,$dbhandle);

	$userID=$_SESSION['UserID'];
	$question=$_POST['question'];
	$answer=$_POST['answer'];
	$answerHash=hash('whirlpool', $answer);
	mysql_query("UPDATE UserInfo SET SecretQuestion='$question', SecretAnswer='$answerHash', HasSecretQA='1' WHERE UserID='$userID'");
	mysql_close($dbhandle);
	$_SESSION['Action']="QA";
	header("Location: ActionComplete.php");
	
?>	