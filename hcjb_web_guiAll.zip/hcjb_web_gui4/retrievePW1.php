<?php //This function allows the user to update their password

session_start();
	include('config.php');
	
	$dbhandle = mysql_connect($hostname, $username, $password)
			or die("Unable to connect to MySQL");
			
	mysql_select_db($databaseName,$dbhandle);
	$myname=$_POST['username'];
	$result= mysql_query("SELECT * FROM UserInfo WHERE Username='$myname'");
	$row = mysql_fetch_array($result);
	$UserNum=$row['UserID'];
	$Question=$row['SecretQuestion'];
		
	if($UserNum==null){
		$_SESSION['ErrorRPW1']=1;
		header("Location: ForgotPW.php");		
		}
	else{
		if($Question=='')
		{	echo "You do not have a secret question and answer set. Please contact an administrator to reset your password<br> <a href=\"Index.php\">Return to log in</a></p>";
		}
		else {
		$_SESSION['UserID']=$UserNum;
		$_SESSION['ErrorRPW1']=0;
		echo $_SESSION['UserID'];
		header("Location: ForgotPWQuestion.php");
		}
		
		
		}
?>	