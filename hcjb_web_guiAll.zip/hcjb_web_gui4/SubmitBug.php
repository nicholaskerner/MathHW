<?php //This function allows the user to submit bugs to our database

session_start();
	include('config.php');
	
	$dbhandle = mysql_connect($hostname, $username, $password)
			or die("Unable to connect to MySQL");
			
	mysql_select_db($databaseName,$dbhandle);
	
	$subject=$_SESSION['Subject'];
	$description:=$_POST['Description:'];
	
	$sql="INSERT INTO  Bugs (
	`Subject` ,
	`Description` 
	)
	VALUES (
	'$subject' ,  '$description'
	)";
	mysql_query($sql,$dbhandle);
	mysql_close($dbhandle);
	echo "$userID  $password" ;
	$_SESSION['Action']="PasswordChange1";
	header("Location: ActionComplete.php");
	
?>	
	
	