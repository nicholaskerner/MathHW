<?php
session_start();
$action=$_SESSION['Action'];

if($action=="0")
{	echo "You have reached this page in error. Click return to be redirected<br>";
	echo "<a href=\"Index.php\">Return</a></p>";
}
else if($action=="Create")
{
	echo "User Sucesfully Created. Click Return to go back to the file page<br>";
	echo "<a href=\"file.php\">Return</a></p>";
}
else if($action=="PasswordChange1")
{
	echo "Password sucessfully changed. Click Return to go back to the file page <br>";
	echo "<a href=\"file.php\">Return</a></p>";
}
else if($action=="QA")
{
	echo "Secret Question and Answer sucessfully changed. Click Return to go back to the file page<br>";
	echo "<a href=\"file.php\">Return</a></p>";
}
else if($action=="ViewChange")
{
	echo "View Mode sucessfully changed. Click Return to go back to the file page<br>";
	echo "<a href=\"file.php\">Return</a></p>";
}
else if($action=="PasswordChange2")
{
	echo "Password sucessfully reset. Click Return to go back to the login page<br>";
	echo "<a href=\"Index.php\">Return</a></p>";
}
else
{	echo "You have reached this page in error. Click return to be redirected<br>";
	echo "<a href=\"Index.php\">Return</a></p>";
}
$_SESSION['Action']="0";
?>