<?php //This function allows the user to update their view

session_start();
	include('config.php');
	
	$dbhandle = mysql_connect($hostname, $username, $password)
			or die("Unable to connect to MySQL");
			
	mysql_select_db($databaseName,$dbhandle);

	$userID=$_SESSION['UserID'];
	$mode=$_POST['viewType'];
	
	mysql_query("UPDATE UserInfo SET ViewType='$mode' WHERE UserID='$userID'");
	mysql_close($dbhandle);
	echo $userID;
	echo $mode;
	$_SESSION['Action']="ViewChange";
	header("Location: ActionComplete.php");
	
?>	