

function currentErrors(){
	this.hardErrorList = new Array();
	this.softErrorList = new Array();
	this.hardErrorList.length = 0;
	this.softErrorList.length = 0;
	
	//clears the errors
	this.clearErrorList = function(){ 
		this.hardErrorList.length = 0;
		this.softErrorList.length = 0;
	};
	
	//adds errors to the list
	this.addHardError = function(link, discription){ 
		var lengthOf = this.hardErrorList.length;
		this.hardErrorList[lengthOf] = [link, discription];
		this.updateHUD();
	};
	this.addSoftError = function(link, discription){ 
		var lengthOf = this.softErrorList.length;
		this.softErrorList[lengthOf] = [link, discription];
		this.updateHUD();
	};
	this.updateHUD = function(){ 
		var printout = "";
		if(this.hardErrorList.length != 0){
			printout += "<strong> Conflict Errors:</strong><br>";
			printout += "<ulclass=\"text-warning\">";
			for(var i=0; i< this.hardErrorList.length; i++){
				if(typeof(this.hardErrorList[i][0]) ==="number"){
					printout+= "<li><a href=\"#\" onclick=\"change("+this.hardErrorList[i][0]+")\">"+this.hardErrorList[i][1]+"</a></li>";
				}
				else{
					printout+= "<li><a href=\"#\" onclick=\"change('"+this.hardErrorList[i][0]+"')\">"+this.hardErrorList[i][1]+"</a></li>";
				}
			}
			printout += "</ul>";
		}
		if(this.softErrorList.length != 0){
			printout+= "<strong> Select Errors:</strong><br>";
			 printout += "<ulclass=\"text-warning\">";
			for(var i=0; i< this.softErrorList.length; i++){
				if(typeof(this.softErrorList[i][0]) ==="number"){
					printout+= "<li><a href=\"#\" onclick=\"change("+this.softErrorList[i][0]+")\">"+this.softErrorList[i][1]+" value not selected</a></li>";
				}
				else{
					printout+= "<li><a href=\"#\" onclick=\"change('"+this.softErrorList[i][0]+"')\">"+this.softErrorList[i][1]+" value not selected</a></li>";
				}
			}
		
		
		}

		document.getElementById("ErrorListing").innerHTML = printout;
		$('#collapseThree2').collapse('show');
	};
	
	this.isEmpty = function(){
		if(this.hardErrorList.length  != 0 || this.softErrorList.length != 0){
			return false;
		}
		else{
			this.updateHUD();
			return true;
		}
	
	};
	
	



}