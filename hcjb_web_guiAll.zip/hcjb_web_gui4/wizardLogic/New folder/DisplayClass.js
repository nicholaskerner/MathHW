
function Display(){
	this.VUMeter;
	this.setVUMeter = function(temp){ 
		if(temp == 0 || temp == 1 || temp == null){
			this.VUMeter = temp;
		}
		else{
			throw "Invalid value for VUMeter";
		}
	
	};
	
	this.Timing;
	this.setTiming = function(temp){ 
		if(temp == 0 || temp == 1 || temp == null){
			this.Timing = temp;
		}
		else{
			throw "Invalid value for Timing";
		}
	
	};
	
	this.Clocktime;
	this.setClocktime = function(temp){ 
		if(temp == 0 || temp == 1 || temp == null){
			this.Clocktime = temp;
		}
		else{
			throw "Invalid value for Clocktime";
		}
	
	};
	
	



}














