function printAudioService(serviceNum){

if(serviceNum == 0)
	var collapseOne = "collapseOne";
	var S0 = "S0";
	var serviceLabel = currentINI.S0ServiceLabel;	
	var serviceIdentifer =currentINI.S0ServiceID;
		serviceIdentifer = serviceIdentifer.toString(16);
	var languageCode = currentINI.S0LanguageCode;	
	var countryCode = currentINI.S0CountryCode;
	var ServiceDesc = currentINI.S0ServiceDesc;
	var ServiceSource = currentINI.S0Source;
	var AudioFileName = currentINI.S0AudioFileName;
	//creates the composite AudioSettings variable
	var AudioSettingsVar = currentINI.S0AudioCodec.toString();
		AudioSettingsVar = AudioSettingsVar + currentINI.S0SBRFlag.toString();
		AudioSettingsVar = AudioSettingsVar + currentINI.S0AudioMode.toString();
		AudioSettingsVar = AudioSettingsVar + currentINI.S0AudioSamplingRate.toString();
	var serviceBandwidth = currentINI.S0DataLengthB;
	var TextFlag = currentINI.S0TextFlag;
}
else if(serviceNum == 1)
	var collapseOne = "collapseTwo";
	var S0 = "S1";
	var serviceLabel = currentINI.S1ServiceLabel;	
	var serviceIdentifer =currentINI.S1ServiceID;
		serviceIdentifer = serviceIdentifer.toString(16);
	var languageCode = currentINI.S1LanguageCode;	
	var countryCode = currentINI.S1CountryCode;
	var ServiceDesc = currentINI.S1ServiceDesc;
	var ServiceSource = currentINI.S1Source;
	var AudioFileName = currentINI.S1AudioFileName;
	//creates the composite AudioSettings variable
	var AudioSettingsVar = currentINI.S1AudioCodec.toString();
		AudioSettingsVar = AudioSettingsVar + currentINI.S1SBRFlag.toString();
		AudioSettingsVar = AudioSettingsVar + currentINI.S1AudioMode.toString();
		AudioSettingsVar = AudioSettingsVar + currentINI.S1AudioSamplingRate.toString();
	var serviceBandwidth = currentINI.S1DataLengthB;
	var TextFlag = currentINI.S1TextFlag;
}
else if(serviceNum == 2)
	var collapseOne = "collapseThree";
	var S0 = "S2";
	var serviceLabel = currentINI.S2ServiceLabel;	
	var serviceIdentifer =currentINI.S2ServiceID;
		serviceIdentifer = serviceIdentifer.toString(16);
	var languageCode = currentINI.S2LanguageCode;	
	var countryCode = currentINI.S2CountryCode;
	var ServiceDesc = currentINI.S2ServiceDesc;
	var ServiceSource = currentINI.S2Source;
	var AudioFileName = currentINI.S2AudioFileName;
	//creates the composite AudioSettings variable
	var AudioSettingsVar = currentINI.S2AudioCodec.toString();
		AudioSettingsVar = AudioSettingsVar + currentINI.S2SBRFlag.toString();
		AudioSettingsVar = AudioSettingsVar + currentINI.S2AudioMode.toString();
		AudioSettingsVar = AudioSettingsVar + currentINI.S2AudioSamplingRate.toString();
	var serviceBandwidth = currentINI.S2DataLengthB;
	var TextFlag = currentINI.S2TextFlag;
}
else if(serviceNum == 3)
	var collapseOne = "collapseFour";
	var S0 = "S3";
	var serviceLabel = currentINI.S3ServiceLabel;	
	var serviceIdentifer =currentINI.S3ServiceID;
		serviceIdentifer = serviceIdentifer.toString(16);
	var languageCode = currentINI.S3LanguageCode;	
	var countryCode = currentINI.S3CountryCode;
	var ServiceDesc = currentINI.S3ServiceDesc;
	var ServiceSource = currentINI.S3Source;
	var AudioFileName = currentINI.S3AudioFileName;
	//creates the composite AudioSettings variable
	var AudioSettingsVar = currentINI.S3AudioCodec.toString();
		AudioSettingsVar = AudioSettingsVar + currentINI.S3SBRFlag.toString();
		AudioSettingsVar = AudioSettingsVar + currentINI.S3AudioMode.toString();
		AudioSettingsVar = AudioSettingsVar + currentINI.S3AudioSamplingRate.toString();
	var serviceBandwidth = currentINI.S3DataLengthB;
	var TextFlag = currentINI.S3TextFlag;
}		

		
services+=						"<div class=\"accordion-heading\">";

services+=							"<a class=\"accordion-toggle\" data-toggle=\"collapse\" data-parent=\"#accordion4\" href=\"#"+collapseOne+"4\">Audio Service</a>";
services+=							"</div>";
services+=									"<div id=\""+collapseOne+"4\" class=\"accordion-body collapse in\">";
services+=									  "<div class=\"accordion-inner\">";
services+=									  "<div class=\"tabbable tabs-left\">";
services+=									"<ul class=\"nav nav-tabs\" id=\"service"+S0+"Tab\">";
services+=									  "<li class=\"active\"><a href=\"#"+S0+"ServiceLabelDiv\" data-toggle=\"tab\"><i class=\"icon-tag\"></i> Service Label</a></li>";
services+=									  "<li><a href=\"#"+S0+"ServiceIndentifierDiv\" data-toggle=\"tab\"><i class=\"icon-eye-open\"></i> Service Identifier</a></li>";
services+=									  "<li><a href=\"#"+S0+"LanguageDiv\" data-toggle=\"tab\"><i class=\"icon-group\"></i> Language</a></li>";
services+=									  "<li><a href=\"#"+S0+"CountryCodeDiv\" data-toggle=\"tab\"><i class=\"icon-globe\"></i> Country Code</a></li>";
services+=									  "<li><a href=\"#"+S0+"ServiceDescriptorDiv\" data-toggle=\"tab\"><i class=\"icon-pencil\"></i> Service Descriptor</a></li>";
services+=									  "<li><a href=\"#"+S0+"SourceDiv\" data-toggle=\"tab\"><i class=\"icon-music\"></i> Source</a></li>";
services+=									  "<li><a href=\"#"+S0+"AudioSettingsDiv\" data-toggle=\"tab\"><i class=\"icon-wrench\"></i> Audio Settings</a></li>";
services+=									  "<li><a href=\"#"+S0+"textFlagDiv\" data-toggle=\"tab\"><i class=\"icon-mobile-phone\"></i> Text Messages</a></li>";
services+=									"</ul>";
			 
services+=								"<div class=\"tab-content\">";
		
services+=											  "<div class=\"tab-pane active\" id=\""+S0+"ServiceLabelDiv\">";
services+=												"<div class=\"span5 well well-small\">";
services+=													"<dl>";
services+=													  "<dt>Service Label</dt>";
services+=													  "<dd> The name you want displayed for this service. Maximum 16 letters or Characters. </dd>";
services+=													"</dl>";
services+=												"</div>";
services+=												"<div class=\"span5 offset1\" >";
services+=													"<div class=\"page-header\">";
services+=													"<h5>Service Label:</h5>";
services+=													"</div>";
services+=													"<div id=\""+S0+"ServiceLabelAlert\">";
services+=													"</div>";
services+=													  "<input type=\"text\" name=\""+S0+"ServiceLabel\" class=\"span11\"  placeholder=\""+serviceLabel+"\" id=\""+S0+"ServiceLabel\" onclick=\"logic(this.name, this.value)\">";
services+=												"</div>";	
services+=											  "</div>";

services+=											  "<div class=\"tab-pane\" id=\""+S0+"ServiceIndentifierDiv\">";
services+=												"<div class=\"span5 well well-small\">";
services+=													"<dl>";
services+=													  "<dt>Service Indentifier</dt>";
services+=													  "<dd> Unique ID, which is a whole number. </dd>";
services+=													"</dl>";
services+=												"</div>";
services+=												"<div class=\"span5 offset1\" >";
services+=													"<div class=\"page-header\">";
services+=													"<h5>Service Identifer:</h5>";
services+=													"</div>";
services+=													"<div id=\""+S0+"ServiceIDAlert\">";
services+=													"</div>";
services+=													  "<input type=\"text\" name=\""+S0+"ServiceIdentifer\" class=\"span11\" placeholder=\""+serviceIdentifer+"\" id=\""+S0+"ServiceID\" onclick=\"logic(this.name, this.value)\">";
services+=												"</div>";	
services+=											  "</div>";
 
services+=											  "<div class=\"tab-pane\" id=\""+S0+"LanguageDiv\">";
services+=												"<div class=\"span5 well well-small\">";
services+=													"<dl>";
services+=													  "<dt>Language</dt>";
services+=													  "<dd> Select the language the serivce is in. </dd>";
services+=													"</dl>";
services+=												"</div>";
services+=												"<div class=\"span5 offset1\" >";
services+=													"<div class=\"page-header\">";
services+=													"<h5>Language:</h5>";
services+=													"</div>";
services+=													"<div id=\""+S0+"LanguageAlert\">";
services+=													"</div>";
services+=													  "<select id=\""+S0+"Language\" name=\""+S0+"Language\" onclick=\"logic(this.name, this.value)\">";
																for(var i=0; i<languageCodesArray.length; i++){
																	if(languageCode == languageCodesArray[i][0]){
																		services+="<option value=\""+languageCodesArray[i][0]+"\" selected>"+languageCodesArray[i][1]+"</option>";
																	}
																	else{
																		services+="<option value=\""+languageCodesArray[i][0]+"\">"+languageCodesArray[i][1]+"</option>";
																	}
																
																}
services+=														"</select>"; 

services+=												"</div>";
services+=											  "</div>";
services+=											  "<div class=\"tab-pane\" id=\""+S0+"CountryCodeDiv\">";
services+=												"<div class=\"span5 well well-small\">";
services+=													"<dl>";
services+=													  "<dt>Country Code</dt>";
services+=													  "<dd> Select the Country Code for where your broadcast is. </dd>";
services+=													"</dl>";
services+=												"</div>";
services+=												"<div class=\"span5 offset1\" >";
services+=													"<div class=\"page-header\">";
services+=													"<h5>Country Code:</h5>";
services+=													"</div>";
services+=													"<div id=\""+S0+"CountrycodeAlert\">";
services+=													"</div>"
services+=													  "<select id=\""+S0+"CountryCode\" name=\""+S0+"CountryCode\" onclick=\"logic(this.name, this.value)\">";
															for(var i=0; i<countryCodeArray.length; i++){
																	if(countryCode == countryCodeArray[i][0]){
																		services+="<option value=\""+countryCodeArray[i][0]+"\" selected>"+countryCodeArray[i][1]+"</option>";
																	}
																	else{
																		services+="<option value=\""+countryCodeArray[i][0]+"\">"+countryCodeArray[i][1]+"</option>";
																	}
																
																}
services+=													  "</select>";
services+=												"</div>";	  
services+=											  "</div>";
services+=											  "<div class=\"tab-pane\" id=\""+S0+"ServiceDescriptorDiv\">";
services+=												"<div class=\"span5 well well-small\">";
services+=													"<dl>";
services+=													  "<dt>Service Descriptor</dt>";
services+=													  "<dd> Select the description that best describes your programing. </dd>";
services+=													"</dl>";
services+=												"</div>";
services+=												"<div class=\"span5 offset1\" >";
services+=													"<div class=\"page-header\">";
services+=													"<h5>Service Descriptor:</h5>";
services+=													"</div>";
services+=													"<div id=\""+S0+"ServiceDescriptorAlert\">";
services+=													"</div>";
services+=													  "<select id=\""+S0+"ServiceDesc\" name=\""+S0+"ServiceDesc\" onclick=\"logic(this.name, this.value)\">";
																for(var i=0; i<ServiceDescArray.length; i++){
																	if(ServiceDesc == ServiceDescArray[i][0]){
																		services+="<option value=\""+ServiceDescArray[i][0]+"\" selected>"+ServiceDescArray[i][1]+"</option>";
																	}
																	else{
																		services+="<option value=\""+ServiceDescArray[i][0]+"\">"+ServiceDescArray[i][1]+"</option>";
																	}
																
																}

services+=													  "</select>";
services+=												"</div>";
services+=											  "</div>";
services+=											  "<div class=\"tab-pane\" id=\""+S0+"SourceDiv\">";
services+=												"<div class=\"span5 well well-small\">";
services+=													"<dl>";
services+=													  "<dt>Source</dt>";
services+=													  "<dd> Location from which your audio is coming from. </dd>";
services+=													"</dl>";
services+=												"</div>";
services+=												"<div class=\"span5 offset1\" >";
services+=													"<div class=\"page-header\">";
services+=													"<h5>Source:</h5>";
services+=													"</div>";
services+=													"<div id=\""+S0+"SourceAlert\">";
services+=													"</div>";
services+=													"<label class=\"radio\" rel=\"tooltip\">";
services+=													 "<input type=\"radio\" name=\""+S0+"Source\" id=\""+S0+"Source2\" value=\"2\" onclick=\"logic(this.name, this.value)\"";

															if(ServiceSource == "2"){
																services+="checked>";
															}
															else{
																services+=">";
															}
services+=														"Wave File";
services+=													"</label>";
services+=													"<input type=\"text\" name=\""+S0+"AudioFilename\"  class=\"span11\" placeholder=\""+AudioFileName+"\" id=\""+S0+"AudioFilename\" onclick=\"logic(this.name, this.value)\">";
services+=													"<label class=\"radio\" rel=\"tooltip\">"
services+=													 "<input type=\"radio\" name=\""+S0+"Source\" id=\""+S0+"Source3\" value=\"3\" onclick=\"logic(this.name, this.value)\"";
															if(ServiceSource == "3"){
																services+="checked>";
															}
															else{
																services+=">";
															}
services+=														"Audio Input";
services+=													"</label>";
services+=													"<select id=\""+S0+"AudioFilenameLive\" name=\""+S0+"AudioFilename\" onclick=\"logic(this.name, this.value)\">";
															for(var i=0; i<liveAudioList.LiveAudioInputs.length; i++){
																	if(AudioFileName == liveAudioList.LiveAudioInputs[i].inputName){
																		services+="<option value=\""+liveAudioList.LiveAudioInputs[i].inputName+"\" selected>"+liveAudioList.LiveAudioInputs[i].inputName+"</option>";
																	}
																	else{
																		services+="<option value=\""+liveAudioList.LiveAudioInputs[i].inputName+"\">"+liveAudioList.LiveAudioInputs[i].inputName+"</option>";
																	}
																
																}	
												
services+=													"</select>";
services+=												"</div>";
services+=											  "</div>";
services+=											  "<div class=\"tab-pane\" id=\""+S0+"AudioSettingsDiv\">";
services+=												"<div class=\"span5 well well-small\">";
services+=													"<dl>";
services+=													  "<dt>Audio Settings</dt>";
services+=													  "<dd> Select the Audio Setting you want. </dd>";
services+=													"</dl>";
services+=												"</div>";
services+=												"<div class=\"span5 offset1\" >";
services+=													"<div class=\"page-header\">";
services+=													"<h5>Audio Setting:</h5>";
services+=													"</div>";
services+=													"<div id=\""+S0+"AudioSettingAlert\">";
services+=													"</div>"
services+=													  "<select id=\""+S0+"AudioSetting\" name=\"+"S0+"AudioSettings\" onclick=\"logic(this.name, this.value)\">";
															var audioSettingsArray = audioSettingsLogic(serviceBandwidth);
															for(var i = 0; i < audioSettingsArray.length; i++){
																if(audioSettingsArray[i][0] == AudioSettingsVar){
																	services+="<option value=\""+audioSettingsArray[i][0]+"\" selected>"+audioSettingsArray[i][1]+"</option>";
																}
																else{
																	services+="<option value=\""+audioSettingsArray[i][0]+"\">"+audioSettingsArray[i][1]+"</option>";
																}
															}

services+=													  "</select>";
services+=												"</div>";
services+=											  "</div>";
services+=											  "<div class=\"tab-pane\" id=\""+S0+"textFlagDiv\">";
services+=												"<div class=\"span5 well well-small\">";
services+=													"<dl>";
services+=													  "<dt>Text Message</dt>";
services+=													  "<dd> Selects if one wants text message with audio. </dd>";
services+=													"</dl>";
services+=												"</div>";
services+=												"<div class=\"span5 offset1\" >";
services+=													"<div class=\"page-header\">";
services+=													"<h5>Text Message:</h5>";
services+=													"</div>";
services+=													"<div id=\""+S0+"SourceAlert\">";
services+=													"</div>";
services+=													"<label class=\"radio\" rel=\"tooltip\">";
services+=													 "<input type=\"radio\" name=\""+S0+"TextFlag\" id=\""+S0+"TextFlag0\" value=\"0\" onclick=\"logic(this.name, this.value)\"";
															if(TextFlag == 0){
															services+= "checked>";
															}
															else{
															services+= ">";
															}
services+=														"Text message not included with audio stream";
services+=													"</label>";
												
services+=													"<label class=\"radio\" rel=\"tooltip\">";
services+=													 "<input type=\"radio\" name=\""+S0+"TextFlag\" id=\""+S0+"TextFlag1\" value=\"1\" onclick=\"logic(this.name, this.value)\"";
															if(TextFlag == 1){
															services+= "checked>";
															}
															else{
															services+= ">";
															}
services+=														"Text message included with audio stream";
services+=													"</label>";
										
services+=												"</div>";
services+=											  "</div>";
services+=											"</div>";
services+=									  "</div>";
services+=									  "</div>";
services+=									"</div>";
services+=								  "</div>";

