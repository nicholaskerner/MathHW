function Output(){
	this.IPEnabled;
	this.IPAddr;
	this.IPPort;
	this.IP_TCP_UDP;
	this.FFEnabled;
	this.FFFileName;
	this.PFTEnabled;
	this.PFTPayloadMtu;
	this.PFTProtection;
	this.PFTStrength;
	this.PFTTransportation;
	this.PFTSource;
	this.PFTDestination;

}