function Service(){
	this.Servicelabel;
	this.ServiceIdentifier;
	this.CASystemUsed;
	this.Language;
	this.LanguageCode;
	this.Countrycode;
	this.AudioDataFlag;
	this.ServiceDescriptor;
	this.StreamId;
	this.AudioCoding;
	this.SBRFlag;
	this.AudioMode;
	this.AudioSamplingRate;
	this.TextFlag;
	this.EnhancementFlag;
	this.Source;
	this.AudioFilename;
	this.RepeatAudio;
	this.CoderField;

}