function  INIFile(){
	this.transmission = new Transmission();
	
	this.Stream0 = new Stream();
	this.Stream1 = new Stream();
	this.Stream2 = new Stream();
	this.Stream3 = new Stream();
	
	this.Service0 = new Service();
	this.Service1 = new Service();
	this.Service2 = new Service();
	this.Service3 = new Service();
	
	this.Output = new Output();
	
	this.Display = new Display();
	
	
}