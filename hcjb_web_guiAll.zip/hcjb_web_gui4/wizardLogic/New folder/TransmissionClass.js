function Transmission(){
	this.ConfigurationDescription;
	this.Robustness;
	this.SpectrumOccupancy;
	this.InterleaverDepthFlag;
	this.MSCMode;
	this.SDCMode;
	this.BaseEnhancementFlag;
	this.ProtLevelForPartA;
	this.ProtLevelForPartB;
	this.ProtLevelForHierarchical;
	this.HierachicalBytes;
	this.AmDrm;
}