function Stream(){
	this.DataLengthForPartA;
	this.DataLengthForPartB;

}