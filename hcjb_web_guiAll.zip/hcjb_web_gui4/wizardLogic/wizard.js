
var ViewType;

function setViewtype(temp){
	ViewType= temp;
}



//handles navigation through the tabs
function change(tabNum){
	
	if(tabNum == 201){
		document.getElementById("previousBtn").className = "previous" ;
		document.getElementById("previousBtn").innerHTML= '<a href="#" onclick=\"change(107)\">&larr; Previous</a>';
		document.getElementById("nextBtn").className = "next" ;	
		document.getElementById("nextBtn").innerHTML= '<a href="#" onclick=\"change(301)\">Next &rarr;</a>';
		$('#myTab0 a[href="#tab201"]').tab('show');
		$('#myTab0 a[href="#tab2xx"]').tab('show');

	}	
	else if(tabNum == 301 || tabNum == 300){
		document.getElementById("previousBtn").className = "previous" ;
		document.getElementById("previousBtn").innerHTML= '<a href="#" onclick=\"change(201)\">&larr; Previous</a>';
		document.getElementById("nextBtn").className = "next" ;
		document.getElementById("nextBtn").innerHTML= '<a href="#" onclick=\"change(302)\">Next &rarr;</a>'; 
		$('#myTab0 a[href="#tab301"]').tab('show');
		$('#myTab0 a[href="#tab3xx"]').tab('show');
	}
	else if(tabNum == 303){
		document.getElementById("previousBtn").className = "previous" ;
		document.getElementById("previousBtn").innerHTML= '<a href="#" onclick=\"change(302)\">&larr; Previous</a>';
		document.getElementById("nextBtn").className = "next disabled" ;

		$('#myTab0 a[href="#tab303"]').tab('show');
		$('#myTab0 a[href="#tab4xx"]').tab('show');
	}
	else if(tabNum == 101){
		document.getElementById("previousBtn").className = "previous disabled" ;
		document.getElementById("nextBtn").innerHTML= '<a href="#" onclick=\"change(102)\">Next &rarr;</a>'; 
		document.getElementById("nextBtn").className = "next" ;	
		$('#myTab0 a[href="#tab101"]').tab('show');
		$('#myTab0 a[href="#tab1xx"]').tab('show');

	}	
	else if(tabNum == 107){
		document.getElementById("previousBtn").className = "previous" ;
		document.getElementById("previousBtn").innerHTML= '<a href="#" onclick=\"change(106)\">&larr; Previous</a>';
		
		document.getElementById("nextBtn").innerHTML= '<a href="#" onclick=\"change(201)\">Next &rarr;</a>'; 
		document.getElementById("nextBtn").className = "next" ;	
		$('#myTab0 a[href="#tab1xx"]').tab('show');
		$('#myTab0 a[href="#tab107"]').tab('show');
		
	}
	else if(typeof(tabNum) ==="number") {
		var less = tabNum-1;
		var more = tabNum+1;
		document.getElementById("previousBtn").className = "previous" ;
		document.getElementById("previousBtn").innerHTML= '<a href="#" onclick=\"change(' + less + ')\">&larr; Previous</a>';
		
		document.getElementById("nextBtn").innerHTML= '<a href="#" onclick=\"change(' + more + ')\">Next &rarr;</a>'; 
		document.getElementById("nextBtn").className = "next" ;	
	
		$('#myTab0 a[href=\"#tab'+ tabNum +'\"]').tab('show');
		$('#myTab0 a[href=\"#tab'+ tabNum +'\"]').tab('show');
	}
	else{
		document.getElementById("previousBtn").className = "previous" ;
		document.getElementById("previousBtn").innerHTML= '<a href="#" onclick=\"change(107)\">&larr; Previous</a>';
		document.getElementById("nextBtn").className = "next" ;
		document.getElementById("nextBtn").innerHTML= '<a href="#" onclick=\"change(301)\">Next &rarr;</a>'; 
		$('#myTab0 a[href="#tab2xx"]').tab('show');
		$('#myTab0 a[href=\"#'+ tabNum +'\"]').tab('show');
		
		if(tabNum.substring(0,2) == "S0"){
			$('#collapseOne4').collapse('show');
			$('#collapseTwo4').collapse('hide');
			$('#collapseThree4').collapse('hide');
			$('#collapseFour4').collapse('hide');
		}
		else if(tabNum.substring(0,2) == "S1"){
			$('#collapseOne4').collapse('hide');
			$('#collapseTwo4').collapse('show');
			$('#collapseThree4').collapse('hide');
			$('#collapseFour4').collapse('hide');
		}
		else if(tabNum.substring(0,2) == "S2"){
			$('#collapseOne4').collapse('hide');
			$('#collapseTwo4').collapse('hide');
			$('#collapseThree4').collapse('show');
			$('#collapseFour4').collapse('hide');
		}
		else if(tabNum.substring(0,2) == "S3"){
			$('#collapseOne4').collapse('hide');
			$('#collapseTwo4').collapse('hide');
			$('#collapseThree4').collapse('hide');
			$('#collapseFour4').collapse('show');
		}
	}
		
		
		

}

function logOut(){
	var pageName = location.pathname;
	$.post( pageName, { "signout": true} );
	window.location.reload();
}
function openAdminTools(){
	//$.post( "AdminOptions.php" );
	window.location = 'AdminOptions.php';
	//window.location.reload();
}
function openUserSettings(){
	//$.post( "AdminOptions.php" );
	window.location = 'UserOptions.php';
	//window.location.reload();
}



