

function loadAJAXObject(fileName){
	// var sendingData = {"FileID": fileName, "ToDo": "loadFile"};
	// sendingData = $.param(sendingData);
	//document.getElementById("testing").innerHTML = ""+sendingData+"";
	$.getJSON("wizardPHP/AJAXCalls.php", {"FileID": fileName, "ToDo": "loadFile"},
		function(data){
			currentFileID = fileName;
			setCurrentINI(data);
			loadLiveAudioObject();
			activateSummaryObject();
		}); 
}
function loadLiveAudioObject(){
	//document.getElementById("testing").innerHTML = ""+sendingData+"";
	$.getJSON("wizardPHP/AJAXCalls.php", {"ToDo": "liveAudio"},
		function(data){
		var tempList = new Array();
		
		for(var i=0; i<data.LiveAudioInputs.length; i++){
			tempList[i] = data.LiveAudioInputs[i].inputName;
		
		}	
			setLiveAudio(tempList);	
			checkAndLoadServices();
		}); 




}
function autoSaveObject(){
	currentINI.FileID = currentFileID;
	currentINI.ToDo = "autoSave";
	$.getJSON("wizardPHP/AJAXCalls.php",$.param(currentINI) ,
		function(data){
			document.getElementById("testing").innerHTML = "Data: "+data.Status+"";
		}); 
}

function saveObject(){
	currentINI.FileID = currentFileID;
	currentINI.ToDo = "save";
	$.getJSON("wizardPHP/AJAXCalls.php",$.param(currentINI) ,
		function(data){
			document.getElementById("testing").innerHTML = data;
			if(data.Status != "WroteFile"){
				document.getElementById("modalStorage").innerHTML = failedSaveModal;
				$('#failedSaveModal').modal('show');
			}
			
		}); 



}
function activateFileObject(){
	currentINI.FileID = currentFileID;
	currentINI.ToDo = "activate";
	$('#activateModal').modal('hide');
	$.getJSON("wizardPHP/AJAXCalls.php",$.param(currentINI) ,
		function(data){
			document.getElementById("testing").innerHTML = data;
			if(data.Status != "activated"){
				document.getElementById("modalStorage").innerHTML = failedActivateModal;
				$('#failedActivateModal').modal('show');
			}
			else{
				activeSummaryObject();
			}
		}); 


}


function activateSummaryObject(){
	
	$.getJSON("wizardPHP/AJAXCalls.php", {"FileID": 0, "ToDo": "loadActive"},
		function(data){
			if(ActiveSum.isEmpty() == true){
				ActiveSum.setActiveConfigSum(data);
				ActiveSum.displayActiveConfig();
			}
			ActiveSum.isUpToDate(data);
		}); 
}


