var currentINI;
var liveAudioList = new Array();
var currentErrors = new currentErrors();
var currentFileID;
var ActiveSum = new ActiveConfigSum();

//sets Main INI file object
function setCurrentINI(data){
	currentINI = data;
	//dealWithNewFile();
	currentINI.OldTotalDataLength = lookUpTotalDataLength();
}

//gets Main INI file object
function getCurrentINI(){
	return currentINI;
}

function setLiveAudio(data){
	liveAudioList = data;
}
//gets Main INI file object
function getLiveAudio(){
	return liveAudioList;
}


//this function is called by all html elements and is delgated off
function logic(name, value){
	
	
	//document.getElementById("testing").innerHTML = "name: "+name+" value: "+value+"";
	

	//updates value for Configuration Description
	if(name == "ConfigurationDescription"){
		currentINI.ConfigurationDesc = value;
	}
	//updates value for Spectrum Occ
	else if(name == "SO"){
		currentINI.SpectrumOcc = value;
	}
	//updates value for Robustness
	else if(name == "Robust"){
		currentINI.Robustness = value;
	}
	//updates value for Interleaver Depth
	else if(name == "Interleaver"){
		currentINI.InterleaverDepth = value;
	}
	//updates value for MSC Mode
	else if(name == "MSC"){
		if(currentINI.MSCMode == 1 || currentINI.MSCMode == 2){
			advancedSettingsNuke();
		}
		currentINI.MSCMode = value;
	}
	//updates value for SDC Mode
	else if(name == "SDC"){
		currentINI.SDCMode = value;
	}
	//updates Protection Levels
	else if(name == "ProtBInt"){
		if(currentINI.ProtAInt != 0){
			advancedSettingsNuke();
		}
		currentINI.ProtBInt = value;
	}
	//updates value for Service Label
	else if(name.substring(2,14) == "ServiceLabel"){
		if(name.substring(0,2) == "S0"){
			currentINI.S0ServiceLabel = value;
		}
		else if(name.substring(0,2) == "S1"){
			currentINI.S1ServiceLabel = value;
		}
		else if(name.substring(0,2) == "S2"){
			currentINI.S2ServiceLabel = value;
		}
		else if(name.substring(0,2) == "S3"){
			currentINI.S3ServiceLabel = value;
		}
	}
	//updates value for Service Identifier
	else if(name.substring(2,18) == "ServiceIdentifer"){
		if(name.substring(0,2) == "S0"){
			currentINI.S0ServiceID =  parseInt(value, 16);
		}
		else if(name.substring(0,2) == "S1"){
			currentINI.S1ServiceID = parseInt(value, 16);
		}
		else if(name.substring(0,2) == "S2"){
			currentINI.S2ServiceID = parseInt(value, 16);
		}
		else if(name.substring(0,2) == "S3"){
			currentINI.S3ServiceID = parseInt(value, 16);
		}	
	}
	//updates value for Language and Language Code
	else if(name.substring(2,10) == "Language"){
		if(name.substring(0,2) == "S0"){
		
			currentINI.S0LanguageCode = value;
			
			if(value == "ara"){
				currentINI.S0LanguageInt = "1";
			}
			else if(value == "ben"){
				currentINI.S0LanguageInt = "2";
			}
			else if(value == "chi"){
				currentINI.S0LanguageInt = "3";
			}
			else if(value == "dum"){
				currentINI.S0LanguageInt = "4";
			}
			else if(value == "eng"){
				currentINI.S0LanguageInt = "5";
			}
			else if(value == "fre"){
				currentINI.S0LanguageInt = "6";
			}
			else if(value == "ger"){
				currentINI.S0LanguageInt = "7";
			}
			else if(value == "hin"){
				currentINI.S0LanguageInt = "8";
			}
			else if(value == "jpn"){
				currentINI.S0LanguageInt = "9";
			}
			else if(value == "jav"){
				currentINI.S0LanguageInt = "10";
			}
			else if(value == "kor"){
				currentINI.S0LanguageInt = "11";
			}
			else if(value == "por"){
				currentINI.S0LanguageInt = "12";
			}
			else if(value == "rus"){
				currentINI.S0LanguageInt = "13";
			}
			else if(value == "spa"){
				currentINI.S0LanguageInt = "14";
			}
			else{
				currentINI.S0LanguageInt = "15";
			}
			
		}
		else if(name.substring(0,2) == "S1"){
			currentINI.S1LanguageCode = value;
			
			if(value == "ara"){
				currentINI.S1LanguageInt = "1";
			}
			else if(value == "ben"){
				currentINI.S1LanguageInt = "2";
			}
			else if(value == "chi"){
				currentINI.S1LanguageInt = "3";
			}
			else if(value == "dum"){
				currentINI.S1LanguageInt = "4";
			}
			else if(value == "eng"){
				currentINI.S1LanguageInt = "5";
			}
			else if(value == "fre"){
				currentINI.S1LanguageInt = "6";
			}
			else if(value == "ger"){
				currentINI.S1LanguageInt = "7";
			}
			else if(value == "hin"){
				currentINI.S1LanguageInt = "8";
			}
			else if(value == "jpn"){
				currentINI.S1LanguageInt = "9";
			}
			else if(value == "jav"){
				currentINI.S1LanguageInt = "10";
			}
			else if(value == "kor"){
				currentINI.S1LanguageInt = "11";
			}
			else if(value == "por"){
				currentINI.S1LanguageInt = "12";
			}
			else if(value == "rus"){
				currentINI.S1LanguageInt = "13";
			}
			else if(value == "spa"){
				currentINI.S1LanguageInt = "14";
			}
			else{
				currentINI.S1LanguageInt = "15";
			}
			
		}
		else if(name.substring(0,2) == "S2"){
			currentINI.S2LanguageCode = value;
			
			if(value == "ara"){
				currentINI.S2LanguageInt = "1";
			}
			else if(value == "ben"){
				currentINI.S2LanguageInt = "2";
			}
			else if(value == "chi"){
				currentINI.S2LanguageInt = "3";
			}
			else if(value == "dum"){
				currentINI.S2LanguageInt = "4";
			}
			else if(value == "eng"){
				currentINI.S2LanguageInt = "5";
			}
			else if(value == "fre"){
				currentINI.S2LanguageInt = "6";
			}
			else if(value == "ger"){
				currentINI.S2LanguageInt = "7";
			}
			else if(value == "hin"){
				currentINI.S2LanguageInt = "8";
			}
			else if(value == "jpn"){
				currentINI.S2LanguageInt = "9";
			}
			else if(value == "jav"){
				currentINI.S2LanguageInt = "10";
			}
			else if(value == "kor"){
				currentINI.S2LanguageInt = "11";
			}
			else if(value == "por"){
				currentINI.S2LanguageInt = "12";
			}
			else if(value == "rus"){
				currentINI.S2LanguageInt = "13";
			}
			else if(value == "spa"){
				currentINI.S2LanguageInt = "14";
			}
			else{
				currentINI.S2LanguageInt = "15";
			}
		}
		else if(name.substring(0,2) == "S3"){
			currentINI.S3LanguageCode = value;
			
			if(value == "ara"){
				currentINI.S3LanguageInt = "1";
			}
			else if(value == "ben"){
				currentINI.S3LanguageInt = "2";
			}
			else if(value == "chi"){
				currentINI.S3LanguageInt = "3";
			}
			else if(value == "dum"){
				currentINI.S3LanguageInt = "4";
			}
			else if(value == "eng"){
				currentINI.S3LanguageInt = "5";
			}
			else if(value == "fre"){
				currentINI.S3LanguageInt = "6";
			}
			else if(value == "ger"){
				currentINI.S3LanguageInt = "7";
			}
			else if(value == "hin"){
				currentINI.S3LanguageInt = "8";
			}
			else if(value == "jpn"){
				currentINI.S3LanguageInt = "9";
			}
			else if(value == "jav"){
				currentINI.S3LanguageInt = "10";
			}
			else if(value == "kor"){
				currentINI.S3LanguageInt = "11";
			}
			else if(value == "por"){
				currentINI.S3LanguageInt = "12";
			}
			else if(value == "rus"){
				currentINI.S3LanguageInt = "13";
			}
			else if(value == "spa"){
				currentINI.S3LanguageInt = "14";
			}
			else{
				currentINI.S3LanguageInt = "15";
			}
		}	
	}
	
	//updates value for Country Code
	else if(name.substring(2,18) == "CountryCode"){
		if(name.substring(0,2) == "S0"){
			currentINI.S0CountryCode = value;
		}
		else if(name.substring(0,2) == "S1"){
			currentINI.S1CountryCode = value;
		}
		else if(name.substring(0,2) == "S2"){
			currentINI.S2CountryCode = value;
		}
		else if(name.substring(0,2) == "S3"){
			currentINI.S3CountryCode = value;
		}	
	}
	//updates value for Service Descriptor 
	else if(name.substring(2,14) == "ServiceDesc"){
		if(name.substring(0,2) == "S0"){
			currentINI.S0ServiceDesc = value;
		}
		else if(name.substring(0,2) == "S1"){
			currentINI.S1ServiceDesc = value;
		}
		else if(name.substring(0,2) == "S2"){
			currentINI.S2ServiceDesc = value;
		}
		else if(name.substring(0,2) == "S3"){
			currentINI.S3ServiceDesc = value;
		}	
	}
	//updates value for Source
	else if(name.substring(2,8) == "Source"){
		if(name.substring(0,2) == "S0"){
			currentINI.S0Source = value;
		}
		else if(name.substring(0,2) == "S1"){
			currentINI.S1Source = value;
		}
		else if(name.substring(0,2) == "S2"){
			currentINI.S2Source = value;
		}
		else if(name.substring(0,2) == "S3"){
			currentINI.S3Source = value;
		}	
	}
	//updates value for Audio/Data File Name
	else if(name.substring(2,15) == "AudioFilename"){
		if(name.substring(0,2) == "S0"){
			currentINI.S0AudioFileName = value;
		}
		else if(name.substring(0,2) == "S1"){
			currentINI.S1AudioFileName = value;
		}
		else if(name.substring(0,2) == "S2"){
			currentINI.S2AudioFileName = value;
		}
		else if(name.substring(0,2) == "S3"){
			currentINI.S3AudioFileName = value;
		}	
	}
	
	//updates value for Audio Settings which is a composite parameter made up of AudioCoding, SBRFlag, AudioMode, and SamplingRate
	else if(name.substring(2,15) == "AudioSettings"){
		if(name.substring(0,2) == "S0"){
			//grabs the integer value from its position in the value that represents its individual value
			currentINI.S0AudioCodec = value.charAt(0);
			currentINI.S0SBRFlag = value.charAt(1);
			currentINI.S0AudioMode = value.charAt(2);
			currentINI.S0AudioSamplingRate = value.charAt(3);
		}
		else if(name.substring(0,2) == "S1"){
			currentINI.S1AudioCodec = value.charAt(0);
			currentINI.S1SBRFlag = value.charAt(1);
			currentINI.S1AudioMode = value.charAt(2);
			currentINI.S1AudioSamplingRate = value.charAt(3);
		}
		else if(name.substring(0,2) == "S2"){
			currentINI.S2AudioCodec = value.charAt(0);
			currentINI.S2SBRFlag = value.charAt(1);
			currentINI.S2AudioMode = value.charAt(2);
			currentINI.S2AudioSamplingRate = value.charAt(3);
		}
		else if(name.substring(0,2) == "S3"){
			currentINI.S3AudioCodec = value.charAt(0);
			currentINI.S3SBRFlag = value.charAt(1);
			currentINI.S3AudioMode = value.charAt(2);
			currentINI.S3AudioSamplingRate = value.charAt(3);
		}	
	}
	//updates value for TextFlag
	else if(name.substring(2,10) == "TextFlag"){
		if(name.substring(0,2) == "S0"){
			currentINI.S0TextFlag = value;
		}
		else if(name.substring(0,2) == "S1"){
			currentINI.S1TextFlag = value;
		}
		else if(name.substring(0,2) == "S2"){
			currentINI.S2TextFlag = value;
		}
		else if(name.substring(0,2) == "S3"){
			currentINI.S3TextFlag = value;
		}	
	}
	
	//updates value for IPEnabled
	else if(name == "IPEnabled"){
		//converts value to bool then NOT's it and converts back to integer
		currentINI.IPEnabled = Number(!currentINI.IPEnabled);
	}
	//updates value for IPAddress
	else if(name == "IPAddr"){
		currentINI.IPAddress = value;
	}
	//updates value for IPPort
	else if(name == "IPPort"){
		currentINI.IPPort = value;
	}
	
	//updates value for FFEnabled
	else if(name == "FFEnabled"){
		//converts value to bool then NOT's it and converts back to integer
		currentINI.FEEnabled = Number(!currentINI.FEEnabled);
	}
	//updates value for FFFileName
	else if(name == "FFFileName"){
		currentINI.FFFileName = value;
	}
	
	//updates value for PFTEnabled
	else if(name == "PFTEnabled"){
		//converts value to bool then NOT's it and converts back to integer
		currentINI.PFTEnabled = Number(!currentINI.PFTEnabled);
	}
	//updates value for PFTProtection
	else if(name == "PFTProtection"){
		//converts value to bool then NOT's it and converts back to integer
		currentINI.PFTProtection = Number(!currentINI.PFTProtection);
	}
	//updates value for PFTTransportation
	else if(name == "PFTTransportation"){
		//converts value to bool then NOT's it and converts back to integer
		currentINI.PFTTransportation = Number(!currentINI.PFTTransportation);
	}
	//updates value for PFTSource
	else if(name == "PFTSource"){
		currentINI.PFTSource = value;
	}
	//updates value for PFTDestination
	else if(name == "PFTDestination"){
		currentINI.PFTDestination = value;
	}
	//sets PFTPayloadMtu this way b/c of the jquery element
	currentINI.PFTPayloadMtu = document.getElementById("spinnerPFTPayloadMtu").value;
	
	//sets PFTStrength this way b/c of the jquery element
	currentINI.PFTStrength = document.getElementById("spinnerPFTStrength").value;
	
	autoSaveObject();
	
	validator();
	
}