

function ActiveConfigSum(){
	this.activeConfigValues == 0;
	
	this.isEmpty = function(){
		if(this.activeConfigValues  == 0){
			return true;
		}
		else{
			return false;
		}
	}
	//sets active config Sum
	this.setActiveConfigSum = function( currentActiveConfigSum){ 
		this.activeConfigValues = currentActiveConfigSum;
	};
	
	//adds errors to the list
	this.isUpToDate = function(currentActiveConfigSum){ 
		if(this.activeConfigValues == currentActiveconfigSum){
			return;
		}
		else{
			this.setActiveconfigSum(currentActiveConfigSum);
			this.displayActiveConfig();
		
		}
	};
	
	this.displayActiveConfig = function(){
		var printout = "<ul>";	
		printout+= "<li>Description: "+this.activeConfigValues.ConfigurationDesc+"</li>";
		
		printout += this.genTransmissionString();
		
		if(this.activeConfigValues.S0Source == 1 || this.activeConfigValues.S0Source == 2 || this.activeConfigValues.S0Source == 3){
			printout += this.genAudioString(0);
		}
		if(this.activeConfigValue.S0Source == 5){
			printout += this.genDataString(0);
		}
		
		if(this.activeConfigValues.S1Source == 1 || this.activeConfigValues.S1Source == 2 || this.activeConfigValues.S1Source == 3){
			printout += this.genAudioString(1);
		}
		if(this.activeConfigValue.S1Source == 5){
			printout += this.genDataString(1);
		}
		
		if(this.activeConfigValues.S2Source == 1 || this.activeConfigValues.S2Source == 2 || this.activeConfigValues.S2Source == 3){
			printout += this.genAudioString(2);
		}
		if(this.activeConfigValue.S2Source == 5){
			printout += this.genDataString(2);
		}
		
		if(this.activeConfigValues.S3Source == 1 || this.activeConfigValues.S3Source == 2 || this.activeConfigValues.S3Source == 3){
			printout += this.genAudioString(3);
		}
		if(this.activeConfigValue.S3Source == 5){
			printout += this.genDataString(3);
		}
		printout += "</ul>";
		
		document.getElementById("ActiveConfigSum").innerHTML = printout;
	};
	
	this.genTransmissionString = function(){
		var printout = "<li>";
		
		printout += "Transmission: ";
		
		if(this.activeConfigValues.Robustness == 0){
			printout+= "A ";
		}
		if(this.activeConfigValues.Robustness == 1){
			printout+= "B ";
		}
		if(this.activeConfigValues.Robustness == 2){
			printout+= "C ";
		}
		if(this.activeConfigValues.Robustness == 3){
			printout+= "D ";
		}
		else{
			return;
		}
		
		if(this.activeConfigValues.SpectrumOcc == 0){
			printout += "4.5 kHz";
		}
		if(this.activeConfigValues.SpectrumOcc == 1){
			printout += "5 kHz";
		}
		if(this.activeConfigValues.SpectrumOcc == 2){
			printout += "9 kHz";
		}
		if(this.activeConfigValues.SpectrumOcc == 3){
			printout += "10 kHz";
		}
		if(this.activeConfigValues.SpectrumOcc == 4){
			printout += "18 kHz";
		}
		if(this.activeConfigValues.SpectrumOcc == 5){
			printout += "20 kHz";
		}
		else{
			return;
		}
		
		if(this.activeConfigValues.MSCMode = 0 || this.activeConfigValues.MSCMode = 1 || this.activeConfigValues.MSCMode = 2){
			printout += "64 QAM"; 
		}
		if(this.activeConfigValues.MSCMode = 3){
			printout += "16 QAM";
		}
		else{
			return;
		}
		
		if(this.activeConfigValues.MSCMode == 0){
			if(this.activeConfigValues.ProtBInt == 0){
				printout += " 0.50";
			}
			if(this.activeConfigValues.ProtBInt == 1){
				printout += " 0.60";
			}
			if(this.activeConfigValues.ProtBInt == 2){
				printout += " 0.71";
			}
			if(this.activeConfigValues.ProtBInt == 3){
				printout += " 0.78";
			}
		}
		if(this.activeConfigValues.MSCMode == 3){
			if(this.activeConfigValues.ProtBInt == 0){
				printout += " 0.50";
			}
			if(this.activeConfigValues.ProtBInt == 1){
				printout += " 0.62";
			}
		}
		
		if(this.activeConfigValues.MSCMode == 1){
			//Part A
			if(this.activeConfigValues.ProtAInt == 0){
				printout += " 0.50/";
			}
			if(this.activeConfigValues.ProtAInt == 1){
				printout += " 0.57/";
			}
			if(this.activeConfigValues.ProtAInt == 2){
				printout += " 0.60/";
			}
			if(this.activeConfigValues.ProtAInt == 3){
				printout += " 0.66/";
			}
			//Part B
			if(this.activeConfigValues.ProtBInt == 0){
				printout += "0.48";
			}
			if(this.activeConfigValues.ProtBInt == 1){
				printout += "0.58";
			}
			if(this.activeConfigValues.ProtBInt == 2){
				printout += "0.71";
			}
			if(this.activeConfigValues.ProtBInt == 3){
				printout += "0.78";
			}
		}
		
		if(this.activeConfigValues.MSCMode == 2){
			//Part A
			if(this.activeConfigValues.ProtAInt == 0){
				printout += " 0.50/";
			}
			if(this.activeConfigValues.ProtAInt == 1){
				printout += " 0.57/";
			}
			if(this.activeConfigValues.ProtAInt == 2){
				printout += " 0.60/";
			}
			if(this.activeConfigValues.ProtAInt == 3){
				printout += " 0.66/";
			}
			//Part B
			if(this.activeConfigValues.ProtBInt == 0){
				printout += "0.45";
			}
			if(this.activeConfigValues.ProtBInt == 1){
				printout += "0.55";
			}
			if(this.activeConfigValues.ProtBInt == 2){
				printout += "0.72";
			}
			if(this.activeConfigValues.ProtBInt == 3){
				printout += "0.78";
			}
		}
		
		printout += "</li>";
		
		return printout;
	};

	this.genAudioString = function(num){
		var printout = "<li>";
		if(num == 0){
			printout = "Audio 1";
			ServiceLabel = this.activeConfigValues.S0ServiceLabel;
			AudioCodec = this.activeConfigValues.S0AudioCodec;
			SBRFlag = this.activeConfigValues.S0SBRFlag;
			AudioSamplingRate = this.activeConfigValues.S0AudioSamplingRate;
			LanguageCode = this.activeConfigValues.S0LanguageCode;
		}
		if(num == 1){
			printout = "Audio 2";
			ServiceLabel = this.activeConfigValues.S1ServiceLabel;
			AudioCodec = this.activeConfigValues.S1AudioCodec;
			SBRFlag = this.activeConfigValues.S1SBRFlag;
			AudioSamplingRate = this.activeConfigValues.S1AudioSamplingRate;
			LanguageCode = this.activeConfigValues.S1LanguageCode;
		}
		if(num == 2){
			printout = "Audio 3";
			ServiceLabel = this.activeConfigValues.S2ServiceLabel;
			AudioCodec = this.activeConfigValues.S2AudioCodec;
			SBRFlag = this.activeConfigValues.S2SBRFlag;
			AudioSamplingRate = this.activeConfigValues.S2AudioSamplingRate;
			LanguageCode = this.activeConfigValues.S2LanguageCode;
		}
		if(num == 3){
			printout = "Audio 4";
			ServiceLabel = this.activeConfigValues.S3ServiceLabel;
			AudioCodec = this.activeConfigValues.S3AudioCodec;
			SBRFlag = this.activeConfigValues.S3SBRFlag;
			AudioSamplingRate = this.activeConfigValues.S3AudioSamplingRate;
			LanguageCode = this.activeConfigValues.S3LanguageCode;
		}
		
		if(ServiceLabel != ""){
			printout+= "/"+ServiceLabel+": ";
		}
		else{
			printout += ": ";
		}
		
		if(AudioCodec == 0){
			printout += "AAC";
		}
		if(AudioCodec == 1){
			printout += "CLEP";
		}
		if(AudioCodec == 2){
			printout += "HVXC";
		}
		
		if(SBRFlag == 1){
			printout += "+";
		}
		else{
			printout += " ";
		}
		
		if(AudioSamplingRate == 0){
			printout += "8 kHz";
		}
		if(AudioSamplingRate == 1){
			printout += "12 kHz";
		}
		if(AudioSamplingRate == 2){
			printout += "16 kHz";
		}
		if(AudioSamplingRate == 3){
			printout += "24 kHz";
		}
		
		for(var i =0 ; i <languageCodesArray.length; i++){
			if(LanguageCode == languageCodeArray[i][0]){
				LanguageName = languageCodeArray[i][1];	
			}
		}
		
		if(LanguageName.search(";") != -1){
			var to = LanguageName.search(";");
			printout += " "+LanguageName.substring(0, to)+"";	
		}
		else{
			printout += " "+LanguageName+"";
		}
		printout += "</li>";
		
		return printout;
		
	};

	this.genDataString = function(num){
		var printout = "<li>";
		if(num == 0){
			printout = "Data";
			ServiceLabel = this.activeConfigValues.S0ServiceLabel;
			LanguageCode = this.activeConfigValues.S0LanguageCode;
		}
		if(num == 1){
			printout = "Data";
			ServiceLabel = this.activeConfigValues.S1ServiceLabel;
			LanguageCode = this.activeConfigValues.S1LanguageCode;
		}
		if(num == 2){
			printout = "Data";
			ServiceLabel = this.activeConfigValues.S2ServiceLabel;
			LanguageCode = this.activeConfigValues.S2LanguageCode;
		}
		if(num == 3){
			printout = "Data";
			ServiceLabel = this.activeConfigValues.S3ServiceLabel;
			LanguageCode = this.activeConfigValues.S3LanguageCode;
		}
		
		if(ServiceLabel != ""){
			printout+= "/"+ServiceLabel+": MOT";
		}
		else{
			printout += ": MOT";
		}
		
			for(var i =0 ; i <languageCodesArray.length; i++){
			if(LanguageCode == languageCodeArray[i][0]){
				LanguageName = languageCodeArray[i][1];	
			}
		}
		
		if(LanguageName.search(";") != -1){
			var to = LanguageName.search(";");
			printout += " "+LanguageName.substring(0, to)+"";	
		}
		else{
			printout += " "+LanguageName+"";
		}
		printout += "</li>";
		
		return printout;
		
	};
}
