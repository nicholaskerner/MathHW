
function checkAndLoadServices(){
	
	if(currentINI.S0DataLengthA != 0 || currentINI.S1DataLengthA != 0 || currentINI.S2DataLengthA != 0 || currentINI.S3DataLengthA != 0){
	
		var outPut = "<div class=\"alert alert-info\"> <button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button><strong>Heads up!</strong>This parameter has a value that is no longer supported. In order to change this perameter please select at supported <a href=\"#tab105\" onclick=\"change(105)\">MSC Mode</a>.</div>";
		
		document.getElementById("servicetabs").innerHTML = outPut;
	}
	else{
		
		printSerivces();
		validator();
		populateServiceSelect();
		
	
	
	
	}





}
//prints service accordins
function printSerivces(){
	var services =  "<div class=\"accordion\" id=\"accordion4\">"; 
		if(currentINI.S0DataLengthB > 0){
			services+= printAudioService(0);
		}
		if(currentINI.S1DataLengthB > 0){
			services+= printAudioService(1);
		}
		if(currentINI.S2DataLengthB > 0){
			services+= printAudioService(2);
		}
		if(currentINI.S3DataLengthB > 0){
			services+= printAudioService(3);
		}
		services+= "</div>";

		document.getElementById("servicetabs").innerHTML = services;

}
//Populates service tab after selecting from the service tab dropdown options.
function servicesToDisplay(value){
	if(currentINI.S0DataLengthA != 0 || currentINI.S1DataLengthA != 0 || currentINI.S2DataLengthA != 0 || currentINI.S3DataLengthA != 0){
		return;
	}
	else{
		currentINI.S0DataLengthA = 0;
		currentINI.S1DataLengthA = 0;
		currentINI.S2DataLengthA = 0;
		currentINI.S3DataLengthA = 0;
		
		currentINI.S0ServiceLabel = "";
		currentINI.S1ServiceLabel = "";
		currentINI.S2ServiceLabel = "";
		currentINI.S3ServiceLabel = "";
		
		currentINI.S0ServiceID = "0";
		currentINI.S1ServiceID = "0";
		currentINI.S2ServiceID = "0";
		currentINI.S3ServiceID = "0";
		
		currentINI.S0ServiceDesc = 	0;
		currentINI.S1ServiceDesc = 	0;
		currentINI.S2ServiceDesc = 	0;
		currentINI.S3ServiceDesc = 	0;
		
		currentINI.S0StreamID = 0;
		currentINI.S1StreamID = 1;
		currentINI.S2StreamID = 2;
		currentINI.S3StreamID = 3;
		
		currentINI.S0EnhancementFlag = 0;
		currentINI.S1EnhancementFlag = 0;
		currentINI.S2EnhancementFlag = 0;
		currentINI.S3EnhancementFlag = 0;
		
		currentINI.S0RepeatAudio = 0;
		currentINI.S1RepeatAudio = 0;
		currentINI.S2RepeatAudio = 0;
		currentINI.S3RepeatAudio = 0;
		
		currentINI.S0CoderField = 0;
		currentINI.S1CoderField = 0;
		currentINI.S2CoderField = 0;
		currentINI.S3CoderField = 0;
		
		currentINI.S0CASystemUsed = 0;
		currentINI.S1CASystemUsed = 0;
		currentINI.S2CASystemUsed = 0;
		currentINI.S3CASystemUsed = 0;
		
		currentINI.S0AudioFileName = "";
		currentINI.S1AudioFileName = "";
		currentINI.S2AudioFileName = "";
		currentINI.S3AudioFileName = "";
		
		currentINI.S0LanguageInt = 0;
		currentINI.S1LanguageInt = 0;
		currentINI.S2LanguageInt = 0;
		currentINI.S3LanguageInt = 0;
		
		currentINI.S0LanguageCode = "---";
		currentINI.S1LanguageCode = "---";
		currentINI.S2LanguageCode = "---";
		currentINI.S3LanguageCode = "---";
		
		currentINI.S0CountryCode = "---";
		currentINI.S1CountryCode = "---";
		currentINI.S2CountryCode = "---";
		currentINI.S3CountryCode = "---";
		
		if(value == "1.1"){
			currentINI.S0DataLengthB = lookUpTotalDataLength();
			currentINI.S0AudioDataFlag = 0;	
			currentINI.S0AudioCodec = 0;
			currentINI.S0SBRFlag = 0;
			currentINI.S0AudioMode = 0;
			currentINI.S0AudioSamplingRate = 1;
			currentINI.S0TextFlag = 1;	
			currentINI.S0Source	= 3;
			
			//clear other services
			currentINI.S1DataLengthB = 0;
			currentINI.S1AudioDataFlag = 2;	
			currentINI.S1AudioCodec = 0;
			currentINI.S1SBRFlag = 0;
			currentINI.S1AudioMode = 0;
			currentINI.S1AudioSamplingRate = 1;
			currentINI.S1TextFlag = 1;	
			currentINI.S1Source	= 3;
			
			currentINI.S2DataLengthB = 0;
			currentINI.S2AudioDataFlag = 2;	
			currentINI.S2AudioCodec = 0;
			currentINI.S2SBRFlag = 0;
			currentINI.S2AudioMode = 0;
			currentINI.S2AudioSamplingRate = 1;
			currentINI.S2TextFlag = 1;	
			currentINI.S2Source	= 3;
			
			currentINI.S3DataLengthB = 0;
			currentINI.S3AudioDataFlag = 2;	
			currentINI.S3AudioCodec = 0;
			currentINI.S3SBRFlag = 0;
			currentINI.S3AudioMode = 0;
			currentINI.S3AudioSamplingRate = 1;
			currentINI.S3TextFlag = 1;	
			currentINI.S3Source	= 3;	
		}
		else if(value == "2.1"){
			currentINI.S0DataLengthB = lookUpTotalDataLength();
			currentINI.S0AudioDataFlag = 0;	
			currentINI.S0AudioCodec = 0;
			currentINI.S0SBRFlag = 1;
			currentINI.S0AudioMode = 0;
			currentINI.S0AudioSamplingRate = 1;
			currentINI.S0TextFlag = 1;	
			currentINI.S0Source	= 3;
			
			//clear other services
			currentINI.S1DataLengthB = 0;
			currentINI.S1AudioDataFlag = 2;	
			currentINI.S1AudioCodec = 0;
			currentINI.S1SBRFlag = 0;
			currentINI.S1AudioMode = 0;
			currentINI.S1AudioSamplingRate = 1;
			currentINI.S1TextFlag = 1;	
			currentINI.S1Source	= 6;
			
			currentINI.S2DataLengthB = 0;
			currentINI.S2AudioDataFlag = 2;	
			currentINI.S2AudioCodec = 0;
			currentINI.S2SBRFlag = 0;
			currentINI.S2AudioMode = 0;
			currentINI.S2AudioSamplingRate = 1;
			currentINI.S2TextFlag = 1;	
			currentINI.S2Source	= 6;
			
			currentINI.S3DataLengthB = 0;
			currentINI.S3AudioDataFlag = 2;	
			currentINI.S3AudioCodec = 0;
			currentINI.S3SBRFlag = 0;
			currentINI.S3AudioMode = 0;
			currentINI.S3AudioSamplingRate = 1;
			currentINI.S3TextFlag = 1;	
			currentINI.S3Source	= 6;	
		}
		else if(value == "3.1"){
			currentINI.S0DataLengthB = lookUpTotalDataLength();
			currentINI.S0AudioDataFlag = 0;	
			currentINI.S0AudioCodec = 0;
			currentINI.S0SBRFlag = 1;
			currentINI.S0AudioMode = 0;
			currentINI.S0AudioSamplingRate = 3;
			currentINI.S0TextFlag = 1;	
			currentINI.S0Source	= 3;
			
			//clear other services
			currentINI.S1DataLengthB = 0;
			currentINI.S1AudioDataFlag = 2;	
			currentINI.S1AudioCodec = 0;
			currentINI.S1SBRFlag = 0;
			currentINI.S1AudioMode = 0;
			currentINI.S1AudioSamplingRate = 1;
			currentINI.S1TextFlag = 1;	
			currentINI.S1Source	= 6;
			
			currentINI.S2DataLengthB = 0;
			currentINI.S2AudioDataFlag = 2;	
			currentINI.S2AudioCodec = 0;
			currentINI.S2SBRFlag = 0;
			currentINI.S2AudioMode = 0;
			currentINI.S2AudioSamplingRate = 1;
			currentINI.S2TextFlag = 1;	
			currentINI.S2Source	= 6;
			
			currentINI.S3DataLengthB = 0;
			currentINI.S3AudioDataFlag = 2;	
			currentINI.S3AudioCodec = 0;
			currentINI.S3SBRFlag = 0;
			currentINI.S3AudioMode = 0;
			currentINI.S3AudioSamplingRate = 1;
			currentINI.S3TextFlag = 1;	
			currentINI.S3Source	= 6;	
		}
		else if(value == "4.1" || value == "5.1" || value == "6.1" || value == "7.1"){
			currentINI.S0DataLengthB = lookUpTotalDataLength();
			currentINI.S0AudioDataFlag = 0;	
			currentINI.S0AudioCodec = 0;
			currentINI.S0SBRFlag = 1;
			currentINI.S0AudioMode = 1;
			currentINI.S0AudioSamplingRate = 3;
			currentINI.S0TextFlag = 1;	
			currentINI.S0Source	= 3;
			
			//clear other services
			currentINI.S1DataLengthB = 0;
			currentINI.S1AudioDataFlag = 2;	
			currentINI.S1AudioCodec = 0;
			currentINI.S1SBRFlag = 0;
			currentINI.S1AudioMode = 0;
			currentINI.S1AudioSamplingRate = 1;
			currentINI.S1TextFlag = 1;	
			currentINI.S1Source	= 6;
			
			currentINI.S2DataLengthB = 0;
			currentINI.S2AudioDataFlag = 2;	
			currentINI.S2AudioCodec = 0;
			currentINI.S2SBRFlag = 0;
			currentINI.S2AudioMode = 0;
			currentINI.S2AudioSamplingRate = 1;
			currentINI.S2TextFlag = 1;	
			currentINI.S2Source	= 6;
			
			currentINI.S3DataLengthB = 0;
			currentINI.S3AudioDataFlag = 2;	
			currentINI.S3AudioCodec = 0;
			currentINI.S3SBRFlag = 0;
			currentINI.S3AudioMode = 0;
			currentINI.S3AudioSamplingRate = 1;
			currentINI.S3TextFlag = 1;	
			currentINI.S3Source	= 6;	
		}
		else if(value == "5.2" || value == "6.2" || value =="7.2"){
			currentINI.S0DataLengthB = lookUpTotalDataLength() - 192;
			currentINI.S0AudioDataFlag = 0;	
			currentINI.S0AudioCodec = 0;
			currentINI.S0SBRFlag = 1;
			currentINI.S0AudioMode = 1;
			currentINI.S0AudioSamplingRate = 3;
			currentINI.S0TextFlag = 1;	
			currentINI.S0Source	= 3;
			
			currentINI.S1DataLengthB = 192;
			currentINI.S1AudioDataFlag = 1;	
			currentINI.S1AudioCodec = 0;
			currentINI.S1SBRFlag = 0;
			currentINI.S1AudioMode = 0;
			currentINI.S1AudioSamplingRate = 1;
			currentINI.S1TextFlag = 1;	
			currentINI.S1Source	= 5;
			
			//clear other services
			currentINI.S2DataLengthB = 0;
			currentINI.S2AudioDataFlag = 2;	
			currentINI.S2AudioCodec = 0;
			currentINI.S2SBRFlag = 0;
			currentINI.S2AudioMode = 0;
			currentINI.S2AudioSamplingRate = 1;
			currentINI.S2TextFlag = 1;	
			currentINI.S2Source	= 6;
			
			currentINI.S3DataLengthB = 0;
			currentINI.S3AudioDataFlag = 2;	
			currentINI.S3AudioCodec = 0;
			currentINI.S3SBRFlag = 0;
			currentINI.S3AudioMode = 0;
			currentINI.S3AudioSamplingRate = 1;
			currentINI.S3TextFlag = 1;	
			currentINI.S3Source	= 6;	
		}
		else if(value == "5.3"){
			currentINI.S0DataLengthB = lookUpTotalDataLength()/2;
			currentINI.S0AudioDataFlag = 0;	
			currentINI.S0AudioCodec = 0;
			currentINI.S0SBRFlag = 0;
			currentINI.S0AudioMode = 0;
			currentINI.S0AudioSamplingRate = 1;
			currentINI.S0TextFlag = 1;	
			currentINI.S0Source	= 3;
			
			currentINI.S1DataLengthB = lookUpTotalDataLength()/2;
			currentINI.S1AudioDataFlag = 0;	
			currentINI.S1AudioCodec = 0;
			currentINI.S1SBRFlag = 0;
			currentINI.S1AudioMode = 0;
			currentINI.S1AudioSamplingRate = 1;
			currentINI.S1TextFlag = 1;	
			currentINI.S1Source	= 3;
			
			//clear other services
			currentINI.S2DataLengthB = 0;
			currentINI.S2AudioDataFlag = 2;	
			currentINI.S2AudioCodec = 0;
			currentINI.S2SBRFlag = 0;
			currentINI.S2AudioMode = 0;
			currentINI.S2AudioSamplingRate = 1;
			currentINI.S2TextFlag = 1;	
			currentINI.S2Source	= 6;
			
			currentINI.S3DataLengthB = 0;
			currentINI.S3AudioDataFlag = 2;	
			currentINI.S3AudioCodec = 0;
			currentINI.S3SBRFlag = 0;
			currentINI.S3AudioMode = 0;
			currentINI.S3AudioSamplingRate = 1;
			currentINI.S3TextFlag = 1;	
			currentINI.S3Source	= 6;	
		}
		else if(value == "6.3"){
			currentINI.S0DataLengthB = lookUpTotalDataLength()-480;
			currentINI.S0AudioDataFlag = 0;	
			currentINI.S0AudioCodec = 0;
			currentINI.S0SBRFlag = 1;
			currentINI.S0AudioMode = 0;
			currentINI.S0AudioSamplingRate = 3;
			currentINI.S0TextFlag = 1;	
			currentINI.S0Source	= 3;
			
			currentINI.S1DataLengthB = 480;
			currentINI.S1AudioDataFlag = 1;	
			currentINI.S1AudioCodec = 0;
			currentINI.S1SBRFlag = 0;
			currentINI.S1AudioMode = 0;
			currentINI.S1AudioSamplingRate = 1;
			currentINI.S1TextFlag = 1;	
			currentINI.S1Source	= 5;
			
			//clear other services
			currentINI.S2DataLengthB = 0;
			currentINI.S2AudioDataFlag = 2;	
			currentINI.S2AudioCodec = 0;
			currentINI.S2SBRFlag = 0;
			currentINI.S2AudioMode = 0;
			currentINI.S2AudioSamplingRate = 1;
			currentINI.S2TextFlag = 1;	
			currentINI.S2Source	= 6;
			
			currentINI.S3DataLengthB = 0;
			currentINI.S3AudioDataFlag = 2;	
			currentINI.S3AudioCodec = 0;
			currentINI.S3SBRFlag = 0;
			currentINI.S3AudioMode = 0;
			currentINI.S3AudioSamplingRate = 1;
			currentINI.S3TextFlag = 1;	
			currentINI.S3Source	= 6;	
		}
		else if(value == "6.4"){
			currentINI.S0DataLengthB = lookUpTotalDataLength()/2;
			currentINI.S0AudioDataFlag = 0;	
			currentINI.S0AudioCodec = 0;
			currentINI.S0SBRFlag = 1;
			currentINI.S0AudioMode = 0;
			currentINI.S0AudioSamplingRate = 1;
			currentINI.S0TextFlag = 1;	
			currentINI.S0Source	= 3;
			
			currentINI.S1DataLengthB = lookUpTotalDataLength()/2;
			currentINI.S1AudioDataFlag = 0;	
			currentINI.S1AudioCodec = 0;
			currentINI.S1SBRFlag = 1;
			currentINI.S1AudioMode = 0;
			currentINI.S1AudioSamplingRate = 1;
			currentINI.S1TextFlag = 1;	
			currentINI.S1Source	= 3;
			
			//clear other services
			currentINI.S2DataLengthB = 0;
			currentINI.S2AudioDataFlag = 2;	
			currentINI.S2AudioCodec = 0;
			currentINI.S2SBRFlag = 0;
			currentINI.S2AudioMode = 0;
			currentINI.S2AudioSamplingRate = 1;
			currentINI.S2TextFlag = 1;	
			currentINI.S2Source	= 6;
			
			currentINI.S3DataLengthB = 0;
			currentINI.S3AudioDataFlag = 2;	
			currentINI.S3AudioCodec = 0;
			currentINI.S3SBRFlag = 0;
			currentINI.S3AudioMode = 0;
			currentINI.S3AudioSamplingRate = 1;
			currentINI.S3TextFlag = 1;	
			currentINI.S3Source	= 6;	
		}
		else if(value == "7.3" || value == "8.2"){
			currentINI.S0DataLengthB = lookUpTotalDataLength()-480;
			currentINI.S0AudioDataFlag = 0;	
			currentINI.S0AudioCodec = 0;
			currentINI.S0SBRFlag = 1;
			currentINI.S0AudioMode = 1;
			currentINI.S0AudioSamplingRate = 3;
			currentINI.S0TextFlag = 1;	
			currentINI.S0Source	= 3;
			
			currentINI.S1DataLengthB = 480;
			currentINI.S1AudioDataFlag = 1;	
			currentINI.S1AudioCodec = 0;
			currentINI.S1SBRFlag = 1;
			currentINI.S1AudioMode = 0;
			currentINI.S1AudioSamplingRate = 1;
			currentINI.S1TextFlag = 1;	
			currentINI.S1Source	= 5;
			
			//clear other services
			currentINI.S2DataLengthB = 0;
			currentINI.S2AudioDataFlag = 2;	
			currentINI.S2AudioCodec = 0;
			currentINI.S2SBRFlag = 0;
			currentINI.S2AudioMode = 0;
			currentINI.S2AudioSamplingRate = 1;
			currentINI.S2TextFlag = 1;	
			currentINI.S2Source	= 6;
			
			currentINI.S3DataLengthB = 0;
			currentINI.S3AudioDataFlag = 2;	
			currentINI.S3AudioCodec = 0;
			currentINI.S3SBRFlag = 0;
			currentINI.S3AudioMode = 0;
			currentINI.S3AudioSamplingRate = 1;
			currentINI.S3TextFlag = 1;	
			currentINI.S3Source	= 6;	
		}
		else if(value == "7.4" || value == "8.3"){
			currentINI.S0DataLengthB = lookUpTotalDataLength()-480;
			currentINI.S0AudioDataFlag = 0;	
			currentINI.S0AudioCodec = 0;
			currentINI.S0SBRFlag = 1;
			currentINI.S0AudioMode = 1;
			currentINI.S0AudioSamplingRate = 3;
			currentINI.S0TextFlag = 1;	
			currentINI.S0Source	= 3;
			
			currentINI.S1DataLengthB = 480;
			currentINI.S1AudioDataFlag = 0;	
			currentINI.S1AudioCodec = 0;
			currentINI.S1SBRFlag = 0;
			currentINI.S1AudioMode = 0;
			currentINI.S1AudioSamplingRate = 1;
			currentINI.S1TextFlag = 1;	
			currentINI.S1Source	= 3;
			
			//clear other services
			currentINI.S2DataLengthB = 0;
			currentINI.S2AudioDataFlag = 2;	
			currentINI.S2AudioCodec = 0;
			currentINI.S2SBRFlag = 0;
			currentINI.S2AudioMode = 0;
			currentINI.S2AudioSamplingRate = 1;
			currentINI.S2TextFlag = 1;	
			currentINI.S2Source	= 6;
			
			currentINI.S3DataLengthB = 0;
			currentINI.S3AudioDataFlag = 2;	
			currentINI.S3AudioCodec = 0;
			currentINI.S3SBRFlag = 0;
			currentINI.S3AudioMode = 0;
			currentINI.S3AudioSamplingRate = 1;
			currentINI.S3TextFlag = 1;	
			currentINI.S3Source	= 6;	
		}
		else if(value == "7.5"){
			currentINI.S0DataLengthB = lookUpTotalDataLength()/2;
			currentINI.S0AudioDataFlag = 0;	
			currentINI.S0AudioCodec = 0;
			currentINI.S0SBRFlag = 1;
			currentINI.S0AudioMode = 0;
			currentINI.S0AudioSamplingRate = 3;
			currentINI.S0TextFlag = 1;	
			currentINI.S0Source	= 3;
			
			currentINI.S1DataLengthB = lookUpTotalDataLength()/2;
			currentINI.S1AudioDataFlag = 0;	
			currentINI.S1AudioCodec = 0;
			currentINI.S1SBRFlag = 1;
			currentINI.S1AudioMode = 0;
			currentINI.S1AudioSamplingRate = 3;
			currentINI.S1TextFlag = 1;	
			currentINI.S1Source	= 3;
			
			//clear other services
			currentINI.S2DataLengthB = 0;
			currentINI.S2AudioDataFlag = 2;	
			currentINI.S2AudioCodec = 0;
			currentINI.S2SBRFlag = 0;
			currentINI.S2AudioMode = 0;
			currentINI.S2AudioSamplingRate = 1;
			currentINI.S2TextFlag = 1;	
			currentINI.S2Source	= 6;
			
			currentINI.S3DataLengthB = 0;
			currentINI.S3AudioDataFlag = 2;	
			currentINI.S3AudioCodec = 0;
			currentINI.S3SBRFlag = 0;
			currentINI.S3AudioMode = 0;
			currentINI.S3AudioSamplingRate = 1;
			currentINI.S3TextFlag = 1;	
			currentINI.S3Source	= 6;	
		}
		else if(value == "8.1"){
			currentINI.S0DataLengthB = lookUpTotalDataLength();
			currentINI.S0AudioDataFlag = 0;	
			currentINI.S0AudioCodec = 0;
			currentINI.S0SBRFlag = 1;
			currentINI.S0AudioMode = 2;
			currentINI.S0AudioSamplingRate = 3;
			currentINI.S0TextFlag = 1;	
			currentINI.S0Source	= 3;
			
			//clear other services
			currentINI.S1DataLengthB = 0;
			currentINI.S1AudioDataFlag = 2;	
			currentINI.S1AudioCodec = 0;
			currentINI.S1SBRFlag = 1;
			currentINI.S1AudioMode = 0;
			currentINI.S1AudioSamplingRate = 3;
			currentINI.S1TextFlag = 1;	
			currentINI.S1Source	= 6;
			
			currentINI.S2DataLengthB = 0;
			currentINI.S2AudioDataFlag = 2;	
			currentINI.S2AudioCodec = 0;
			currentINI.S2SBRFlag = 0;
			currentINI.S2AudioMode = 0;
			currentINI.S2AudioSamplingRate = 1;
			currentINI.S2TextFlag = 1;	
			currentINI.S2Source	= 6;
			
			currentINI.S3DataLengthB = 0;
			currentINI.S3AudioDataFlag = 2;	
			currentINI.S3AudioCodec = 0;
			currentINI.S3SBRFlag = 0;
			currentINI.S3AudioMode = 0;
			currentINI.S3AudioSamplingRate = 1;
			currentINI.S3TextFlag = 1;	
			currentINI.S3Source	= 6;	
		}
		else if(value == "8.4"){
			currentINI.S0DataLengthB = lookUpTotalDataLength()/2;
			currentINI.S0AudioDataFlag = 0;	
			currentINI.S0AudioCodec = 0;
			currentINI.S0SBRFlag = 1;
			currentINI.S0AudioMode = 1;
			currentINI.S0AudioSamplingRate = 3;
			currentINI.S0TextFlag = 1;	
			currentINI.S0Source	= 3;
			
			currentINI.S1DataLengthB = lookUpTotalDataLength()/2;
			currentINI.S1AudioDataFlag = 0;	
			currentINI.S1AudioCodec = 0;
			currentINI.S1SBRFlag = 1;
			currentINI.S1AudioMode = 1;
			currentINI.S1AudioSamplingRate = 3;
			currentINI.S1TextFlag = 1;	
			currentINI.S1Source	= 3;
			
			//clear other services
			currentINI.S2DataLengthB = 0;
			currentINI.S2AudioDataFlag = 2;	
			currentINI.S2AudioCodec = 0;
			currentINI.S2SBRFlag = 0;
			currentINI.S2AudioMode = 0;
			currentINI.S2AudioSamplingRate = 1;
			currentINI.S2TextFlag = 1;	
			currentINI.S2Source	= 6;
			
			currentINI.S3DataLengthB = 0;
			currentINI.S3AudioDataFlag = 2;	
			currentINI.S3AudioCodec = 0;
			currentINI.S3SBRFlag = 0;
			currentINI.S3AudioMode = 0;
			currentINI.S3AudioSamplingRate = 1;
			currentINI.S3TextFlag = 1;	
			currentINI.S3Source	= 6;	
		}
		else if(value == "9.1"){
			currentINI.S0DataLengthB = lookUpTotalDataLength();
			currentINI.S0AudioDataFlag = 0;	
			currentINI.S0AudioCodec = 0;
			currentINI.S0SBRFlag = 1;
			currentINI.S0AudioMode = 2;
			currentINI.S0AudioSamplingRate = 3;
			currentINI.S0TextFlag = 1;	
			currentINI.S0Source	= 3;
			
			//clear other services
			currentINI.S1DataLengthB = 0;
			currentINI.S1AudioDataFlag = 2;	
			currentINI.S1AudioCodec = 0;
			currentINI.S1SBRFlag = 1;
			currentINI.S1AudioMode = 1;
			currentINI.S1AudioSamplingRate = 3;
			currentINI.S1TextFlag = 1;	
			currentINI.S1Source	= 6;
			
			currentINI.S2DataLengthB = 0;
			currentINI.S2AudioDataFlag = 2;	
			currentINI.S2AudioCodec = 0;
			currentINI.S2SBRFlag = 0;
			currentINI.S2AudioMode = 0;
			currentINI.S2AudioSamplingRate = 1;
			currentINI.S2TextFlag = 1;	
			currentINI.S2Source	= 6;
			
			currentINI.S3DataLengthB = 0;
			currentINI.S3AudioDataFlag = 2;	
			currentINI.S3AudioCodec = 0;
			currentINI.S3SBRFlag = 0;
			currentINI.S3AudioMode = 0;
			currentINI.S3AudioSamplingRate = 1;
			currentINI.S3TextFlag = 1;	
			currentINI.S3Source	= 6;	
		}
		else if(value == "9.2"){
			currentINI.S0DataLengthB = lookUpTotalDataLength()-960;
			currentINI.S0AudioDataFlag = 0;	
			currentINI.S0AudioCodec = 0;
			currentINI.S0SBRFlag = 1;
			currentINI.S0AudioMode = 1;
			currentINI.S0AudioSamplingRate = 3;
			currentINI.S0TextFlag = 1;	
			currentINI.S0Source	= 3;
			
			currentINI.S1DataLengthB = 480;
			currentINI.S1AudioDataFlag = 1;	
			currentINI.S1AudioCodec = 0;
			currentINI.S1SBRFlag = 1;
			currentINI.S1AudioMode = 1;
			currentINI.S1AudioSamplingRate = 3;
			currentINI.S1TextFlag = 1;	
			currentINI.S1Source	= 5;
			
			//clear other services
			currentINI.S2DataLengthB = 0;
			currentINI.S2AudioDataFlag = 2;	
			currentINI.S2AudioCodec = 0;
			currentINI.S2SBRFlag = 0;
			currentINI.S2AudioMode = 0;
			currentINI.S2AudioSamplingRate = 1;
			currentINI.S2TextFlag = 1;	
			currentINI.S2Source	= 6;
			
			currentINI.S3DataLengthB = 0;
			currentINI.S3AudioDataFlag = 2;	
			currentINI.S3AudioCodec = 0;
			currentINI.S3SBRFlag = 0;
			currentINI.S3AudioMode = 0;
			currentINI.S3AudioSamplingRate = 1;
			currentINI.S3TextFlag = 1;	
			currentINI.S3Source	= 6;	
		}
		else if(value == "9.3"){
			currentINI.S0DataLengthB = lookUpTotalDataLength()-960;
			currentINI.S0AudioDataFlag = 0;	
			currentINI.S0AudioCodec = 0;
			currentINI.S0SBRFlag = 1;
			currentINI.S0AudioMode = 1;
			currentINI.S0AudioSamplingRate = 3;
			currentINI.S0TextFlag = 1;	
			currentINI.S0Source	= 3;
			
			currentINI.S1DataLengthB = 480;
			currentINI.S1AudioDataFlag = 0;	
			currentINI.S1AudioCodec = 0;
			currentINI.S1SBRFlag = 1;
			currentINI.S1AudioMode = 0;
			currentINI.S1AudioSamplingRate = 3;
			currentINI.S1TextFlag = 1;	
			currentINI.S1Source	= 3;
			
			//clear other services
			currentINI.S2DataLengthB = 0;
			currentINI.S2AudioDataFlag = 2;	
			currentINI.S2AudioCodec = 0;
			currentINI.S2SBRFlag = 0;
			currentINI.S2AudioMode = 0;
			currentINI.S2AudioSamplingRate = 1;
			currentINI.S2TextFlag = 1;	
			currentINI.S2Source	= 6;
			
			currentINI.S3DataLengthB = 0;
			currentINI.S3AudioDataFlag = 2;	
			currentINI.S3AudioCodec = 0;
			currentINI.S3SBRFlag = 0;
			currentINI.S3AudioMode = 0;
			currentINI.S3AudioSamplingRate = 1;
			currentINI.S3TextFlag = 1;	
			currentINI.S3Source	= 6;	
		}
		else if(value == "9.4"){
			currentINI.S0DataLengthB = (lookUpTotalDataLength()/2)-96;
			currentINI.S0AudioDataFlag = 0;	
			currentINI.S0AudioCodec = 0;
			currentINI.S0SBRFlag = 1;
			currentINI.S0AudioMode = 1;
			currentINI.S0AudioSamplingRate = 3;
			currentINI.S0TextFlag = 1;	
			currentINI.S0Source	= 3;
			
			currentINI.S1DataLengthB = (lookUpTotalDataLength()/2)-96;
			currentINI.S1AudioDataFlag = 0;	
			currentINI.S1AudioCodec = 0;
			currentINI.S1SBRFlag = 1;
			currentINI.S1AudioMode = 1;
			currentINI.S1AudioSamplingRate = 3;
			currentINI.S1TextFlag = 1;	
			currentINI.S1Source	= 3;
			
			currentINI.S2DataLengthB = 192;
			currentINI.S2AudioDataFlag = 1;	
			currentINI.S2AudioCodec = 0;
			currentINI.S2SBRFlag = 0;
			currentINI.S2AudioMode = 0;
			currentINI.S2AudioSamplingRate = 1;
			currentINI.S2TextFlag = 1;	
			currentINI.S2Source	= 5;
			
			//clear other services
			currentINI.S3DataLengthB = 0;
			currentINI.S3AudioDataFlag = 2;	
			currentINI.S3AudioCodec = 0;
			currentINI.S3SBRFlag = 0;
			currentINI.S3AudioMode = 0;
			currentINI.S3AudioSamplingRate = 1;
			currentINI.S3TextFlag = 1;	
			currentINI.S3Source	= 6;	
		}
		else if(value == "9.5"){
			currentINI.S0DataLengthB = lookUpTotalDataLength()/2;
			currentINI.S0AudioDataFlag = 0;	
			currentINI.S0AudioCodec = 0;
			currentINI.S0SBRFlag = 1;
			currentINI.S0AudioMode = 1;
			currentINI.S0AudioSamplingRate = 3;
			currentINI.S0TextFlag = 1;	
			currentINI.S0Source	= 3;
			
			currentINI.S1DataLengthB = lookUpTotalDataLength()/4;
			currentINI.S1AudioDataFlag = 0;	
			currentINI.S1AudioCodec = 0;
			currentINI.S1SBRFlag = 1;
			currentINI.S1AudioMode = 0;
			currentINI.S1AudioSamplingRate = 3;
			currentINI.S1TextFlag = 1;	
			currentINI.S1Source	= 3;
			
			currentINI.S2DataLengthB = lookUpTotalDataLength()/4;
			currentINI.S2AudioDataFlag = 0;	
			currentINI.S2AudioCodec = 0;
			currentINI.S2SBRFlag = 1;
			currentINI.S2AudioMode = 0;
			currentINI.S2AudioSamplingRate = 3;
			currentINI.S2TextFlag = 1;	
			currentINI.S2Source	= 3;
			
			//clear other services
			currentINI.S3DataLengthB = 0;
			currentINI.S3AudioDataFlag = 2;	
			currentINI.S3AudioCodec = 0;
			currentINI.S3SBRFlag = 0;
			currentINI.S3AudioMode = 0;
			currentINI.S3AudioSamplingRate = 1;
			currentINI.S3TextFlag = 1;	
			currentINI.S3Source	= 6;	
		}
		else{
		}
		
		printSerivces();
		validator();
	}
}

//populates  service select
//************NEEDS TO CHECK
function populateServiceSelect(){
	
	if(currentINI.S0DataLengthA != 0 || currentINI.S1DataLengthA != 0 || currentINI.S2DataLengthA != 0 || currentINI.S3DataLengthA != 0){
		return;
	}
	else{
		var printSelect = "";
		
		if(lookUpTotalDataLength() >= 240 && lookUpTotalDataLength() <= 586){
			printSelect  += "<option value=\"1.1\">1 low quality mono audio service occupying complete MSC bandwidth</option>"; 
		}
		else if(lookUpTotalDataLength() >= 637 && lookUpTotalDataLength() <= 689){
			printSelect  += "<option value=\"2.1\">1 fair quality mono audio service occupying complete MSC bandwidth </option>"; 
		}
		else if(lookUpTotalDataLength() >= 718 && lookUpTotalDataLength() <= 820){
			printSelect  += "<option value=\"3.1\">1 good quality mono audio service occupying complete MSC bandwidth </option>"; 
		}
		else if(lookUpTotalDataLength() >= 826 && lookUpTotalDataLength() <= 984){
			printSelect  += "<option value=\"4.1\">1 good quality parametric stereo audio service occupying complete MSC bandwidth </option>"; 
		}
		else if(lookUpTotalDataLength() >= 1048 && lookUpTotalDataLength() <= 1206){
			printSelect  += "<option value=\"5.1\">1 good quality parametric stereo audio service occupying complete MSC bandwidth </option>"; 
			printSelect  += "<option value=\"5.2\">1 good quality parametric stereo audio service  with low bit rate slide show </option>";
			printSelect  += "<option value=\"5.3\">2 low quality mono audio services sharing total BW evenly </option>";
		}
		else if(lookUpTotalDataLength() >= 1237 && lookUpTotalDataLength() <= 1394){
			printSelect  += "<option value=\"6.1\">1 high quality parametric stereo audio service occupying complete MSC bandwidth </option>"; 
			printSelect  += "<option value=\"6.2\">1 high quality parametric stereo audio service  with low bit rate slide show </option>";
			printSelect  += "<option value=\"6.3\">1 good quality mono audio service  with medium bit rate slide show </option>";
			printSelect  += "<option value=\"6.4\">2 fair quality mono audio services sharing total BW evenly </option>";
		}
		else if(lookUpTotalDataLength() >= 1447 && lookUpTotalDataLength() <= 1738){
			printSelect  += "<option value=\"7.1\">1 high quality parametric stereo audio service occupying complete MSC bandwidth </option>"; 
			printSelect  += "<option value=\"7.2\">1 high quality parametric stereo audio service  with low bit rate slide show </option>";
			printSelect  += "<option value=\"7.3\">1 good quality mono audio service  with medium bit rate slide show </option>";
			printSelect  += "<option value=\"7.4\">1 good quality parametric stereo audio service  with one low quality mono audio service </option>";
			printSelect  += "<option value=\"7.5\">2 good quality mono audio services sharing total BW evenly </option>";
		}
		else if(lookUpTotalDataLength() >= 1788 && lookUpTotalDataLength() <= 2145){
			printSelect  += "<option value=\"8.1\">1 high quality parametric stereo audio service occupying complete MSC bandwidth </option>"; 
			printSelect  += "<option value=\"8.2\">1 high quality parametric stereo audio service  with medium bit rate slide show </option>";
			printSelect  += "<option value=\"8.3\">1 high quality parametric stereo audio service  with one low quality mono audio service</option>";
			printSelect  += "<option value=\"8.4\">2 good quality parametric stereo audio services sharing total BW evenly </option>";
		}
		else if(lookUpTotalDataLength() >= 2150 && lookUpTotalDataLength() <= 3600){
			printSelect  += "<option value=\"9.1\">1 high quality full stereo audio service occupying complete MSC bandwidth </option>"; 
			printSelect  += "<option value=\"9.2\">1 high quality parametric stereo audio service  with high bit rate slide show </option>";
			printSelect  += "<option value=\"9.3\">1 high quality parametric stereo audio service  with one high quality mono audio service</option>";
			printSelect  += "<option value=\"9.4\">2 good quality parametric stereo audio services sharing total BW evenly with low bit rate slide show</option>";
			printSelect  += "<option value=\"9.5\">1 high quality parametric stereo audio service with two low quality mono audio services</option>";
		}
		else{
			
		}
		document.getElementById("servicesSelect").innerHTML = printSelect;
	}
	


}

//decides what Audio settings options are presented
function audioSettingsLogic(BDF){
//AudioSettings controls four options which is :AudioCoding, SRBFlag, audioMode, and AudioSamplingRate; it has composit value of each options interger value combined.
	var audioSettingsArray = new Array();
	var i = 0;
	if(BDF >= 400 && BDF<= 699){
		//audioSettingsArray[i][0] = "0001";
		//audioSettingsArray[i][1] = "AAC 12kHz Mono";
		audioSettingsArray[i] = ["0001", "AAC 12kHz Mono"];
		i++;
	}
	if(BDF >= 611 && BDF<= 699){
		// audioSettingsArray[i][0] = "0101";
		// audioSettingsArray[i][1] = "AAC+ 12kHz Mono";
		audioSettingsArray[i] = ["0101", "AAC+ 12kHz Mono"];
		i++;
	}
	if(BDF >= 700 && BDF<= 999){
		// audioSettingsArray[i][0] = "0003";
		// audioSettingsArray[i][1] = "AAC 24kHz Mono";
		audioSettingsArray[i] = ["0003", "AAC 24kHz Mono"];
		i++;
	}
	if(BDF >= 700 && BDF<= 1824){
		// audioSettingsArray[i][0] = "0103";
		// audioSettingsArray[i][1] = "AAC+ 24kHz Mono";
		audioSettingsArray[i] = ["0103", "AAC+ 24kHz Mono"];
		i++;
	}
	if(BDF >= 824 && BDF<= 1824){
		// audioSettingsArray[i][0] = "0113";
		// audioSettingsArray[i][1] = "AAC+ 24kHz Para";
		audioSettingsArray[i] = ["0113", "AAC+ 24kHz Para"];
		i++;
	}
	if(BDF >= 1324 && BDF<= 3700){
		// audioSettingsArray[i][0] = "0123";
		// audioSettingsArray[i][1] = "AAC+ 24kHz Stereo";
		audioSettingsArray[i] = ["0123", "AAC+ 24kHz Stereo"];
		i++;
	}

	return audioSettingsArray;

}


function printAudioService(serviceNum){

	if(serviceNum == 0){
		var dataType = currentINI.S0AudioDataFlag;
		var collapseOne = "collapseOne";
		var S0 = "S0";
		var serviceLabel = currentINI.S0ServiceLabel;	
		var serviceIdentifer =currentINI.S0ServiceID;
			serviceIdentifer = serviceIdentifer.toString(16);
		var languageCode = currentINI.S0LanguageCode;	
		var countryCode = currentINI.S0CountryCode;
		var ServiceDesc = currentINI.S0ServiceDesc;
		var ServiceSource = currentINI.S0Source;
		var AudioFileName = currentINI.S0AudioFileName;
		//creates the composite AudioSettings variable
		var AudioSettingsVar = currentINI.S0AudioCodec.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S0SBRFlag.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S0AudioMode.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S0AudioSamplingRate.toString();
		var serviceBandwidth = currentINI.S0DataLengthB;
		var TextFlag = currentINI.S0TextFlag;
	}
	else if(serviceNum == 1){
		var dataType = currentINI.S1AudioDataFlag;
		var collapseOne = "collapseTwo";
		var S0 = "S1";
		var serviceLabel = currentINI.S1ServiceLabel;	
		var serviceIdentifer =currentINI.S1ServiceID;
			serviceIdentifer = serviceIdentifer.toString(16);
		var languageCode = currentINI.S1LanguageCode;	
		var countryCode = currentINI.S1CountryCode;
		var ServiceDesc = currentINI.S1ServiceDesc;
		var ServiceSource = currentINI.S1Source;
		var AudioFileName = currentINI.S1AudioFileName;
		//creates the composite AudioSettings variable
		var AudioSettingsVar = currentINI.S1AudioCodec.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S1SBRFlag.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S1AudioMode.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S1AudioSamplingRate.toString();
		var serviceBandwidth = currentINI.S1DataLengthB;
		var TextFlag = currentINI.S1TextFlag;
	}
	else if(serviceNum == 2){
		var dataType = currentINI.S2AudioDataFlag;
		var collapseOne = "collapseThree";
		var S0 = "S2";
		var serviceLabel = currentINI.S2ServiceLabel;	
		var serviceIdentifer =currentINI.S2ServiceID;
			serviceIdentifer = serviceIdentifer.toString(16);
		var languageCode = currentINI.S2LanguageCode;	
		var countryCode = currentINI.S2CountryCode;
		var ServiceDesc = currentINI.S2ServiceDesc;
		var ServiceSource = currentINI.S2Source;
		var AudioFileName = currentINI.S2AudioFileName;
		//creates the composite AudioSettings variable
		var AudioSettingsVar = currentINI.S2AudioCodec.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S2SBRFlag.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S2AudioMode.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S2AudioSamplingRate.toString();
		var serviceBandwidth = currentINI.S2DataLengthB;
		var TextFlag = currentINI.S2TextFlag;
	}
	else if(serviceNum == 3){
		var dataType = currentINI.S3AudioDataFlag;
		var collapseOne = "collapseFour";
		var S0 = "S3";
		var serviceLabel = currentINI.S3ServiceLabel;	
		var serviceIdentifer =currentINI.S3ServiceID;
			serviceIdentifer = serviceIdentifer.toString(16);
		var languageCode = currentINI.S3LanguageCode;	
		var countryCode = currentINI.S3CountryCode;
		var ServiceDesc = currentINI.S3ServiceDesc;
		var ServiceSource = currentINI.S3Source;
		var AudioFileName = currentINI.S3AudioFileName;
		//creates the composite AudioSettings variable
		var AudioSettingsVar = currentINI.S3AudioCodec.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S3SBRFlag.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S3AudioMode.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S3AudioSamplingRate.toString();
		var serviceBandwidth = currentINI.S3DataLengthB;
		var TextFlag = currentINI.S3TextFlag;
	}		

	var services=	"<div class=\"accordion-group\">";		
	services+=						"<div class=\"accordion-heading\">";

	services+=							"<a class=\"accordion-toggle\" data-toggle=\"collapse\" data-parent=\"#accordion4\" href=\"#"+collapseOne+"4\">";
	if(dataType == 0){
	services+= "Audio Service";
	}
	else if(dataType == 1){
	services+= "Data Service";
	}

	services+=                          "</a>";
	services+=							"</div>";
	services+=									"<div id=\""+collapseOne+"4\" class=\"accordion-body collapse in\">";
	services+=									  "<div class=\"accordion-inner\">";
	services+=									  "<div class=\"tabbable tabs-left\">";
	services+=									"<ul class=\"nav nav-tabs\" id=\"myTab0\">";
	services+=									  "<li class=\"active\"><a href=\"#"+S0+"ServiceLabelDiv\" onclick=\"change('"+S0+"ServiceLabelDiv')\"><i class=\"icon-tag\"></i> Service Label</a></li>";
	services+=									  "<li><a href=\"#"+S0+"ServiceIndentifierDiv\" onclick=\"change('"+S0+"ServiceIndentifierDiv')\"><i class=\"icon-eye-open\"></i> Service Identifier</a></li>";
	services+=									  "<li><a href=\"#"+S0+"LanguageDiv\" onclick=\"change('"+S0+"LanguageDiv')\"><i class=\"icon-group\"></i> Language</a></li>";
	services+=									  "<li><a href=\"#"+S0+"CountryCodeDiv\" onclick=\"change('"+S0+"CountryCodeDiv')\"><i class=\"icon-globe\"></i> Country Code</a></li>";
	services+=									  "<li><a href=\"#"+S0+"ServiceDescriptorDiv\" onclick=\"change('"+S0+"ServiceDescriptorDiv')\"><i class=\"icon-pencil\"></i> Service Descriptor</a></li>";
	services+=									  "<li><a href=\"#"+S0+"SourceDiv\" onclick=\"change('"+S0+"SourceDiv')\"><i class=\"icon-music\"></i> Source</a></li>";
	if(dataType == 0){
	services+=									  "<li><a href=\"#"+S0+"AudioSettingsDiv\" onclick=\"change('"+S0+"AudioSettingsDiv')\"><i class=\"icon-wrench\"></i> Audio Settings</a></li>";
	services+=									  "<li><a href=\"#"+S0+"textFlagDiv\" onclick=\"change('"+S0+"textFlagDiv')\"><i class=\"icon-mobile-phone\"></i> Text Messages</a></li>";
	}
	services+=									"</ul>";
				 
	services+=								"<div class=\"tab-content\">";
			
	services+=											  "<div class=\"tab-pane active\" id=\""+S0+"ServiceLabelDiv\">";
	services+=												"<div class=\"span5 well well-small\">";
	services+=													"<dl>";
	services+=													  "<dt>Service Label</dt>";
	services+=													  "<dd> The name you want displayed for this service. Maximum 16 letters or Characters. </dd>";
	services+=													"</dl>";
	services+=												"</div>";
	services+=												"<div class=\"span5 offset1\" >";
	services+=													"<div class=\"page-header\">";
	services+=													"<h5>Service Label:</h5>";
	services+=													"</div>";
	services+=													"<div id=\""+S0+"ServiceLabelAlert\">";
	services+=													"</div>";
	services+=													  "<input type=\"text\" name=\""+S0+"ServiceLabel\" class=\"span11\"  value=\""+serviceLabel+"\" placeholder=\""+serviceLabel+"\" id=\""+S0+"ServiceLabel\" onchange=\"logic(this.name, this.value)\">";
	services+=												"</div>";	
	services+=											  "</div>";

	services+=											  "<div class=\"tab-pane\" id=\""+S0+"ServiceIndentifierDiv\">";
	services+=												"<div class=\"span5 well well-small\">";
	services+=													"<dl>";
	services+=													  "<dt>Service Indentifier</dt>";
	services+=													  "<dd> Unique ID, which is a whole number. </dd>";
	services+=													"</dl>";
	services+=												"</div>";
	services+=												"<div class=\"span5 offset1\" >";
	services+=													"<div class=\"page-header\">";
	services+=													"<h5>Service Identifer:</h5>";
	services+=													"</div>";
	services+=													"<div id=\""+S0+"ServiceIDAlert\">";
	services+=													"</div>";
	services+=													  "<input type=\"text\" name=\""+S0+"ServiceIdentifer\" class=\"span11\" value=\""+serviceIdentifer+"\"  placeholder=\""+serviceIdentifer+"\" id=\""+S0+"ServiceID\" onchange=\"logic(this.name, this.value)\">";
	services+=												"</div>";	
	services+=											  "</div>";
	 
	services+=											  "<div class=\"tab-pane\" id=\""+S0+"LanguageDiv\">";
	services+=												"<div class=\"span5 well well-small\">";
	services+=													"<dl>";
	services+=													  "<dt>Language</dt>";
	services+=													  "<dd> Select the language the serivce is in. </dd>";
	services+=													"</dl>";
	services+=												"</div>";
	services+=												"<div class=\"span5 offset1\" >";
	services+=													"<div class=\"page-header\">";
	services+=													"<h5>Language:</h5>";
	services+=													"</div>";
	services+=													"<div id=\""+S0+"LanguageAlert\">";
	services+=													"</div>";
	services+=													  "<select id=\""+S0+"Language\" name=\""+S0+"Language\" onclick=\"logic(this.name, this.value)\">";
																	for(var i=0; i<languageCodesArray.length; i++){
																		if(languageCode == languageCodesArray[i][0]){
																			services+="<option value=\""+languageCodesArray[i][0]+"\" selected>"+languageCodesArray[i][1]+"</option>";
																		}
																		else{
																			services+="<option value=\""+languageCodesArray[i][0]+"\">"+languageCodesArray[i][1]+"</option>";
																		}
																	
																	}
	services+=														"</select>"; 

	services+=												"</div>";
	services+=											  "</div>";
	services+=											  "<div class=\"tab-pane\" id=\""+S0+"CountryCodeDiv\">";
	services+=												"<div class=\"span5 well well-small\">";
	services+=													"<dl>";
	services+=													  "<dt>Country Code</dt>";
	services+=													  "<dd> Select the Country Code for where your broadcast is. </dd>";
	services+=													"</dl>";
	services+=												"</div>";
	services+=												"<div class=\"span5 offset1\" >";
	services+=													"<div class=\"page-header\">";
	services+=													"<h5>Country Code:</h5>";
	services+=													"</div>";
	services+=													"<div id=\""+S0+"CountrycodeAlert\">";
	services+=													"</div>"
	services+=													  "<select id=\""+S0+"CountryCode\" name=\""+S0+"CountryCode\" onclick=\"logic(this.name, this.value)\">";
																for(var i=0; i<countryCodeArray.length; i++){
																		if(countryCode == countryCodeArray[i][0]){
																			services+="<option value=\""+countryCodeArray[i][0]+"\" selected>"+countryCodeArray[i][1]+"</option>";
																		}
																		else{
																			services+="<option value=\""+countryCodeArray[i][0]+"\">"+countryCodeArray[i][1]+"</option>";
																		}
																	
																	}
	services+=													  "</select>";
	services+=												"</div>";	  
	services+=											  "</div>";
	services+=											  "<div class=\"tab-pane\" id=\""+S0+"ServiceDescriptorDiv\">";
	services+=												"<div class=\"span5 well well-small\">";
	services+=													"<dl>";
	services+=													  "<dt>Service Descriptor</dt>";
	services+=													  "<dd> Select the description that best describes your programing. </dd>";
	services+=													"</dl>";
	services+=												"</div>";
	services+=												"<div class=\"span5 offset1\" >";
	services+=													"<div class=\"page-header\">";
	services+=													"<h5>Service Descriptor:</h5>";
	services+=													"</div>";
	services+=													"<div id=\""+S0+"ServiceDescriptorAlert\">";
	services+=													"</div>";
	services+=													  "<select id=\""+S0+"ServiceDesc\" name=\""+S0+"ServiceDesc\" onclick=\"logic(this.name, this.value)\">";
																	for(var i=0; i<ServiceDescArray.length; i++){
																		if(ServiceDesc == ServiceDescArray[i][0]){
																			services+="<option value=\""+ServiceDescArray[i][0]+"\" selected>"+ServiceDescArray[i][1]+"</option>";
																		}
																		else{
																			services+="<option value=\""+ServiceDescArray[i][0]+"\">"+ServiceDescArray[i][1]+"</option>";
																		}
																	
																	}

	services+=													  "</select>";
	services+=												"</div>";
	services+=											  "</div>";

	if(dataType == 0){

		services+=											  "<div class=\"tab-pane\" id=\""+S0+"SourceDiv\">";
		services+=												"<div class=\"span5 well well-small\">";
		services+=													"<dl>";
		services+=													  "<dt>Source</dt>";
		services+=													  "<dd> Location from which your audio is coming from. </dd>";
		services+=													"</dl>";
		services+=												"</div>";
		services+=												"<div class=\"span5 offset1\" >";
		services+=													"<div class=\"page-header\">";
		services+=													"<h5>Source:</h5>";
		services+=													"</div>";
		services+=													"<div id=\""+S0+"SourceAlert\">";
		services+=													"</div>";
		services+=													"<label class=\"radio\" rel=\"tooltip\">";
		services+=													 "<input type=\"radio\" name=\""+S0+"Source\" id=\""+S0+"Source2\" value=\"2\" onclick=\"logic(this.name, this.value)\"";

																	if(ServiceSource == "2"){
																		services+="checked>";
																	}
																	else{
																		services+=">";
																	}
		services+=														"Wave File";
		services+=													"</label>";
		services+=													"<input type=\"text\" name=\""+S0+"AudioFilename\" value=\""+AudioFileName+"\"  class=\"span11\" placeholder=\""+AudioFileName+"\" id=\""+S0+"AudioFilename\" onclick=\"logic(this.name, this.value)\">";
		services+=													"<label class=\"radio\" rel=\"tooltip\">"
		services+=													 "<input type=\"radio\" name=\""+S0+"Source\" id=\""+S0+"Source3\" value=\"3\" onclick=\"logic(this.name, this.value)\"";
																	if(ServiceSource == "3"){
																		services+="checked>";
																	}
																	else{
																		services+=">";
																	}
		services+=														"Audio Input";
		services+=													"</label>";
		services+=													"<select id=\""+S0+"AudioFilenameLive\" name=\""+S0+"AudioFilename\" onclick=\"logic(this.name, this.value)\">";

																	for(var i=0; i< liveAudioList.length; i++){
																			if(AudioFileName == liveAudioList[i]){
																				services+="<option value=\""+liveAudioList[i]+"\" selected>"+liveAudioList[i]+"</option>";
																			}
																			else{
																				services+="<option value=\""+liveAudioList[i]+"\">"+liveAudioList[i]+"</option>";
																			}
																		
																		}	
														
		services+=													"</select>";
		services+=												"</div>";
		services+=											  "</div>";
		services+=											  "<div class=\"tab-pane\" id=\""+S0+"AudioSettingsDiv\">";
		services+=												"<div class=\"span5 well well-small\">";
		services+=													"<dl>";
		services+=													  "<dt>Audio Settings</dt>";
		services+=													  "<dd> Select the Audio Setting you want. </dd>";
		services+=													"</dl>";
		services+=												"</div>";
		services+=												"<div class=\"span5 offset1\" >";
		services+=													"<div class=\"page-header\">";
		services+=													"<h5>Audio Setting:</h5>";
		services+=													"</div>";
		services+=													"<div id=\""+S0+"AudioSettingAlert\">";
		services+=													"</div>"
		services+=													  "<select id=\""+S0+"AudioSetting\" name=\""+S0+"AudioSettings\" onclick=\"logic(this.name, this.value)\">";
																	var audioSettingsArray = audioSettingsLogic(serviceBandwidth);
																	for(var i = 0; i < audioSettingsArray.length; i++){
																		if(audioSettingsArray[i][0] == AudioSettingsVar){
																			services+="<option value=\""+audioSettingsArray[i][0]+"\" selected>"+audioSettingsArray[i][1]+"</option>";
																		}
																		else{
																			services+="<option value=\""+audioSettingsArray[i][0]+"\">"+audioSettingsArray[i][1]+"</option>";
																		}
																	}

		services+=													  "</select>";
		services+=												"</div>";
		services+=											  "</div>";
		services+=											  "<div class=\"tab-pane\" id=\""+S0+"textFlagDiv\">";
		services+=												"<div class=\"span5 well well-small\">";
		services+=													"<dl>";
		services+=													  "<dt>Text Message</dt>";
		services+=													  "<dd> Selects if one wants text message with audio. </dd>";
		services+=													"</dl>";
		services+=												"</div>";
		services+=												"<div class=\"span5 offset1\" >";
		services+=													"<div class=\"page-header\">";
		services+=													"<h5>Text Message:</h5>";
		services+=													"</div>";
		services+=													"<div id=\""+S0+"SourceAlert\">";
		services+=													"</div>";
		services+=													"<label class=\"radio\" rel=\"tooltip\">";
		services+=													 "<input type=\"radio\" name=\""+S0+"TextFlag\" id=\""+S0+"TextFlag0\" value=\"0\" onclick=\"logic(this.name, this.value)\"";
																	if(TextFlag == 0){
																	services+= "checked>";
																	}
																	else{
																	services+= ">";
																	}
		services+=														"Text message not included with audio stream";
		services+=													"</label>";
														
		services+=													"<label class=\"radio\" rel=\"tooltip\">";
		services+=													 "<input type=\"radio\" name=\""+S0+"TextFlag\" id=\""+S0+"TextFlag1\" value=\"1\" onclick=\"logic(this.name, this.value)\"";
																	if(TextFlag == 1){
																	services+= "checked>";
																	}
																	else{
																	services+= ">";
																	}
		services+=														"Text message included with audio stream";
		services+=													"</label>";
												
		services+=												"</div>";
		services+=											  "</div>";
		services+=											"</div>";
		services+=									  "</div>";
		services+=									  "</div>";
		services+=									"</div>";
		services+=								  "</div>";
	}

	else if(dataType == 1){

		services+=												"<div class=\"tab-pane\" id=\""+S0+"SourceDiv\">";
		services+=												"<div class=\"span5 well well-small\">";
		services+=													"<dl>";
		services+=													  "<dt>Source</dt>";
		services+=													  "<dd> Name of you data file. </dd>";
		services+=													"</dl>";
		services+=												"</div>";
		services+=												"<div class=\"span5 offset1\" >";
		services+=													"<div class=\"page-header\">";
		services+=													"<h5>Source:</h5>";
		services+=													"</div>";
		services+=													"<div id=\""+S0+"SourceAlert\">";
		services+=													"</div>";
															
		services+=													"<input type=\"text\" name=\""+S0+"AudioFilename\"  value=\""+AudioFileName+"\" class=\"span11\" placeholder=\""+AudioFileName+"\" id=\""+S0+"AudioFilename\" onclick=\"logic(this.name, this.value)\">";
															
															
		services+=												"</div>";
		services+=											  "</div>";
		services+=											 "</div>";
		services+=									  "</div>";
		services+=									  "</div>";
		services+=									"</div>";
		services+=								  "</div>";

	}
	return services;
}