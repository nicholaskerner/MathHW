<?php

class Dislay{
	protected $VUMeter;
	protected $Timing;
	protected $Clocktime;
	
	//LEFT OFF HERE
	public function Display(){
	 setVUMeter(null);
	 
	
	}
	
	public function setVUMeter($temp){
		if($temp == 0 || $temp == 1 || $temp == null){
			$VUMeter = $temp; 
		}
		else{
			throw new Exception('Invalid, value for VUMeter.');
		}
	}
	
	public function getVUMeter(){
		return $VUMeter;
	}
	
	public function setTiming($temp){
		if($temp == 0 || $temp == 1 || $temp == null){
			$Timing = $temp; 
		}
		else{
			throw new Exception('Invalid, value for Timing.');
		}
	}
	
	public function getTiming(){
		return $Timing;
	}

	public function setClocktime($temp){
		if($temp == 0 || $temp == 1 || $temp == null){
			$Timing = $temp; 
		}
		else{
			throw new Exception('Invalid, value for Clocktime.');
		}
	}
	
	public function getClocktime(){
		return $Clocktime;
	}



}














?>