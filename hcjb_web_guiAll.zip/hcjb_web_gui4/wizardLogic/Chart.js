function genChart(){
$(function () {
        $('#chartContainer').highcharts({
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false
            },
            title: {
                text: ''
            },
            tooltip: {
        	    pointFormat: '{series.name}: <b>{point.percentage}%</b>',
            	percentageDecimals: 1
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        color: '#000000',
                        connectorColor: '#000000',
                        formatter: function() {
                        }
                    }
                }
            },
            series: [{
                type: 'pie',
                name: 'Bandwidth',
                data: chartData()
            }]
        });
    });
    

 
}

function chartData(){
	var audioNum = 1;
	var dataNum = 1;
	var service0 = "Illogical";
	var service1 = "Illogical";
	var service2 = "Illogical";
	var service3 = "Illogical";
	//document.getElementById("testing").innerHTML = "AudioDataFlag: "+currentINI.S0AudioDataFlag+"";
	if(currentINI.S0AudioDataFlag == 0){
		service0 = "Audio ";
		service0 += audioNum.toString()+"/"+currentINI.S0ServiceLabel;
		audioNum++;
	}
	if(currentINI.S0AudioDataFlag == 1){
		service0 = "Data/Slide Show "+audioNum+"/"+currentINI.S0ServiceLabel;
		dataNum++;
	}
	if(currentINI.S1AudioDataFlag == 0){
		service1 = "Audio "+audioNum+"/"+currentINI.S1ServiceLabel;
		audioNum++;
	}
	if(currentINI.S1AudioDataFlag == 1){
		service1 = "Data/Slide Show "+audioNum+"/"+currentINI.S1ServiceLabel;
		dataNum++;
	}
	if(currentINI.S2AudioDataFlag == 0){
		service2 = "Audio "+audioNum+"/"+currentINI.S2ServiceLabel;
		audioNum++;
	}
	if(currentINI.S2AudioDataFlag == 1){
		service2 = "Data/Slide Show "+audioNum+"/"+currentINI.S2ServiceLabel;
		dataNum++;
	}
	if(currentINI.S3AudioDataFlag == 0){
		service3 = "Audio "+audioNum+"/"+currentINI.S3ServiceLabel;
		audioNum++;
	}
	if(currentINI.S3AudioDataFlag == 1){
		service3 = "Data/Slide Show "+audioNum+"/"+currentINI.S3ServiceLabel;
		dataNum++;
	}
	
	
	var temp = new Array([service0, Number(currentINI.S0DataLengthB)],[service1, Number(currentINI.S1DataLengthB)], [service2, Number(currentINI.S2DataLengthB)],[service3, Number(currentINI.S3DataLengthB)]);
	

return temp;






}