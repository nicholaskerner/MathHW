function validator(){
	if(currentINI.S0DataLengthA == 0 || currentINI.S1DataLengthA == 0 || currentINI.S2DataLengthA == 0 || currentINI.S3DataLengthA == 0){
		currentErrors.clearErrorList();
		configurationDescriptionVal();
		robustnessVal();
		spectrumOccVal();
		interLeaverDepthFlag();
		mscModeVal();
		sdcModeVal();
		baseEnhancementFlagVal();
		protBIntVal();
		//protectionPartBVal();
		amDrmVal();
		dataLengthPartBVal();
		lookUpTotalDataLength();
		serviceLabelVal();
		serviceIdentifierVal();
		CASystemVal();
		languageCodeVal();
		countryCodeVal();
		audioDataFlagVal();
		serviceDescriptorVal();
		audioSettingsVal();
		audioFileNameVal();
		ipVal();
		ffVal();
		pftVal();
		isValid();
		genChart();
	}	
}

function isValid(){
	var printout = "";
	if(currentErrors.isEmpty() == true){
		
			 printout += "<div class=\"btn-group\"><button class=\"btn btn-success\" onclick=\"saveObject()\" type=\"button\"><i class=\"icon-save\"></i> Save</button><button class=\"btn btn-warning\" onclick=\"loadActivateModal()\" type=\"button\"><i class=\" icon-ok\"></i>Activate</button></div><div class=\"btn-group\"><button class=\"btn btn-primary\" onclick=\"window.location = 'file.php'\"> <i class=\"icon-home\"></i> Back to File Page</button>					<button class=\"btn btn-primary\" onclick=\"logOut()\"> <i class=\"icon-signout\"></i> signout</button> </div></div>";
			document.getElementById("activateAndSave").innerHTML = printout;
	}
	else{
		printout +="<div class=\"btn-group\"><button class=\"btn btn-success\" onclick=\"saveObject()\" type=\"button\"  disabled><i class=\"icon-save\"></i> Save</button><button class=\"btn btn-warning\" onclick=\"loadActivateModal()\" type=\"button\"  disabled><i class=\" icon-ok\"></i>Activate</button></div><div class=\"btn-group\"><button class=\"btn btn-primary\" onclick=\"window.location = 'file.php'\"> <i class=\"icon-home\"></i> Back to File Page</button>					<button class=\"btn btn-primary\" onclick=\"logOut()\"> <i class=\"icon-signout\"></i> signout</button> </div></div>";
		document.getElementById("activateAndSave").innerHTML = printout;
	}
}
//**********************************************************************//
//******VERY IMPORTANT FUNCTION*****************************************//
//BLOWS AWAY ADVANCED USER MODE SETTINGS
function advancedSettingsNuke(){
	currentINI.MSCMode = null;
	currentINI.ProAInt = 0;
	currentINI.ProBInt = 0;
	currentINI.ProtLevelForHierarchical = 0;
	currentINI.HierarchicalBytes = 0;
	currentINI.S0DataLengthA = 0;
	currentINI.S1DataLengthA = 0;
	currentINI.S2DataLengthA = 0;
	currentINI.S3DataLengthA = 0;
	currentINI.S0DataLengthB = 0;
	currentINI.S1DataLengthB = 0;
	currentINI.S2DataLengthB = 0;
	currentINI.S3DataLengthB = 0;

}

//Validated configuration Description
function configurationDescriptionVal(){
	if(currentINI.ConfigurationDesc.length >255){
		//message to be displayed
		var alertMessage = "<div class=\"alert alert-error\">";
              alertMessage += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>";
              alertMessage += "<strong>Oh No!</strong> Your description is to long. Please try shortning.";
           alertMessage += "</div>";
		 //prints message to page 
		document.getElementById("ConfigurationDescriptionAlert").innerHTML = alertMessage;
		//add to error list
		currentErrors.addHardError(101, "Configuration Description to long");
	}
	else if(currentINI.ConfigurationDesc == null){
		currentINI.ConfigurationDesc = "";
	}
	else{
		document.getElementById("ConfigurationDescriptionAlert").innerHTML = "";
	}
	

}

//Validates Robustness
function robustnessVal(){
	//Checks for constraints
	if( (currentINI.Robustness == 2 || currentINI.Robustness == 3) && ( currentINI.SpectrumOcc != 3 && currentINI.SpectrumOcc != 5)){
		//message to be displayed
		var alertMessage = "<div class=\"alert alert-error\">";
              alertMessage += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>";
              alertMessage += "<strong>Oh No!</strong> Your Robustness setting is conflicting with your Spectrum Occupancy. To fix this select a Spectrum Occupancy of 10kHz or 20kHz.<a href=\"#\" onclick=\"change(102)\">Click here to go Spectrum Occupancy and fix it.</a>";
           alertMessage += "</div>";
		   
		 //prints message to page 
		document.getElementById("RobustAlert").innerHTML = alertMessage;
		
		//add to error list
		currentErrors.addHardError("103", "Robustness Conflict");
	
	}
	//Checks if not selected
	else if(currentINI.Robustness != 0 && currentINI.Robustness != 1 && currentINI.Robustness != 2 && currentINI.Robustness != 3){
		//add to error list
		currentErrors.addSoftError(103, "Robustness");
		document.getElementById("RobustAlert").innerHTML = "";
	}
	else if(currentINI.Robustness < 0){
		currentErrors.addSoftError(103, "Robustness");
	}
	else{
		document.getElementById("RobustAlert").innerHTML = "";
	}

}

//Validate Spectrum Occupancy
function spectrumOccVal(){
	//checks constraints
	if( (currentINI.Robustness != 0 && currentINI.Robustness != 1) && ( currentINI.SpectrumOcc == 0 || currentINI.SpectrumOcc == 1 || currentINI.SpectrumOcc == 2 || currentINI.SpectrumOcc == 4)){
		//message to be displayed
		var alertMessage = "<div class=\"alert alert-error\">";
              alertMessage += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>";
              alertMessage += "<strong>Oh No!</strong> Your Spectrum Occupancy setting is conflicting with your Robustness. To fix this select a Robustness of A 5% or B 20%.<a href=\"#\" onclick=\"change(103)\">Click here to  go Robustness and fix it.</a>";
           alertMessage += "</div>";
		   
		 //prints message to page 
		document.getElementById("SOAlert").innerHTML = alertMessage;
		
		//add to error list
		currentErrors.addHardError(102, "Spectrum Occupancy Conflict");
	
	}
	
	//checks if selected
	else if(currentINI.SpectrumOcc != 0 && currentINI.SpectrumOcc != 1 && currentINI.SpectrumOcc != 2 && currentINI.SpectrumOcc != 3 && currentINI.SpectrumOcc != 4 && currentINI.SpectrumOcc != 5){
		//add to error list
		currentErrors.addSoftError(102, "Spectrum");
		document.getElementById("SOAlert").innerHTML = "";
	}
	else if(currentINI.SpectrumOcc <0){
		currentErrors.addSoftError(102, "Robustness");
	}
	else{
		document.getElementById("SOAlert").innerHTML = "";
	}

}

//validate Interleaver Depth Flag
function interLeaverDepthFlag(){
	if (currentINI.InterleaverDepth != 0 && currentINI.InterleaverDepth != 1){
		//add to error list
		currentErrors.addSoftError(104, "Interleaver Depth");
	
	}
	else if(currentINI.InterleaverDepth < 0){
		currentErrors.addSoftError(104, "Interleaver Depth");
	}
}

//Validate MSC Mode
function mscModeVal(){
	var temp = currentINI.ProtBInt;
	var alertMessage ="";
	if(currentINI.MSCMode < 0){
		currentErrors.addSoftError(105, "MSC Mode");
	}
	else if(currentINI.MSCMode == 0){
							
		alertMessage+="		<label class=\"radio\" rel=\"tooltip\" data-placement=\"left\" title=\"strong\"><input type=\"radio\" name=\"ProtBInt\" id=\"optionsProtBInt0\" value=\"0\" onclick=\"logic(this.name, this.value)\"";
		if(temp == 0){
			alertMessage+=" checked>";
		}
		else{
			alertMessage+=" >";
		}		 		 
		alertMessage+="	0.50</label><label class=\"radio\" rel=\"tooltip\"> <input type=\"radio\" name=\"ProtBInt\" id=\"optionsProtbInt1\" value=\"1\" onclick=\"logic(this.name, this.value)\"";
		if(temp == 1){
			alertMessage+=" checked>";
		}
		else{
			alertMessage+=" >";
		}		 	 
		alertMessage+="	0.60</label>";
		
		alertMessage+="<label class=\"radio\" rel=\"tooltip\"><input type=\"radio\" name=\"ProtBInt\" id=\"optionsProtBInt2\" value=\"2\" onclick=\"logic(this.name, this.value)\"";
		if(temp == 2){
			alertMessage+=" checked>";
		}
		else{
			alertMessage+=" >";
		}		 		 
		alertMessage+="	0.71</label><label class=\"radio\" rel=\"tooltip\" data-placement=\"left\" title=\"weak\"><input type=\"radio\" name=\"ProtBInt\" id=\"optionsProtbInt3\" value=\"3\" onclick=\"logic(this.name, this.value)\"";
		if(temp == 3){
			alertMessage+=" checked>";
		}
		else{
			alertMessage+=" >";
		}		 	 
		alertMessage+="	0.78</label>";
	}
	else if(currentINI.MSCMode == 3){
		alertMessage+="<label class=\"radio\" rel=\"tooltip\" data-placement=\"left\" title=\"strong\"><input type=\"radio\" name=\"ProtBInt\" id=\"optionsProtBInt0\" value=\"0\" onclick=\"logic(this.name, this.value)\"";
		if(temp == 0){
			alertMessage+=" checked>";
		}
		else{
			alertMessage+=" >";
		}		 		 
		alertMessage+="	0.50</label><label class=\"radio\" rel=\"tooltip\" data-placement=\"left\" title=\"weak\"><input type=\"radio\" name=\"ProtBInt\" id=\"optionsProtbInt1\" value=\"1\" onclick=\"logic(this.name, this.value)\"";
		if(temp == 1){
			alertMessage+=" checked>";
		}
		else{
			alertMessage+=" >";
		}		 	 
		alertMessage+="	0.62</label>";

	}
	else if (currentINI.MSCMode == 1 || currentINI.MSCMode == 2 ){
		alertMessage+="<div class=\"alert alert-info\">"; 
		alertMessage+=	"<button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>";
		alertMessage+=	"<strong>Heads up!</strong>"
		alertMessage+=	" This parameter has a value that is no longer supported. To change Protection Level please select a valid<a href=\"#\" onclick=\"change(105)\">MSC Mode.</a></div>";
		
	}
	else{
		currentErrors.addSoftError(105, "MSC Mode");
		alertMessage+="<div class=\"alert alert-info\">"; 
		alertMessage+=	"<button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>";
		alertMessage+=	"<strong>Heads up!</strong>"
		alertMessage+=	" This parameter is dependent on the MSC Mode. To change Protection Level please select a valid<a href=\"#\" onclick=\"change(105)\">MSC Mode.</a></div>";
	
	}
	
	document.getElementById("ProtLevelOptions").innerHTML = alertMessage;
}

//validate  SDC Mode
function sdcModeVal(){
	if(currentINI.SDCMode != 0 && currentINI.SDCMode != 1){
		currentErrors.addSoftError(106, "SDC Mode");
	}
}

//validates BaseEnhancementFlag
function baseEnhancementFlagVal(){
	
	if(currentINI.BaseEnhancementFlag != 0 || currentINI.BaseEnhancementFlag != 1){
		currentINI.BaseEnhancementFlag = 0;
	}
}

//validate Protection Levels ***Dont Call if part protection A is not 0******
function protBIntVal(){
	if(currentINI.ProtBInt  < 0){
		currentErrors.addSoftError(107, "Protection Level");
	}
	if(currentINI.MSCMode == 0 && (currentINI.ProtBInt != 0 && currentINI.ProtBInt != 1 && currentINI.ProtBInt != 2 && currentINI.ProtBInt != 3)){
		currentErrors.addSoftError(107, "Protection Level");
	}
	if(currentINI.MSCMode == 3 && currentINI.ProtBInt != 0 && currentINI.ProtBInt != 1){
		currentErrors.addSoftError(107, "Protection Level");
	}
}

//validate AmDrm
function amDrmVal(){
	if(currentINI.AmDrm != 0 || currentINI.AmDrm != 1 || currentINI.AmDrm != 2 || currentINI.AmDrm != 3 || currentINI.AmDrm != 4 || currentINI.AmDrm != 5 || currentINI.AmDrm != 6){
		currentINI.AmDrm = 0;
	}
}

//validate Data Length for part B
//************DONT VALIDATE IF PART A IS NOT 0******
function dataLengthPartBVal(){
	var sumOfDataLengths = Number(currentINI.S0DataLengthB);
		sumOfDataLengths += Number(currentINI.S1DataLengthB);
		sumOfDataLengths += Number(currentINI.S2DataLengthB);
		sumOfDataLengths += Number(currentINI.S3DataLengthB);

	var totalDataAvailable = lookUpTotalDataLength();
	if(totalDataAvailable === undefined){
		return;
	}
	
	if(sumOfDataLengths > totalDataAvailable){
		currentINI.S0DataLengthB = 0;
		currentINI.S1DataLengthB = 0;
		currentINI.S2DataLengthB = 0;
		currentINI.S3DataLengthB = 0;
		//calls services select
		populateServiceSelect();
		currentErrors.addHardError(201, "Your Service Options have changed. Please select a new one.");
		document.getElementById("servicetabs").innerHTML = "";
	}
	if(totalDataAvailable != currentINI.OldTotalDataLength){
		populateServiceSelect();
		currentINI.OldTotalDataLength = totalDataAvailable;
	}
	if(sumOfDataLengths == 0){
		currentErrors.addSoftError(201, "Services");
	}

}
//helper function for dataLengthPartBVal
function lookUpTotalDataLength(){
	var lookUpIndex = 0;
	
	if(currentINI.Robustness <0 || currentINI.SpectrumOcc <0 || currentINI.MSCMode < 0 || currentINI.ProtBInt < 0){
		return null;
	}
	
	//setting rubust value
	if(currentINI.Robustness == 0){
		lookUpIndex += 0;
	}
	else if(currentINI.Robustness == 1){
		lookUpIndex += 36;
	}
	else if(currentINI.Robustness == 2){
		lookUpIndex += 72;
	}
	else if(currentINI.Robustness == 3){
		lookUpIndex += 83;
	}
	else{
		return;
	}
	
	//seting spectrumOcc value
	if(currentINI.Robustness == 0 || currentINI.Robustness == 1){
		
		if(currentINI.SpectrumOcc == 0){
				lookUpIndex += 0;
		}
		else if(currentINI.SpectrumOcc == 1){
				lookUpIndex += 6;
		}
		else if(currentINI.SpectrumOcc == 2){
				lookUpIndex += 12;
		}
		else if(currentINI.SpectrumOcc == 3){
				lookUpIndex += 18;
		}
		else if(currentINI.SpectrumOcc == 4){
				lookUpIndex += 24;
		}
		else if(currentINI.SpectrumOcc == 5){
				lookUpIndex += 30;
		}
		else{
			return null;
		}
	}
	else{
		if(currentINI.SpectrumOcc == 3){
				lookUpIndex += 0;
		}
		else if(currentINI.SpectrumOcc == 5){
				lookUpIndex += 6;
		}
		else{
			return null;
		}
	}
	
	//setting QAM
	if(currentINI.MSCMode == 3){
		lookUpIndex += 0;
	}
	else if(currentINI.MSCMode == 0){
		lookUpIndex += 2;
	}
	else{
	 return null;
	}
	
	if(currentINI.ProtBInt == 0 || currentINI.ProtBInt == 1 || currentINI.ProtBInt == 2 || currentINI.ProtBInt == 3){
		lookUpIndex += Number(currentINI.ProtBInt);
		lookUpIndex += 1;	
	}
	else{
		return null;
	}	
	
	return bytesPerFrame[lookUpIndex];

}


//validate service labels
function serviceLabelVal(){
	if(currentINI.S0DataLengthB > 0 && currentINI.S0ServiceLabel.length > 64){
			currentErrors.addHardError("S0ServiceLabelDiv", "Shorten Service Label");
			var alertMessage = "<div class=\"alert alert-error\">";
              alertMessage += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>";
              alertMessage += "<strong>Oh No!</strong> Your Service Label is to long.</a>";
           alertMessage += "</div>";
		document.getElementById("S0ServiceLabel").innerHTML = alertMessage;
	}
	else if(currentINI.S1DataLengthB > 0 && currentINI.S1ServiceLabel.length > 64){
			currentErrors.addHardError("S1ServiceLabelDiv", "Shorten Service Label");
			var alertMessage = "<div class=\"alert alert-error\">";
              alertMessage += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>";
              alertMessage += "<strong>Oh No!</strong> Your Service Label is to long.</a>";
           alertMessage += "</div>";
		document.getElementById("S1ServiceLabel").innerHTML = alertMessage;
	}
	else if(currentINI.S2DataLengthB > 0 && currentINI.S2ServiceLabel.length > 64){
			currentErrors.addHardError("S2ServiceLabelDiv", "Shorten Service Label");
			var alertMessage = "<div class=\"alert alert-error\">";
              alertMessage += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>";
              alertMessage += "<strong>Oh No!</strong> Your Service Label is to long.</a>";
           alertMessage += "</div>";
		document.getElementById("S2ServiceLabel").innerHTML = alertMessage;
	}
	else if(currentINI.S3DataLengthB > 0 && currentINI.S3ServiceLabel.length > 64){
			currentErrors.addHardError("S3ServiceLabelDiv", "Shorten Service Label");
			var alertMessage = "<div class=\"alert alert-error\">";
              alertMessage += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>";
              alertMessage += "<strong>Oh No!</strong> Your Service Label is to long.</a>";
           alertMessage += "</div>";
		document.getElementById("S3ServiceLabel").innerHTML = alertMessage;
	}
	else{}

}

//validate service identifier
function serviceIdentifierVal(){
	if(currentINI.S0DataLengthB > 0 && currentINI.S0ServiceID <= 16777216){
		if(currentINI.S0ServiceID == 0){
			currentErrors.addSoftError("S0ServiceIndentifierDiv", "Service Indentifier");
		}
		
	}
	else if(currentINI.S0DataLengthB > 0 && currentINI.S0ServiceID > 16777216){
			currentErrors.addHardError("S0ServiceIndentifierDiv", "Shorten Indentifier Label");
			var alertMessage = "<div class=\"alert alert-error\">";
              alertMessage += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>";
              alertMessage += "<strong>Oh No!</strong> Your Service Label is to long.</a>";
			alertMessage += "</div>";
		document.getElementById("S0ServiceID").innerHTML = alertMessage;
	}
	
	if(currentINI.S1DataLengthB > 0 && currentINI.S1ServiceID <= 16777216){
		if(currentINI.S1ServiceID == 0){
			currentErrors.addSoftError("S1ServiceIndentifierDiv", "Service Indentifier");
		}
		
	}
	else if(currentINI.S1DataLengthB > 0 && currentINI.S1ServiceID > 16777216){
			currentErrors.addHardError("S1ServiceIndentifierDiv", "Shorten Identifier Label");
			var alertMessage = "<div class=\"alert alert-error\">";
              alertMessage += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>";
              alertMessage += "<strong>Oh No!</strong> Your Service Label is to long.</a>";
			alertMessage += "</div>";
		document.getElementById("S1ServiceID").innerHTML = alertMessage;
	}	
	
	if(currentINI.S2DataLengthB > 0 && currentINI.S2ServiceID <= 16777216){
		if(currentINI.S2ServiceID == 0){
			currentErrors.addSoftError("S2ServiceIndentifierDiv", "Service Indentifier");
		}
		
	}
	else if(currentINI.S1DataLengthB > 0 && currentINI.S1ServiceID > 16777216){
			currentErrors.addHardError("S2ServiceIndentifierDiv", "Shorten Identifier Label");
			var alertMessage = "<div class=\"alert alert-error\">";
              alertMessage += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>";
              alertMessage += "<strong>Oh No!</strong> Your Service Label is to long.</a>";
			alertMessage += "</div>";
		document.getElementById("S2ServiceID").innerHTML = alertMessage;
	}	
	
	if(currentINI.S3DataLengthB > 0 && currentINI.S3ServiceID <= 16777216){
		if(currentINI.S3ServiceID == 0){
			currentErrors.addSoftError("S3ServiceIndentifierDiv", "Service Indentifier");
		}
		
	}
	else if(currentINI.S1DataLengthB > 0 && currentINI.S1ServiceID > 16777216){
			currentErrors.addHardError("S3ServiceIndentifierDiv", "Shorten Identifier Label");
			var alertMessage = "<div class=\"alert alert-error\">";
              alertMessage += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>";
              alertMessage += "<strong>Oh No!</strong> Your Service Label is to long.</a>";
			alertMessage += "</div>";
		document.getElementById("S3ServiceID").innerHTML = alertMessage;
	}	
	

}

//validate CA system used
function CASystemVal(){
	if(currentINI.S0CASystemUsed != 0 || currentINI.S0CASystemUsed != 1){
		currentINI.S0CASystemUsed = 0;	
	}
	if(currentINI.S1CASystemUsed != 0 || currentINI.S1CASystemUsed != 1){
		currentINI.S1CASystemUsed = 0;	
	}
	if(currentINI.S2CASystemUsed != 0 || currentINI.S2CASystemUsed != 1){
		currentINI.S2CASystemUsed = 0;	
	}
	if(currentINI.S3CASystemUsed != 0 || currentINI.S3CASystemUsed != 1){
		currentINI.S3CASystemUsed = 0;	
	}
	else{}

}

//validate Language
function languageCodeVal(){
	if(currentINI.S0DataLengthB > 0 && currentINI.S0LanguageCode == "---"){
		currentErrors.addSoftError("S0LanguageDiv", "Language");
	}
	if(currentINI.S1DataLengthB > 0 && currentINI.S1LanguageCode == "---"){
		currentErrors.addSoftError("S1LanguageDiv", "Language");
	}
	if(currentINI.S2DataLengthB > 0 && currentINI.S2LanguageCode == "---"){
		currentErrors.addSoftError("S2LanguageDiv", "Language");
	}
	if(currentINI.S3DataLengthB > 0 && currentINI.S3LanguageCode == "---"){
		currentErrors.addSoftError("S3LanguageDiv", "Language");
	}
}

//validate Country Code
function countryCodeVal(){
	if(currentINI.S0DataLengthB > 0 && currentINI.S0CountryCode == "---"){
		currentErrors.addSoftError("S0CountryCodeDiv", "Country Code");
	}
	if(currentINI.S1DataLengthB > 0 && currentINI.S1CountryCode == "---"){
		currentErrors.addSoftError("S1CountryCodeDiv", "Country Code");
	}
	if(currentINI.S2DataLengthB > 0 && currentINI.S2CountryCode == "---"){
		currentErrors.addSoftError("S2CountryCodeDiv", "Country Code");
	}
	if(currentINI.S3DataLengthB > 0 && currentINI.S3CountryCode == "---"){
		currentErrors.addSoftError("S3CountryCodeDiv", "Country Code");
	}
}

//validate Audio Data Flag
function audioDataFlagVal(){
	if(currentINI.S0DataLengthB == 0 && (currentINI.S0AudioDataFlag!= 2 || currentINI.S0Source != 6)){
		currentINI.S0AudioDataFlag = 2;
		currentINI.S0Source = 6;
	}
	if(currentINI.S1DataLengthB == 0 && (currentINI.S1AudioDataFlag!= 2 || currentINI.S1Source != 6)){
		currentINI.S1AudioDataFlag = 2;
		currentINI.S1Source = 6;
	}
	if(currentINI.S2DataLengthB == 0 && (currentINI.S2AudioDataFlag!= 2 || currentINI.S2Source != 6)){
		currentINI.S2AudioDataFlag = 2;
		currentINI.S2Source = 6;
	}
	if(currentINI.S3DataLengthB == 0 && (currentINI.S3AudioDataFlag!= 2 || currentINI.S3Source != 6)){
		currentINI.S3AudioDataFlag = 2;
		currentINI.S3Source = 6;
	}
}

//validate Service descriptor
function serviceDescriptorVal(){
	if(currentINI.S0DataLengthB >0 && currentINI.S0ServiceDesc == 0){
		currentErrors.addSoftError("S0ServiceDescriptorDiv", "Service Descriptor");
	}
	if(currentINI.S1DataLengthB >0 && currentINI.S1ServiceDesc == 0){
		currentErrors.addSoftError("S1ServiceDescriptorDiv", "Service Descriptor");
	}
	if(currentINI.S2DataLengthB >0 && currentINI.S2ServiceDesc == 0){
		currentErrors.addSoftError("S2ServiceDescriptorDiv", "Service Descriptor");
	}
	if(currentINI.S3DataLengthB >0 && currentINI.S3ServiceDesc == 0){
		currentErrors.addSoftError("S3ServiceDescriptorDiv", "Service Descriptor");
	}
}

//validate Audio Coding, SBRFlag, AudioMode, AudioSamplingRate
function audioSettingsVal(){
	if(currentINI.S0DataLengthB > 0){
		var AudioSettingsVar = currentINI.S0AudioCodec.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S0SBRFlag.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S0AudioMode.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S0AudioSamplingRate.toString();
	
		if(Number(AudioSettingsVar) <= 123 && Number(AudioSettingsVar) != 1 && Number(AudioSettingsVar) != 101 && Number(AudioSettingsVar) != 3 && Number(AudioSettingsVar) != 103 && Number(AudioSettingsVar) != 113 && Number(AudioSettingsVar) != 123){
			currentErrors.addSoftError("S0AudioSettingsDiv", "Audio Settings");
		}
	}
	if(currentINI.S1DataLengthB > 0){
		var AudioSettingsVar = currentINI.S1AudioCodec.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S1SBRFlag.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S1AudioMode.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S1AudioSamplingRate.toString();
	
		if(Number(AudioSettingsVar) <= 123 && Number(AudioSettingsVar) != 1 && Number(AudioSettingsVar) != 101 && Number(AudioSettingsVar) != 3 && Number(AudioSettingsVar) != 103 && Number(AudioSettingsVar) != 113 && Number(AudioSettingsVar) != 123){
			currentErrors.addSoftError("S1AudioSettingsDiv", "Audio Settings");
		}
	}
	if(currentINI.S2DataLengthB > 0){
		var AudioSettingsVar = currentINI.S2AudioCodec.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S2SBRFlag.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S2AudioMode.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S2AudioSamplingRate.toString();
	
		if(Number(AudioSettingsVar) <= 123 && (Number(AudioSettingsVar) != 1) && Number(AudioSettingsVar) != 101 && Number(AudioSettingsVar) != 3 && Number(AudioSettingsVar) != 103 && Number(AudioSettingsVar) != 113 && Number(AudioSettingsVar) != 123){
			currentErrors.addSoftError("S2AudioSettingsDiv", "Audio Settings");
		}
	}
	if(currentINI.S3DataLengthB > 0){
		var AudioSettingsVar = currentINI.S3AudioCodec.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S3SBRFlag.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S3AudioMode.toString();
			AudioSettingsVar = AudioSettingsVar + currentINI.S3AudioSamplingRate.toString();
	
		if(Number(AudioSettingsVar) <= 123 && Number(AudioSettingsVar) != 1 && Number(AudioSettingsVar) != 101 && Number(AudioSettingsVar) != 3 && Number(AudioSettingsVar) != 103 && Number(AudioSettingsVar) != 113 && Number(AudioSettingsVar) != 123){
			currentErrors.addSoftError("S3AudioSettingsDiv", "Audio Settings");
		}
	}

}

//validate audio file name
function audioFileNameVal(){
	if(currentINI.S0DataLengthB > 0){
		if((currentINI.S0AudioFileName == "") && (currentINI.S0Source == 2 || currentINI.S0Source == 5)){
			currentErrors.addSoftError("S0SourceDiv", "File Name");
		}	
		else if(currentINI.S0Source == 3){
			var flagIt;
			for(var i = 0; i <liveAudioList.length; i++){
				if(currentINI.S0AudioFileName == liveAudioList[i]){
					flagIt = false;
					break;
				}
				else{
					flagIt = true;
				}
			}
			if(flagIt == true){
				currentErrors.addSoftError("S0SourceDiv", "Live Audio");
			}
			
		}	
	}
	if(currentINI.S1DataLengthB > 0){
		if(currentINI.S1AudioFileName == "" && (currentINI.S1Source == 2 || currentINI.S1Source == 5)){
			currentErrors.addSoftError("S1SourceDiv", "Audio File Name");
		}	
		else if(currentINI.S1Source == 3){
			var flagIt;
			for(var i = 0; i <liveAudioList.length; i++){
				if(currentINI.S1AudioFileName == liveAudioList[i]){
					flagIt = false;
					break;
				}
				else{
					flagIt = true;
				}
			}
			if(flagIt == true){
				currentErrors.addSoftError("S1SourceDiv", "Live Audio");
			}
			
		}	
	}
	if(currentINI.S2DataLengthB > 0){
		if(currentINI.S2AudioFileName == "" && (currentINI.S2Source == 2 || currentINI.S2Source == 5)){
			currentErrors.addSoftError("S2SourceDiv", "Audio File Name");
		}	
		else if(currentINI.S2Source == 3){
			var flagIt;
			for(var i = 0; i <liveAudioList.length; i++){
				if(currentINI.S2AudioFileName == liveAudioList[i]){
					flagIt = false;
					break;
				}
				else{
					flagIt = true;
				}
			}
			if(flagIt == true){
				currentErrors.addSoftError("S2SourceDiv", "Live Audio");
			}
			
		}	
	}
	if(currentINI.S3DataLengthB > 0){
		if(currentINI.S3AudioFileName == "" && (currentINI.S3Source == 2 || currentINI.S3Source == 5)){
			currentErrors.addSoftError("S3SourceDiv", "Audio File Name");
		}	
		else if(currentINI.S3Source == 3){
			var flagIt;
			for(var i = 0; i <liveAudioList.length; i++){
				if(currentINI.S3AudioFileName == liveAudioList[i]){
					flagIt = false;
					break;
				}
				else{
					flagIt = true;
				}
			}
			if(flagIt == true){
				currentErrors.addSoftError("S3SourceDiv", "Live Audio");
			}
			
		}	
	}

}

//validate ip address
function ipVal(){
	var ipPatt = new RegExp("/^([1-9]?\d|1\d\d|2[0-4]\d|25[0-5])\.([1-9]?\d|1\d\d|2[0-4]\d|25[0-5])\.([1-9]?\d|1\d\d|2[0-4]\d|25[0-5])\.([1-9]?\d|1\d\d|2[0-4]\d|25[0-5])$/");
	if(currentINI.IPAddress == "" && currentINI.IPEnabled == 1){
		currentErrors.addSoftError(301, "IP Address");
	}
	if(ipPatt.test(currentINI.IPAddress) && currentINI.IPEnabled == 1){
		currentErrors.addHardError(301, "IP Address not properly formatted");
			var alertMessage = "<div class=\"alert alert-error\">";
              alertMessage += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>";
              alertMessage += "<strong>Oh No!</strong> Your IP Address is not in proper format.";
           alertMessage += "</div>";
		document.getElementById("IPAlert").innerHTML = alertMessage;
	}
	
	if(currentINI.IPPort == "" && currentINI.IPEnabled == 1){
		currentErrors.addSoftError(301, "IP Port");
	}
	if(currentINI.IPPort > 65535 && currentINI.IPEnabled == 1){
		currentErrors.addHardError(301, "IP Port is to large a value.");
			var alertMessage = "<div class=\"alert alert-error\">";
              alertMessage += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>";
              alertMessage += "<strong>Oh No!</strong> Your IP Port is to large a value.a>";
           alertMessage += "</div>";
		document.getElementById("IPAlert").innerHTML = alertMessage;
	}

}

//validate FF
function ffVal(){
	
	if(currentINI.FFFileName == "" && currentINI.FEEnabled == 1){
		currentErrors.addSoftError("302", "FF File Name");
	}
	if(currentINI.FFFileName > 255 && currentINI.FEEnabled == 1){
		currentErrors.addHardError("302", "FF File Name is to long");
			var alertMessage = "<div class=\"alert alert-error\">";
              alertMessage += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>";
              alertMessage += "<strong>Oh No!</strong> Your FF File Name is to long.a>";
           alertMessage += "</div>";
		document.getElementById("FFAlert").innerHTML = alertMessage;
	}
	
	

}

//validate ip address
function pftVal(){
	
	if(currentINI.PFTPayloadMtu <50 && currentINI.PFTEnabled == 1){
		currentErrors.addHardError(303, "PFT Pay load value to low");
			var alertMessage = "<div class=\"alert alert-error\">";
              alertMessage += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>";
              alertMessage += "<strong>Oh No!</strong> Your PFT Pay load value to low. The minimum value is 50";
           alertMessage += "</div>";
		document.getElementById("PFTAlert").innerHTML = alertMessage;
	}
	if(currentINI.PFTPayloadMtu >16384 && currentINI.PFTEnabled == 1){
		currentErrors.addHardError(303, "PFT Pay load value to High");
			var alertMessage = "<div class=\"alert alert-error\">";
              alertMessage += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>";
              alertMessage += "<strong>Oh No!</strong> Your PFT Pay load value to high. The max value is 16384";
           alertMessage += "</div>";
		document.getElementById("PFTAlert").innerHTML = alertMessage;
	}
	
	if(currentINI.PFTStrength <0 && currentINI.PFTEnabled == 1 && currentINI.PFTProtection == 1){
		currentErrors.addHardError(303, "PFT Strength value to low");
			var alertMessage = "<div class=\"alert alert-error\">";
              alertMessage += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>";
              alertMessage += "<strong>Oh No!</strong> Your PFT strength value to low. The minimum value is 0";
           alertMessage += "</div>";
		document.getElementById("PFTAlert").innerHTML = alertMessage;
	}
	if(currentINI.PFTSource.lenght < 3 && currentINI.PFTEnabled == 1 && currentINI.PFTTransportation == 1){
		currentErrors.addHardError(303, "PFT Source value is to long");
			var alertMessage = "<div class=\"alert alert-error\">";
              alertMessage += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>";
              alertMessage += "<strong>Oh No!</strong> Your PFT Source value is to long. try shortening to no more than 2 characters.";
           alertMessage += "</div>";
		document.getElementById("PFTAlert").innerHTML = alertMessage;
	}
	if(currentINI.PFTSource =="" && currentINI.PFTEnabled == 1 && currentINI.PFTTransportation == 1){
		currentErrors.addSoftError(303, "PFT Source");
	}
	if(currentINI.PFTDestination.lenght < 3 && currentINI.PFTEnabled == 1 && currentINI.PFTTransportation == 1){
		currentErrors.addHardError(303, "PFT Destination value is to long");
			var alertMessage = "<div class=\"alert alert-error\">";
              alertMessage += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>";
              alertMessage += "<strong>Oh No!</strong> Your PFT Destination value is to long. Try shortening to no more than 2 characters.";
           alertMessage += "</div>";
		document.getElementById("PFTAlert").innerHTML = alertMessage;
	}
	if(currentINI.PFTDestination =="" && currentINI.PFTEnabled == 1 && currentINI.PFTTransportation == 1){
		currentErrors.addSoftError(303, "PFT Destination");
	}
}





