<?php //This function allows a user to update their password
//Start session
	session_start();

	//Determination variables
	$user = 0;//0=empty UserName field, 1=fields don't match database, 2=correct
	

	include('config.php');
	
	$dbhandle = mysql_connect($hostname, $username, $password)
			or die("Unable to connect to MySQL");
			
	mysql_select_db($databaseName,$dbhandle);
	$username=$_POST['username'];
	$password=$_POST['password'];
	$passwordHash=hash('whirlpool', $password);
	$type=$_POST['userType'];
	
	
	$pass=mysql_query("UPDATE UserInfo SET PasswordHashed='$passwordHash', UserType='$type' WHERE Username='$username'");
	$result=mysql_query("SELECT * FROM UserInfo WHERE Username='$username'");
	$row=mysql_fetch_array($result);
	$DBPass=$row['PasswordHashed'];
	if(($passwordHash==$DBPass)&&($password!=null))
	{
		$_SESSION['Action']="PasswordChange1";
		header("Location: ActionComplete.php");
	}
	if(($passwordHash!=$DBPass)&&($password!=null))
	{
		$user=1;
		
	}
	mysql_close($dbhandle);
	
	if ($_SESSION['UserType'] != "Basic") {
		header("Location: file.php");
		exit;
	}

	//Check for session logout
	if (isset($_POST["signout"])) {
		session_destroy();
		header("Location: index.php");
		exit;
	}

	//Check session status
	if (!isset($_SESSION['Login'])) {
		header("Location: index.php");
		exit;
	}
?>	


<!DOCTYPE html>
<html lang="en">
	<head>
<link href="bootstrap/css/bootstrap.css" rel="stylesheet">
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
<script src="js/validatorAdminCreate.js"></script>
<script src="js/validatorAdminCredentials.js"></script>
<script src="js/validatorAdminResetUser.js"></script>
<link rel="stylesheet" href="CSS/file.css" type="text/css"/>
<link rel="stylesheet" href="CSS/customWells.css" type="text/css"/>
<link href="FortAwesome/css/font-awesome.css" rel="stylesheet" type="text/css">
	</head>
<body>
	<div class="row-fluid">
		<div class="span12 well-white">
			<h1 class=" pull-left" style="color: #049cdb;" > <i class="icon-music"></i> eRadioConfig </h1>
			
			<div class=" pull-right" style="margin-bottom:0px; padding-bottom:0px">
					<a href="file.php" class="btn btn-primary"><i class="icon-home"></i> Back to File Page</a>
			</div>

		</div>
	</div>
	<div class="container-fluid">	
		<div class="row-fluid">
			<div class="span11.5 offset.5 well-white">
				<ul id="myTab" class="nav nav-tabs">
              <li class="active"><a href="#UpdatePW" data-toggle="tab">Update Password</a></li>
              <li><a href="#ChangeQA" data-toggle="tab">Change Secret Question and Answer</a></li>
              <li><a href="#ChangeViewMode" data-toggle="tab">Change View Mode</a></li>
            </ul>
				<div id="myTabContent" class="tab-content">
				   <div class="tab-pane fade in active" id="UpdatePW">
			<form class="form-horizontal" name="passwordChange" onsubmit="return validatorPW()" action="UpdatePW_BE.php" method="post">
				
				<fieldset>
				<legend>Change Password</legend>
				<div class="control-group" id="passwordGroup">
					<label class="control-label" for="password">New Password</label>
					<div class="controls">
						<input type="password" class="input-xlarge" id="password" name="password">
						<span class="help-inline" id="passwordHelp"></span>
					</div>
				</div>
				<div class="control-group" id="passwordConfirmGroup">
					<label class="control-label" for="passwordConfirm">Confirm Password</label>
					<div class="controls">
						<input type="password" class="input-xlarge" id="passwordConfirm" name="passwordConfirm">
						<span class="help-inline" id="passwordConfirmHelp"></span>
					</div>
				</div>
				<div class="form-actions">
					<button value="submit" type="submit" class="btn btn-primary">Submit</button>
					<button class="btn" value="Reload Page" onClick="document.location.reload(true)">Cancel</button>
				</div>
			</fieldset>
			</form>
			</div>
			
			<div class="tab-pane fade" id="ChangeQA">
			<form class="form-horizontal" name="questionChange" onsubmit="return validatorQA()" action="UpdateQA_BE.php" method="post">
			<fieldset>
				<legend>Update Secret Question + Answer</legend>
				<div class="control-group" id="secretQuestionGroup">
					<label class="control-label" for="question">New Secret Question</label>
					<div class="controls">
						<input type="text" class="input-xlarge" id="question" name="question">
						<span class="help-inline" id="questionHelp"></span>
					</div>
				</div>
				<div class="control-group" id="secretAnswerGroup">
					<label class="control-label" for="answer">New Secret Answer</label>
					<div class="controls">
						<input type="text" class="input-xlarge" id="answer" name="answer">
						<span class="help-inline" id="answerHelp"></span>
					</div>
				</div>
				<div class="control-group" id="secretAnswerConfirmGroup">
					<label class="control-label" for="answer">Confirm Answer</label>
					<div class="controls">
						<input type="text" class="input-xlarge" id="answerConfirm" name="answerConfirm">
						<span class="help-inline" id="answerConfirmHelp"></span>
					</div>
				</div>
				
				<div class="form-actions">
					<button value="submit" type="submit" class="btn btn-primary">Submit</button>
					<button class="btn" value="Reload Page" onClick="document.location.reload(true)">Cancel</button>
				</div>
			</fieldset>
			</form>
			</div>
			
			<div class="tab-pane fade" id="ChangeViewMode">
                <form class="form-horizontal" name="userChangeView" id="userChangeView" onsubmit="" action="UpdateViewBE.php" method="post">
			<fieldset>
			<div class="control-group" id="userTypeGroup">
					<label class="control-label" for="userType">User Type</label>
					<div class="controls">
						<select id="viewType" name="viewType"><!--TODO: Add js to give warning if swiching to advanced mode -->
							<option>Basic</option>
							<option>Advanced</option>
						</select>
					</div>
				</div>
				<div class="form-actions">
					<button value="submit" type="submit" class="btn btn-primary">Submit</button>
					<button class="btn" value="Reload Page" onClick="document.location.reload(true)">Cancel</button>
				</div>
			</fieldset>
		</form>
		</div>
			
		</div>
	</div>
	<!-- For test reporting only-->	
	<div class="navbar navbar-fixed-bottom">
  <div class="navbar-inner">
    <a class="brand" href="#testModal" class="btn" data-toggle="modal">Report Bug</a>
  </div>
  
</div>
<div id="testModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
    <h3>Report A Bug</h3>
  </div>
  <div class="modal-body">
	<Label> Subject:</label>
    <input type="text" id="subject" placeholder="Subject">
	<Label> Discription:</label>
	<textarea rows="3"></textarea>
  </div>
  <div class="modal-footer">
    <a href="#" class="btn" data-dismiss="modal" aria-hidden="true">Close</a>
    <a href="#" class="btn btn-primary">Submit</a>
  </div>
</div>
</body>
</html>
