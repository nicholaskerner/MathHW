<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>HCJB DRM Web GUI</title>
		<link href="bootstrap/css/bootstrap.css" rel="stylesheet">
		<script src="http://code.jquery.com/jquery-latest.js"></script>
		<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
		<script src="js/validatorAdminCreate.js"></script>
		<script src="js/validatorAdminCredentials.js"></script>
		<script src="js/validatorAdminResetUser.js"></script>
		<link rel="stylesheet" href="CSS/file.css" type="text/css"/>
		<link rel="stylesheet" href="CSS/customWells.css" type="text/css"/>
		<link href="FortAwesome/css/font-awesome.css" rel="stylesheet" type="text/css">
		<script src="js/validatorForgotPW.js"></script>	
	</head>
	<body>
	<div class="row-fluid">
		<div class="span12 well-white">
			<h1 class=" pull-left" style="color: #049cdb;" > <i class="icon-music"></i> eRadioConfig </h1>
			
			<div class=" pull-right" style="margin-bottom:0px; padding-bottom:0px">
					<a href="file.php" class="btn btn-primary"><i class="icon-home"></i> Back to Login Page</a>
			</div>

		</div>
	</div>

		<form class="form-horizontal" name="passwordChange" onsubmit="return validator()" action="UpdatePW_BE.php" method="post">
			
				<fieldset>
				<legend>Change Password</legend>
				<div class="control-group" id="passwordGroup">
					<label class="control-label" for="password">New Password</label>
					<div class="controls">
						<input type="password" class="input-xlarge" id="password" name="password">
						<span class="help-inline" id="passwordHelp"></span>
					</div>
				</div>
				<div class="control-group" id="passwordConfirmGroup">
					<label class="control-label" for="passwordConfirm">Confirm Password</label>
					<div class="controls">
						<input type="password" class="input-xlarge" id="passwordConfirm" name="passwordConfirm">
						<span class="help-inline" id="passwordConfirmHelp"></span>
					</div>
				</div>
				<div class="form-actions">
					<button value="submit" type="submit" class="btn btn-primary">Submit</button>
					<button class="btn" value="Reload Page" onClick="document.location.reload(true)">Cancel</button>
				</div>
			</fieldset>
		
	</body>
</html>
