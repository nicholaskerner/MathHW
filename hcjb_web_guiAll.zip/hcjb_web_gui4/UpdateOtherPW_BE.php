<?php //This function allows an admin to update a user's password

session_start();
	include('config.php');
	
	$dbhandle = mysql_connect($hostname, $username, $password)
			or die("Unable to connect to MySQL");
			
	mysql_select_db($databaseName,$dbhandle);
	$username=$_POST['username'];
	$password=$_POST['password'];
	$passwordHash=hash('whirlpool', $password);
	mysql_query("UPDATE UserInfo SET PasswordHashed='$passwordHash' WHERE UserID='$userID'");
	mysql_close($dbhandle);
	$_SESSION['Action']="PasswordChange1";
	header("Location: ActionComplete.php");
	
?>	