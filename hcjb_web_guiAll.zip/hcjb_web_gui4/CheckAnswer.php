<?php //This function allows the user to update their password

	session_start();
	include('config.php');
	
	$dbhandle = mysql_connect($hostname, $username, $password)
			or die("Unable to connect to MySQL");
			
	mysql_select_db($databaseName,$dbhandle);
	$myAnswer=$_POST['answer'];
	$hashedAnswer=hash('whirlpool', $myAnswer);
	$userNum=$_SESSION['UserID'];
	$result= mysql_query("SELECT * FROM UserInfo WHERE UserID='$userNum'");
	$row = mysql_fetch_array($result);
	$DBAnswer=$row['SecretAnswer'];
	if($DBAnswer==$hashedAnswer)//Correct
	{
		header("Location: ResetPW.php");
	}
	else //Incorrect
	{
		$_SESSION['ErrorRPW1']=2;
		//echo "DB: $DBAnswer   Entry: $hashedAnswer";
		header("Location: ForgotPWQuestion.php");	
	}
	
?>	
	