// Validation support for HCJB Admin Create User
// Author: Austin Klob
// Created: November, 2012


function validatorCreate() {
	//Pass or fail to be output at end
	var output = true;

	//Form values
	var username = document.forms["newUser"]["username"].value;
	var email = document.forms["newUser"]["email"].value;
	var password = document.forms["newUser"]["password"].value;
	var passwordConfirm = document.forms["newUser"]["confPassword"].value;
	
	
	//Checking form values
	if (username == null || username == "") {
		document.getElementById("usernameGroup").className = "control-group error";
		document.getElementById("usernameHelp").innerHTML = "Please enter a user name";
		output = false;
	}

	else {
		document.getElementById("usernameGroup").className = "control-group";
		document.getElementById("usernameHelp").innerHTML = "";
	}


	if (checkEmail(email) == false) {
		document.getElementById("emailGroup").className = "control-group error";
		document.getElementById("emailHelp").innerHTML = "Please enter a valid e-mail address";
		output = false;
	}

	else {
		document.getElementById("emailGroup").className = "control-group";
		document.getElementById("emailHelp").innerHTML = "";
	}

	if (password == null || password == "") {
		document.getElementById("passwordGroup").className = "control-group error";
		document.getElementById("passwordHelp").innerHTML = "Please enter a password";
		document.getElementById("confPasswordGroup").className = "control-group";
		//document.getElementById("confPasswordHelp").innerHTML = "";
		output = false;
	}

	else if (password != passwordConfirm) {
		document.getElementById("confPasswordGroup").className = "control-group error";
		document.getElementById("passwordGroup").className = "control-group error";
		document.getElementById("passwordHelp").innerHTML = "";
		document.getElementById("confPasswordHelp").innerHTML = "The passwords do not match";
		output = false;
	}

	else {
		document.getElementById("confPasswordGroup").className = "control-group";
		document.getElementById("passwordGroup").className = "control-group";
		document.getElementById("passwordHelp").innerHTML = "";
		document.getElementById("confPasswordHelp").innerHTML = "";
	}


	return output;
}


function checkEmail(email) { 
	var emailCheck = /\S+@\S+\.\S+/;

	return emailCheck.test(email);
}
