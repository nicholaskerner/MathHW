function validatorQA() {
	//Pass or fail to be output at end
	var output = true;

	//Form values
	
	
	var question = document.forms["questionChange"]["question"].value;
	var answer = document.forms["questionChange"]["answer"].value;
	var answerConfirm= document.forms["questionChange"]["answerConfirm"].value;
	
	if (question == null || question == "") {
		document.getElementById("secretQuestionGroup").className = "control-group error";
		document.getElementById("questionHelp").innerHTML = "Please enter a question";
		output = false;
	}

	else {
		document.getElementById("secretQuestionGroup").className = "control-group";
		document.getElementById("questionHelp").innerHTML = "";
	}
	
	if (answer == null || answer == "") {
		document.getElementById("secretAnswerGroup").className = "control-group error";
		document.getElementById("answerHelp").innerHTML = "Please enter a password";
		document.getElementById("secretAnswerConfirmGroup").className = "control-group";
		//document.getElementById("confPasswordHelp").innerHTML = "";
		output = false;
	}

	else if (answer != answerConfirm) {
		document.getElementById("secretAnswerConfirmGroup").className = "control-group error";
		document.getElementById("secretAnswerGroup").className = "control-group error";
		document.getElementById("answerHelp").innerHTML = "";
		document.getElementById("answerConfirmHelp").innerHTML = "The answers do not match";
		output = false;
	}

	else {
		document.getElementById("secretAnswerConfirmGroup").className = "control-group";
		document.getElementById("secretAnswerGroup").className = "control-group";
		document.getElementById("answerHelp").innerHTML = "";
		document.getElementById("answerConfirmHelp").innerHTML = "";
	}
	
		return output;
}