// Validation support for HCJB Change Password Page
// Author: Austin Klob
// Created: November, 2012


function validator() {
	//Pass or fail to be output at end
	var output = true;

	//Form values
	var password = document.forms["passwordChange"]["password"].value;
	var passwordConfirm = document.forms["passwordChange"]["passwordConfirm"].value;

	//Checking form values
	if (password == null || password == "") {
		document.getElementById("passwordGroup").className = "control-group error";
		document.getElementById("passwordHelp").innerHTML = "Please enter a password";
		document.getElementById("passwordConfirmGroup").className = "control-group";
		document.getElementById("passwordConfirmHelp").innerHTML = "";
		output = false;
	}

	else if (password != passwordConfirm) {
		document.getElementById("passwordConfirmGroup").className = "control-group error";
		document.getElementById("passwordGroup").className = "control-group error";
		document.getElementById("passwordHelp").innerHTML = "";
		document.getElementById("passwordConfirmHelp").innerHTML = "The passwords do not match";
		output = false;
	}

	else {
		document.getElementById("passwordConfirmGroup").className = "control-group";
		document.getElementById("passwordGroup").className = "control-group";
		document.getElementById("passwordHelp").innerHTML = "";
		document.getElementById("passwordConfirmHelp").innerHTML = "";
	}

	return output;
}
