//Logic to check over file page


function checkAllBoxes() {
	var globalCheckBox = document.getElementById("checkAll");
	var list = document.getElementsByClassName("checkBox");

	if (globalCheckBox.checked) {
		for (var i = 0; i < list.length; i++) {
			list[i].checked = true;
		}
	}

	else {
		for (var i = 0; i < list.length; i++) {
			list[i].checked = false;
		}
	}

	countBoxes();
}


function checkBox(checkID) {
	document.getElementById(checkID).checked = !document.getElementById(checkID).checked;
	countBoxes();
}


function countBoxes() {
	var list = document.getElementsByClassName("checkBox");
	var numChecked = 0;

	for (var i = 0; i < list.length; i++) {
		if (list[i].checked == true) {
			numChecked++;
		}
	}

	if (numChecked == list.length) {
		document.getElementById("checkAll").checked = true;
	}

	else {
		document.getElementById("checkAll").checked = false;
	}

	checkCount(numChecked);
}


function checkCount(numChecked) {
	if (numChecked == 0) {
		document.getElementById("open").className = "disabled";
		document.getElementById("delete").className = "disabled";
		document.getElementById("copy").className = "disabled";
		document.getElementById("rename").className = "disabled";
		document.getElementById("preset").className = "disabled";
		document.getElementById("download").className = "disabled";
	}

	else if(numChecked == 1) {
		document.getElementById("open").className = "";
		document.getElementById("delete").className = "";
		document.getElementById("copy").className = "";
		document.getElementById("rename").className = "";
		document.getElementById("preset").className = "";
		document.getElementById("download").className = "";
	}

	else {
		document.getElementById("delete").className = "";
		document.getElementById("copy").className = "";
		document.getElementById("preset").className = "";
		document.getElementById("download").className = "disabled";
		document.getElementById("open").className = "disabled";
		document.getElementById("rename").className = "disabled";
	}
}


function submitTableChange(buttonHit) {	
	if (buttonHit == "download") {
		tallyChecked("action");
		var selection = document.getElementById("action").value;

		if (selection != "" && selection.indexOf('*') == -1) {
			document.getElementById("action").name = "downloadID";
			document.getElementById("checkboxForm").submit();
		}
	}

	if (buttonHit == "upload") {
		$('#uploadFile').modal('show');
	}

	else if (buttonHit == "open") {
		tallyChecked("action");
		var selection = document.getElementById("action").value;

		if (selection != "" && selection.indexOf('*') == -1) {
			document.getElementById("action").name = "openID";
			document.getElementById("checkboxForm").submit();
		}
	}

	else if (buttonHit == "delete") {
		tallyChecked("deleteID");

		if (document.getElementById("deleteID").value != "") {
			$('#confirmDelete').modal('show');
		}
	}

	else if (buttonHit == "copy") {
		tallyChecked("action");
		var selection = document.getElementById("action").value;

		if (selection != "") {
			document.getElementById("action").name = "copyID";
			document.getElementById("checkboxForm").submit();
		}
	}

	else if (buttonHit == "rename") {
		tallyChecked("renameID");
		var selection = document.getElementById("renameID").value;

		if (selection != "" && selection.indexOf('*') == -1) {
			var nameID = "0" + selection;
			document.forms["renameForm"]["rename"].value = document.getElementById(nameID).value;
			$('#checkRename').modal('show');
		}
	}

	else if (buttonHit == "preset") {
		tallyChecked("action");
		var selection = document.getElementById("action").value;

		if (selection != "") {
			document.getElementById("action").name = "presetID";
			document.getElementById("checkboxForm").submit();
		}
	}
}


function tallyChecked(output) {
	var list = document.getElementsByClassName("checkBox");
	var selected = "";

	for (var i = 0; i < list.length; i++) {
		if (list[i].checked == true) {
			selected += list[i].value + "*";
		}
	}

	//Trim last asterisk from string
	selected = selected.substring(0, selected.length - 1);

	document.getElementById(output).value = selected;

}


function selectFile(id) {
	$('#createChecker').modal('hide');
	$('#newFileName').modal('show');
	document.getElementById("newNameID").value = id;
}


function signout() {
	document.getElementById("action").name = "signout";
	document.getElementById("checkboxForm").submit();
}
