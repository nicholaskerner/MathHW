

function validator() {
	//Pass or fail to be output at end
	var output = true;

	//Form values
	var username = document.forms["resetPassword"]["username"].value;
	
	var password = document.forms["resetPassword"]["password"].value;
	var passwordConfirm = document.forms["resetPassword"]["passwordConfirm"].value;
	
	if (username == null || username == "") {
		document.getElementById("usernameGroup").className = "control-group error";
		document.getElementById("usernameHelp").innerHTML = "Please enter a user name";
		output = false;
	}

	else {
		document.getElementById("usernameGroup").className = "control-group";
		document.getElementById("usernameHelp").innerHTML = "";
	}
	
	if (password == null || password == "") {
		document.getElementById("passwordGroup").className = "control-group error";
		document.getElementById("passwordHelp").innerHTML = "Please enter a password";
		document.getElementById("passwordConfirmGroup").className = "control-group";
		//document.getElementById("confPasswordHelp").innerHTML = "";
		output = false;
	}

	else if (password != passwordConfirm) {
		document.getElementById("passwordConfirmGroup").className = "control-group error";
		document.getElementById("passwordGroup").className = "control-group error";
		document.getElementById("passwordHelp").innerHTML = "";
		document.getElementById("passwordConfirmHelp").innerHTML = "The passwords do not match";
		output = false;
	}

	else {
		document.getElementById("passwordConfirmGroup").className = "control-group";
		document.getElementById("passwordGroup").className = "control-group";
		document.getElementById("passwordHelp").innerHTML = "";
		document.getElementById("passwordConfirmHelp").innerHTML = "";
	}
	
		return output;
}