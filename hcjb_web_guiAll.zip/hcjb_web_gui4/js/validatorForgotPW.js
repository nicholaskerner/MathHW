function validatorID() {
	//Pass or fail to be output at end
	var output = true;

	//Form values
	var username = document.forms["ForgotPassword"]["username"].value;
	if (username == null || username == "") {
		document.getElementById("usernameGroup").className = "control-group error";
		document.getElementById("usernameHelp").innerHTML = "Please enter a user name";
		output = false;
	}
	return output;
}

