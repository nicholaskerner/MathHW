<?php
	print_r(parse_ini_file('Button5.ini', true));
?>
