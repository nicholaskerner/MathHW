<?php
$input=$_POST[userName];
echo hash('whirlpool', $input);
?>