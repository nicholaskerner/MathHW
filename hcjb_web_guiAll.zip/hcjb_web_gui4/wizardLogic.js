


function loc(value){

	if(value == 0 && (transmission.SO != 1 || transmission.SO != 3 || transmission.SO == 5)){
		document
	}
	

}