<?php

	include('config.php');
	
	//Connect to the database
	$dbhandle = mysql_connect($hostname, $username, $password);
	
	if(!$dbhandle){
		throw new Exception("Unable to connect to MySQL");
	}

	
	//Select the database
	$selected = mysql_select_db($databaseName,$dbhandle);
	
	if(!$selected){
		throw new Exception("Could not select database.");
	}

	$result = mysql_query("INSERT INTO `$databaseName`.`AutoSave` (`UserID`,`FileID`, `FileLocation`,`FileName`, `IsMostRecent`, `IsRealFile`, `ConfigurationDesc`, `Location`, `SpectrumOcc`, `Robustness`, `InterleaverDepth`, `MSCMode`, `SDCMode`, `BaseEnhancementFlag`, `ProtAInt`, `ProtAValue`, `ProtBInt`, `ProtBValue`, `ProtHValue`, `ProtHInt`, `HierarchicalBytes`, `AmDRM`, `S0DataLengthA`, `S0DataLengthB`, `S0ServiceLabel`, `S0ServiceID`, `S0CASystemUsed`, `S0LanguageInt`, `S0LanguageCode`, `S0CountryInt`, `S0CountryCode`, `S0AudioDataFlag`, `S0ServiceDesc`, `S0StreamID`, `S0AudioCodec`, `S0SBRFlag`, `S0AudioMode`, `S0AudioSamplingRate`, `S0TextFlag`, `S0EnhancementFlag`, `S0Source`, `S0AudioFileName`, `S0RepeatAudio`, `S0CoderField`, `S1DataLengthA`, `S1DataLengthB`, `S1ServiceLabel`, `S1ServiceID`, `S1CASystemUsed`, `S1LanguageInt`, `S1LanguageCode`, `S1CountryInt`, `S1CountryCode`, `S1AudioDataFlag`, `S1ServiceDesc`, `S1StreamID`, `S1AudioCodec`, `S1SBRFlag`, `S1AudioMode`, `S1AudioSamplingRate`, `S1TextFlag`, `S1EnhancementFlag`, `S1Source`, `S1AudioFileName`, `S1RepeatAudio`, `S1CoderField`, `S2DataLengthA`, `S2DataLengthB`, `S2ServiceLabel`, `S2ServiceID`, `S2CASystemUsed`, `S2LanguageInt`, `S2LanguageCode`, `S2CountryInt`, `S2CountryCode`, `S2AudioDataFlag`, `S2ServiceDesc`, `S2StreamID`, `S2AudioCodec`, `S2SBRFlag`, `S2AudioMode`, `S2AudioSamplingRate`, `S2TextFlag`, `S2EnhancmentFlag`, `S2Source`, `S2AudioFileName`, `S2RepeatAudio`, `S2CoderField`, `S3DataLengthA`, `S3DataLengthB`, `S3ServiceLabel`, `S3ServiceID`, `S3CASystemUsed`, `S3LanguageInt`, `S3LanguageCode`, `S3CountryID`, `S3CountryCode`, `S3AudioDataFlag`, `S3ServiceDesc`, `S3StreamID`, `S3AudioCodec`, `S3SBRFlag`, `S3AudioMode`, `S3AudioSamplingRate`, `S3TextFlag`, `S3EnhancementFlag`, `S3Source`, `S3AudioFileName`, `S3RepeatAudio`, `S3CoderField`, `IPEnabled`, `IPAddress`, `IPPort`, `IP_TCP_UDP`, `FEEnabled`, `FFFileName`, `PFTEnabled`, `PFTPayloadMtu`, `PFTProtection`, `PFTStrength`, `PFTTransportation`, `PFTSource`, `PFTDestination`, `VUMeter`, `Timing`, `Clocktime`, `Preset`) VALUES ('$UID','', NULL,'$filename', '1', '0',  '$ConfigurationDescription', NULL,'$SpectrumOccupancy', '$Robustness', '$InterleaverDepthFlag', '$MSCMode', '$SDCMode', '$BaseEnhancementFlag', '$ProtLevelForPartA', NULL, '$ProtLevelForPartB', NULL, NULL, '$ProtLevelForHierarchical', '$HierarchicalBytes', '$AmDrm', '$DataLengthForPartA0', '$DataLengthForPartB0', '$ServiceLabel0', '$ServiceIdentifier0', '$CASystemUsed0', '$Language0', '$LanguageCode0', NULL, '$CountryCode0', '$AudioDataFlag0', '$ServiceDescriptor0', '$StreamId0', '$AudioCoding0', '$SBRFlag0', '$AudioMode0', '$AudioSamplingRate0', '$TextFlag0', '$EnhancementFlag0', '$Source0', '$AudioFilename0', '$RepeatAudio0', '$CoderField0', '$DataLengthForPartA1', '$DataLengthForPartB1', '$ServiceLabel1', '$ServiceIdentifier1', '$CASystemUsed1', '$Language1', '$LanguageCode1', NULL, '$CountryCode1', '$AudioDataFlag1', '$ServiceDescriptor1', '$StreamId1', '$AudioCoding1', '$SBRFlag1', '$AudioMode1', '$AudioSamplingRate1', '$TextFlag1', '$EnhancementFlag1', '$Source1', '$AudioFilename1', '$RepeatAudio1', '$CoderField1', '$DataLengthForPartA2', '$DataLengthForPartB2', '$ServiceLabel2', '$ServiceIdentifier2', '$CASystemUsed2', '$Language2', '$LanguageCode2', NULL, '$CountryCode2', '$AudioDataFlag2', '$ServiceDescriptor2', '$StreamId2', '$AudioCoding2', '$SBRFlag2', '$AudioMode2', '$AudioSamplingRate2', '$TextFlag2', '$EnhancementFlag2', '$Source2', '$AudioFilename2', '$RepeatAudio2', '$CoderField2', '$DataLengthForPartA3', '$DataLengthForPartB3', '$ServiceLabel3', '$ServiceIdentifier3', '$CASystemUsed3', '$Language3', '$LanguageCode3', NULL, '$CountryCode3', '$AudioDataFlag3', '$ServiceDescriptor3', '$StreamId3', '$AudioCoding3', '$SBRFlag3', '$AudioMode3', '$AudioSamplingRate3', '$TextFlag3', '$EnhancementFlag3', '$Source3', '$AudioFilename3', '$RepeatAudio3', '$CoderField3', '$IPEnabled', '$IPAddr', '$IPPort', '$IP_TCP_UDP', '$FFEnabled', '$FFFileName', '$PFTEnabled', '$PFTPayloadMtu', '$PFTProtection', '$PFTStrength', '$PFTTransportation', '$PFTSource', '$PFTDestination', '$VUMeter', '$Timing', '$Clocktime' , '0');");
	
	if($result == false){
			throw new Exception("No bugs to display.".$endl);
	}	
	else{
		
		
	
		echo "<table border=\"1\">";
		
		
		$row = mysql_fetch_array($result);		
		while($row != FALSE){
			echo "<tr>";
			echo "<td>".."</td>";
			echo "<td>".."</td>";
			echo "</tr>";
			
			$row = mysql_fetch_array($result);	
		}
		
		echo "</table>";
	}
?>