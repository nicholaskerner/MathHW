<?php

	//Start session
	session_start();

	//Check for session logout
	if (isset($_POST["signout"])) {
		session_destroy();
		header("Location: index.php");
		exit;
	}
	//Check session status
	if (!isset($_SESSION['Login'])) {
		header("Location: index.php");
		exit;
	}
	//$_SESSION['FileID'] = 77;
	//echo $_SESSION['FileID'];
?>
<?php
	if($_SESSION['ViewType'] == "Adv"){
		header( 'Location: adv_wizard.php');
	}	
?>	

<!DOCTYPE html>		
<html>
	<head>
		<title> Content Server </title>
		 
		<link rel="stylesheet" href="CSS/wizard.css" type="text/css"/>
		<link rel="stylesheet" href="CSS/customWells.css" type="text/css"/>
		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
		<link href="FortAwesome/css/font-awesome.css" rel="stylesheet" type="text/css">
		<link href="JQuery-UI/jquery-ui-bootstrap-gh-pages/css/custom-theme/jquery-ui-1.10.0.custom.css" rel="stylesheet" type="text/css">		
		<script src="http://code.jquery.com/jquery-latest.js"></script>
		<script type="text/javascript" src="JQuery-UI/jquery-ui-bootstrap-gh-pages/assets/js/jquery-ui-1.10.0.custom.min.js"></script>
		<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="wizardLogic/CurrentErrorsObject.js"></script>
		<script type="text/javascript" src="wizardLogic/wizard.js"></script>
		<script type="text/javascript" src="wizardLogic.js"></script>
		<script type="text/javascript" src="wizardLogic/AJAXCalls.js"></script>
		<script type="text/javascript" src="wizardLogic/ServiceDisplay.js"></script>
		<script type="text/javascript" src="wizardLogic/MainLogic.js"></script>
		<script type="text/javascript" src="wizardLogic/Arrays.js"></script>
		<script type="text/javascript" src="wizardLogic/Validator.js"></script>
		<script type="text/javascript" src="wizardLogic/modals.js"></script>
		<script type="text/javascript" src="wizardLogic/newFileLogic.js"></script>
		<script type="text/javascript" src="wizardLogic/activeconfigSummary.js"></script>
		<script src="http://code.highcharts.com/highcharts.js"></script>
		<script src="http://code.highcharts.com/modules/exporting.js"></script>
		<script type="text/javascript" src="wizardLogic/Chart.js"></script>
		<script type="text/javascript" src="lib/Bug/submitBugs.js"></script>
		<!-- loads tooltips for page-->
		<script >
			 $(document).ready(function () {
				$("[rel=tooltip]").tooltip();
			  });
		</script>
		<script>
			
		</script>

		
	</head>
<?php
	echo "<body onload=\"loadAJAXObject(".$_SESSION['FileID'].")\">";

?>	
	
	
		<div class="row-fluid">
			<div class="span12 well-white">
				<h1 style="color: #049cdb;" > <i class="icon-music"></i> eRadioConfig </h1>
				<div class="span12"></div>
				<div id="activateAndSave" class="pull-right" style="margin-bottom:0px; padding-bottom:0px">
					
				</div>
				
			</div>
		</div>
			
		<div class="container-fluid">	
			<div class="row-fluid">
				<div class="span8 well-white" >
						
					<ul class="nav nav-tabs" id="myTab0">
						<li class="active"><a href="#tab1xx" onclick="change(101)">Transmission</a></li>
					    <li ><a href="#tab2xx" onclick="change(201)">Service</a></li>
					    <li ><a href="#tab3xx" onclick="change(300)">Output Options</a></li>
					</ul>
					 
					<div class="tab-content">
		 
						<div class="tab-pane active " id="tab1xx">
							<div class="span11 "> 
								<div class="tabbable tabs-left"> <!-- Only required for left/right tabs -->
								  <ul class="nav nav-tabs" id="myTab0">
									<li class="active"><a href="#tab101" onclick="change(101)" ><i class="icon-edit"></i> File Description </a></li>
									<li><a href="#tab102" onclick="change(102)" ><i class="icon-globe"></i> Spectrum Occupancy </a></li>
									<li><a href="#tab103" onclick="change(103)"><i class="icon-signal"></i> Robustness </a></li>
									<li><a href="#tab104" onclick="change(104)"><i class="icon-exchange"></i> Interleaver Depth</a></li>
									<li><a href="#tab105" onclick="change(105)"><i class="icon-spinner"></i> MSC</a></li>
									<li><a href="#tab106" onclick="change(106)"><i class="icon-bar-chart"></i> SDC</a></li>
									<li><a href="#tab107" onclick="change(107)"><i class="icon-lock"></i> Protection Level</a></li>

								  </ul>
								  <div class="tab-content">
									<div class="tab-pane active" id="tab101">
										<div class="span6 well">
											<dl>
											  <dt>Configuration Description</dt>
											  <dd>255 Character limit, that describes this file.</dd>
											</dl>
										</div>
										<div class="span5 offset1" >
											<div class="page-header">
											<h5>Description:</h5>
											</div>
											<div id="ConfigurationDescriptionAlert">
											</div>
<?php
	//Perform SQL Call and get ConfigurationDescription.
	include('config.php');

	//Connect to the database
	$dbhandle = mysql_connect($hostname, $username, $password)
		or die("Unable to connect to MySQL");

	//Select the database
	$selected = mysql_select_db($databaseName,$dbhandle)
		or die("Could not select examples");
		
	//Execute the query, gathering all data from the database
	$result = mysql_query("SELECT * FROM `AutoSave` WHERE FileID = \"".$_SESSION['FileID']."\"");

	$row = mysql_fetch_array($result);
	
	$Temp = $row["ConfigurationDesc"];
	
	if($Temp == null || $Temp == "--" || $Temp == ""){
		echo "<textarea rows=\"5\" name=\"ConfigurationDescription\" onchange=\"logic(this.name, this.value)\">
												</textarea>";
				
	}
	else{
		echo "<textarea rows=\"5\" name=\"ConfigurationDescription\" onchange=\"logic(this.name, this.value)\">".$Temp."
												</textarea>";
	}

?>											
											
											<br>
										</div>
									</div>

									<div class="tab-pane" id="tab102">
									  <div class="span6 well">
											<dl>
											  <dt>Spectrum Occupency</dt>
											  <dd>The hertz the transmission is operating on, most basic option. Set to 4.5, 9, 18 kHz for Europe and 5,10,20 for US Higher means better quality. 18,20 not used by FHG receivers. 9,10 is typical.</dd>
											</dl>
										</div>
										<div class="span5 offset1" >
											<div class="page-header">
											<h5>Options:</h5>
											</div>
											<div id="SOAlert">
											</div>
												<h5>Europe<h5>
<?php	
	//Get Spectrum Occupency
		$Temp = $row["SpectrumOcc"];
										echo"	<label class=\"radio\">
												  <input type=\"radio\" name=\"SO\" id=\"optionsRadios45\" value=\"0\" onclick=\"logic(this.name, this.value)\"";
										if($Temp == 0 ){
											echo" checked>";
										}
										else{
											echo" >";
										}
										echo"			4.5 kHz
												</label>
												<label class=\"radio\">
												  <input type=\"radio\" name=\"SO\" id=\"optionsRadios9\" value=\"2\" onclick=\"logic(this.name, this.value)\"";
										if($Temp == 2){
											echo" checked>";
										}
										else{
											echo" >";
										}		  
										echo"			9 kHz
												</label>
												<label class=\"radio\">
												 <input type=\"radio\" name=\"SO\" id=\"optionsRadios18\" value=\"4\" onclick=\"logic(this.name, this.value)\"";
										if($Temp == 4){
											echo" checked>";
										}
										else{
											echo" >";
										}		 
										echo"			18 kHz
												</label>
												<h5>America<h5>
												<label class=\"radio\">
												  <input type=\"radio\" name=\"SO\" id=\"optionsRadios5\" value=\"1\" onclick=\"logic(this.name, this.value)\"";
										if($Temp == 1){
											echo" checked>";
										}
										else{
											echo" >";
										}		  
										echo"			5 kHz
												</label>
												<label class=\"radio\">
												  <input type=\"radio\" name=\"SO\" id=\"optionsRadios10\" value=\"3\" onclick=\"logic(this.name, this.value)\"";
										if($Temp == 3){
											echo" checked>";
										}
										else{
											echo" >";
										}		  
										echo"			10 kHz
												</label>
												<label class=\"radio\">
												  <input type=\"radio\" name=\"SO\" id=\"optionsRadios45\" value=\"5\" onclick=\"logic(this.name, this.value)\"";
										if($Temp == 5){
											echo" checked>";
										}
										else{
											echo" >";
										}		  
										echo"			20 kHz
												</label>";
?>												
											<br>
										</div>
									</div>
									
									<div class="tab-pane" id="tab103">
										<div class="span6 well">
											<dl>
											  <dt>Robustness </dt>
											  <dd>Protects against loss of data along transmission. Higher value means more stability but lesser quality.</dd>
											</dl>
										</div>
										<div class="span5 offset1" >
											<div class="page-header">
											<h5>Options:</h5>
											</div>
											<div id="RobustAlert">
											</div>
<?php	
	//Get robustness
	$Temp = $row["Robustness"];
										
									echo"	<label class=\"radio\" rel=\"tooltip\" data-placement=\"left\" title=\"guard interval local medium wave\">
											 <input type=\"radio\" name=\"Robust\" id=\"optionsRobust1\" value=\"0\" onclick=\"logic(this.name, this.value)\"";
										if($Temp === 0){
											echo" checked>";
										}
										else{
											echo" >";
										}	 
										echo"		A 5%
											</label>
											<label class=\"radio\" rel=\"tooltip\" data-placement=\"left\" title=\"guard interval general sky wave\">
											 <input type=\"radio\" name=\"Robust\" id=\"optionsRobust2\" value=\"1\" onclick=\"logic(this.name, this.value)\"";
										if($Temp === 1){
											echo" checked>";
										}
										else{
											echo" >";
										}	 
										echo"	 B 20 %
											</label>
											<label class=\"radio\" rel=\"tooltip\" data-placement=\"left\" title=\"guard interval severe multipath\">
											 <input type=\"radio\" name=\"Robust\" id=\"optionsRobust3\" value=\"2\" onclick=\"logic(this.name, this.value)\"";
										if($Temp === 2){
											echo" checked>";
										}
										else{
											echo" >";
										}	 
										echo"	C 27%
											</label>
											<label class=\"radio\" rel=\"tooltip\" data-placement=\"left\" title=\"guard interval severe multipath & Doppler\">
											 <input type=\"radio\" name=\"Robust\" id=\"optionsRobust4\" value=\"3\" onclick=\"logic(this.name, this.value)\"";
										if($Temp === 3){
											echo" checked>";
										}
										else{
											echo" >";
										}	 
										echo"	D 44%
											</label>";
?>											
											<br>
										</div>
									</div>
									
									
									
									<div class="tab-pane" id="tab104">
										<div class="span6 well">
											<dl>
											  <dt>Interleaver Depth</dt>
											  <dd>Amount of time audio frame is spread between (.4 or 2 sec)
												(Long interleave increases decoding delay but increases signals robustness)</dd>
											</dl>
										</div>
										<div class="span5 offset1" >
											<div class="page-header">
											<h5>Options:</h5>
											</div>
											<div id="InterleaverAlert">
											</div>
<?php
//Get Interleaver Depth
$Temp = $row["InterleaverDepth"];											
										echo"	<label class=\"radio\">
												 <input type=\"radio\" name=\"Interleaver\" id=\"optionsID1\" value=\"0\" onclick=\"logic(this.name, this.value)\"";
										if($Temp === 0){
											echo" checked>";
										}
										else{
											echo" >";
										}		 
										echo"		2.0 sec
												</label>
											<label class=\"radio\">
												 <input type=\"radio\" name=\"Interleaver\" id=\"optionsID2\" value=\"1\" onclick=\"logic(this.name, this.value)\"";
										if($Temp == 1){
											echo" checked>";
										}
										else{
											echo" >";
										}		 
										echo"		0.4 sec
												</label>";
?>												
											<br>
										</div>
									</div>
									
									<div class="tab-pane" id="tab105">
										<div class="span6 well">
											<dl>
											  <dt>MSC</dt>
											  <dd> Adds redundancy to transmission. </dd>
											</dl>
										</div>
										<div class="span5 offset1" >
											<div class="page-header">
											<h5>Options:</h5>
											</div>
<?php	
//get MSC 
$Temp = $row["MCSMode"];			
									echo"<div id=\"MSCAlert\">";
										
									if($Temp == 1 || $Temp == 2){
										echo"<div class=\"alert alert-info\"> 
												<button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>
												<strong>Heads up!</strong>
												 This parameter has a value that is no longer supported. if you change this parameter it will erase this value.
										</div>";
									}
									echo "</div>";
									echo"		<label class=\"radio\" rel=\"tooltip\" data-placement=\"left\" title=\"non-hierarchical \">
											 <input type=\"radio\" name=\"MSC\" id=\"optionsMSC1\" value=\"0\" onclick=\"logic(this.name, this.value)\"";
									if($Temp === 0){
											echo" checked>";
										}
										else{
											echo" >";
										}		 		 
										echo"	64 QAM SM
											</label>
											<label class=\"radio\" rel=\"tooltip\" data-placement=\"left\" title=\"non-hierarchical\">
											 <input type=\"radio\" name=\"MSC\" id=\"optionsMSC4\" value=\"3\" onclick=\"logic(this.name, this.value)\"";
										if($Temp == 3){
											echo" checked>";
										}
										else{
											echo" >";
										}		 	 
										echo"	16 QAM SM
											</label>";
?>											
											<br>
										</div>
									</div>

									<div class="tab-pane" id="tab106">
										<div class="span6 well">
											<dl>
											  <dt>SDC</dt>
											  <dd> Service Discription Channel. </dd>
											</dl>
										</div>
										<div class="span5 offset1" >
											<div class="page-header">
											<h5>Options:</h5>
											</div>
											<div id="SDCAlert">
											</div>
<?php	
$Temp = $row["SDCMode"];											
									echo"		<label class=\"radio\" rel=\"tooltip\" >
											 <input type=\"radio\" name=\"SDC\" id=\"optionsSDC0\" value=\"0\" onclick=\"logic(this.name, this.value)\"";
									if($Temp === 0){
											echo" checked>";
										}
										else{
											echo" >";
										}		 		 
										echo"	16 QAM
											</label>

											<label class=\"radio\" rel=\"tooltip\">
											 <input type=\"radio\" name=\"SDC\" id=\"optionsSDC1\" value=\"1\" onclick=\"logic(this.name, this.value)\"";
										if($Temp == 1){
											echo" checked>";
										}
										else{
											echo" >";
										}		 	 
										echo"	4 QAM
											</label>";
?>											
											<br>
										</div>
									</div>
									
									<div class="tab-pane" id="tab107">
										<div class="span6 well">
											<dl>
											  <dt>Protection Level</dt>
											  <dd> The amount of protection. </dd>
											</dl>
										</div>
										<div class="span5 offset1" >
											<div class="page-header">
											<h5>Options:</h5>
											</div>
											<div id="ProtLevelAlert">
											</div>
											<div id="ProtLevelOptions">
<?php	
$Temp = $row["MCSMode"];	
				if($Temp === 0){
					$Temp = $row["ProtBInt"];	
									echo"		<label class=\"radio\" rel=\"tooltip\" data-placement=\"left\" title=\"strong\">
											 <input type=\"radio\" name=\"ProtBInt\" id=\"optionsProtBInt0\" value=\"0\" onclick=\"logic(this.name, this.value)\"";
									if($Temp === 0){
											echo" checked>";
										}
										else{
											echo" >";
										}		 		 
										echo"	0.50
											</label>

											<label class=\"radio\" rel=\"tooltip\">
											 <input type=\"radio\" name=\"ProtBInt\" id=\"optionsProtbInt1\" value=\"1\" onclick=\"logic(this.name, this.value)\"";
										if($Temp == 1){
											echo" checked>";
										}
										else{
											echo" >";
										}		 	 
										echo"	0.60
											</label>";
										
										echo"		<label class=\"radio\" rel=\"tooltip\">
											 <input type=\"radio\" name=\"ProtBInt\" id=\"optionsProtBInt2\" value=\"2\" onclick=\"logic(this.name, this.value)\"";
									if($Temp == 2){
											echo" checked>";
										}
										else{
											echo" >";
										}		 		 
										echo"	0.71
											</label>

											<label class=\"radio\" rel=\"tooltip\" data-placement=\"left\" title=\"weak\">
											 <input type=\"radio\" name=\"ProtBInt\" id=\"optionsProtbInt3\" value=\"3\" onclick=\"logic(this.name, this.value)\"";
										if($Temp == 3){
											echo" checked>";
										}
										else{
											echo" >";
										}		 	 
										echo"	0.78
											</label>";
				}
				else if($Temp === 3){
					$Temp = $row["ProtBInt"];	
									echo"		<label class=\"radio\" rel=\"tooltip\" data-placement=\"left\" title=\"strong\">
											 <input type=\"radio\" name=\"ProtBInt\" id=\"optionsProtBInt0\" value=\"0\" onclick=\"logic(this.name, this.value)\"";
									if($Temp === 0){
											echo" checked>";
										}
										else{
											echo" >";
										}		 		 
										echo"	0.50
											</label>

											<label class=\"radio\" rel=\"tooltip\" data-placement=\"left\" title=\"weak\">
											 <input type=\"radio\" name=\"ProtBInt\" id=\"optionsProtbInt1\" value=\"1\" onclick=\"logic(this.name, this.value)\"";
										if($Temp == 1){
											echo" checked>";
										}
										else{
											echo" >";
										}		 	 
										echo"	0.62
											</label>";



				}
				else if($Temp === 1 || $Temp ===2){
					echo"<div class=\"alert alert-info\"> 
												<button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button>
												<strong>Heads up!</strong>
												 This parameter has a value that is no longer supported. In order to change this perameter please select a supported <a href=\"#tab105\" onclick=\"change(105)\">MSC Mode</a>.
										</div>";



				}
				else{
					echo"		<label class=\"radio\" rel=\"tooltip\" data-placement=\"left\" title=\"strong\">
											 <input type=\"radio\" name=\"ProtBInt\" id=\"optionsProtBInt0\" value=\"0\" onclick=\"logic(this.name, this.value)\">";
					 		 
										echo"	0.50
											</label>

											<label class=\"radio\" rel=\"tooltip\">
											 <input type=\"radio\" name=\"ProtBInt\" id=\"optionsProtbInt1\" value=\"1\" onclick=\"logic(this.name, this.value)\">"; 	 
										echo"	0.60
											</label>";
										
										echo"		<label class=\"radio\" rel=\"tooltip\">
											 <input type=\"radio\" name=\"ProtBInt\" id=\"optionsProtBInt2\" value=\"2\" onclick=\"logic(this.name, this.value)\">";		 		 
										echo"	0.71
											</label>

											<label class=\"radio\" rel=\"tooltip\" data-placement=\"left\" title=\"weak\">
											 <input type=\"radio\" name=\"ProtBInt\" id=\"optionsProtbInt3\" value=\"3\" onclick=\"logic(this.name, this.value)\">";
												 	 
										echo"	0.78
											</label>";
				
				
				
				
				
				
				
				}
?>			
										</div>
											<br>
										</div>
									</div>
								
								  </div>
								</div>	
							</div>		
						 </div>
						 
						
						<div class="tab-pane" id="tab2xx">
						  <div class="span12"> 
							<div class="page-header">
								<h5 class="span4">Select Service Options:</h5>
							
								<select class="span3 inline" id="servicesSelect" onclick="servicesToDisplay(this.value)">
								</select>
							
							</div>
							<div id="servicetabs">
							
							</div>
						
						  </div>
						</div>
						
						<div class="tab-pane" id="tab3xx">
						  <div class="span12"> 
								<div class="tabbable tabs-left"> <!-- Only required for left/right tabs -->
									  <ul class="nav nav-tabs" id="myTab0">
										<li class="active"><a href="#tab301" onclick="change(301)" ><i class="icon-edit"></i> IPEnabled</a></li>
										<li><a href="#tab302" onclick="change(302)" ><i class="icon-globe"></i> FFEnabled </a></li>
										<li><a href="#tab303" onclick="change(303)"><i class="icon-signal"></i> PFTEnabled</a></li>
									  </ul>
									  <div class="tab-content">
									  
										<div class="tab-pane active" id="tab301">
											<div class="span10 offset1" >
												<div class="page-header">
												<h5>IP Enabled:</h5>
												</div>
												<div id="IPAlert">
												</div>
												
												
<?php											
$Temp = $row["IPEnabled"];	
										echo"		<label class=\"checkbox\">
												<input type=\"checkbox\" name=\"IPEnabled\"  onchange=\"logic(this.name, this.value)\"";
										if($Temp == 1){
											echo" checked>";		
										}
										else{
											echo">";
										}	
$Temp = $row["IPAddress"];											
										echo "Check to enable IP output
												</label>
												<div class=\"span8 well-white\">
												<input id=\"IPAddr\" type=\"text\" class=\"span6\" name=\"IPAddr\" placeholder=\"IP Address\" value=\"";
										if($Temp == NULL){
											echo"IP Address";
										}	
										else{
											echo $Temp;
										}
$Temp = $row["IPPort"];										
										echo"\" onchange=\"logic(this.name, this.value)\">
												<input type=\"text\" id=\"IPPort\" class=\"span3 offset2\" name=\"IPPort\" placeholder=\"IPPort\" value=\"";
										if($Temp == NULL){
											echo"Port";
										}
										else{
											echo $Temp;
										}
										echo"\" onchange=\"logic(this.name, this.value)\">";
?>
											</div>
											</div>
										</div>
										
										<div class="tab-pane" id="tab302">
											<div class="span10 offset1" >
												<div class="page-header">
												<h5>FF Enabled:</h5>
												</div>
												<div id="FFAlert">
												</div>
												<label class="checkbox">
												<input type="checkbox" name="FFEnabled" onclick="logic(this.name, this.value)"
<?php
$Temp = $row["FEEnabled"];	
												if($Temp == 1){
													echo"checked>";
												}
												else{
													echo ">";
												}
?>												
												
												  Check to enable FF output
												</label>
												<input type="text" class="span7" placeholder="File Name (Default: /home/drm/mdi/ff.mdi)" value="
<?php
$Temp = $row["FFFileName"];	
												if($Temp == '/home/drm/mdi/ff.mdi' || $Temp == NULL){
													echo"File Name (Default: /home/drm/mdi/ff.mdi)";
												}
												else{
													echo $Temp;
												}
?>												
												
												" name="FFFileName" onchange="logic(this.name, this.value)">
											</div>
										</div>
										
										<div class="tab-pane" id="tab303">
											<div class="span10 offset1" >
												<div class="page-header">
												<h5>PFT Enabled:</h5>
												</div>
												<div id="PFTAlert">
												</div>

												<label class="checkbox">
												<input type="checkbox" name="PFTEnabled" value="1" onclick="logic(this.name, this.value)"
<?php
$Temp = $row["PFTEnabled"];	
												if($Temp == "1"){
													echo"checked>";
												}
												else{
													echo ">";
												}
?>													
												  Check to enable PFT output
												</label>
												<div class="accordion" id="accordion3">
														  <div class="accordion-group">
															<div class="accordion-heading">
															  <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#collapseOne">
																PFT PayloadMTU
															  </a>
															</div>
															<div id="collapseOne" class="accordion-body collapse in">
															  <div class="accordion-inner">
																<script>
																  $(function() {
																	var spinner = $( "#spinnerPFTPayloadMtu" ).spinner();
																 
																	$( "#spinnerPFTPayloadMtu" ).spinner({ max: 16384 });
																	$( "#spinnerPFTPayloadMtu" ).spinner({ min: 50 });
																 
																	
																  });
																  </script>
																<p>
																  <label for="spinnerPFTPayloadMtu">Select a value for PFTPayloadMtu:</label>
																  <input id="spinnerPFTPayloadMtu" name="PFTPayloadMtu" value="
<?php
$Temp = $row["PFTPayloadMtu"];	
												if($Temp == '1456' || $Temp == NULL){
													echo"1456";
												}
												else{
													echo $Temp;
												}
?>																	  
																 " onchange="logic(this.name, this.value)"/>
																</p>
															  </div>
															</div>
														  </div>
														  <div class="accordion-group">
															<div class="accordion-heading">
															  <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#collapseTwo">
																PFT Protection
															  </a>
															</div>
															<div id="collapseTwo" class="accordion-body collapse">
															  <div class="accordion-inner">
																<label class="checkbox">
																<input type="checkbox" name="PFTProtection" value="1" onclick="logic(this.name, this.value)"
<?php
$Temp = $row["PFTProtection"];	
												if($Temp == "1"){
													echo"checked>";
												}
												else{
													echo ">";
												}
?>																	
																  Check to enable PFT Protection
																</label>
																
																<script>
																  $(function() {
																	var spinner = $( "#spinnerPFTStrength" ).spinner();
																 
																	$( "#spinnerPFTStrength" ).spinner({ max: 5 });
																	$( "#spinnerPFTStrength" ).spinner({ min: 0});
																 
																	
																  });
																  </script>
																<p>
																  <label for="spinnerPFTStrength">Select a value for Strength:</label>
																  <input id="spinnerPFTStrength" name="PFTStrength" value="
<?php
$Temp = $row["PFTStrength"];	
												if($Temp == '0' || $Temp == NULL){
													echo"0";
												}
												else{
													echo $Temp;
												}
?>																	  
																  " onchange="logic(this.name, this.value)"/>
																</p>
															  </div>
															</div>
														  </div>
														   <div class="accordion-group">
															<div class="accordion-heading">
															  <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#collapseThree">
																PFT Transportation
															  </a>
															</div>
															<div id="collapseThree" class="accordion-body collapse">
															  <div class="accordion-inner">
																<label class="checkbox">
																<input type="checkbox" name="PFTTransportation" value="1" onclick="logic(this.name, this.value)"
<?php
$Temp = $row["PFTTransportation"];	
												if($Temp == "1"){
													echo"checked>";
												}
												else{
													echo ">";
												}
?>																	
																  Check to enable PFT Transportation
																</label>
																  <label>PFTSource</label>
																<input type="text" class="span5" placeholder="PFTSource" value="
<?php
$Temp = $row["PFTSource"];	
												if($Temp == NULL){
													echo"PFTSource";
												}
												else{
													echo $Temp;
												}
?>																	
																" name="PFTSource" onchange="logic(this.name, this.value)"><br>
																  <label>PFTDestination</label>
																<input type="text" class="span5" placeholder="PFTDestination" value="
<?php
$Temp = $row["PFTDestination"];	
												if($Temp == NULL){
													echo"PFTDestination";
												}
												else{
													echo $Temp;
												}
?>																		
																" name="PFTDestination" onchange="logic(this.name, this.value)">	
															  </div>
															</div>
														  </div>
												</div>
												
												
												
												
												
											</div>
										</div>
									  
								</div>
							</div>	 
							
							
						
						  </div>
						</div>
						 
						<!-- This helps control what tab is shown first. For greater detail checkout first link.-->
						<!--<script>
						  $(function () {
							$('#myTab li:eq(0) a').tab('show');
						  })
						</script>-->
					
						
						
				</div>
				
				<div>
						<ul class="pager" id="Page1">
						  <li class="previous disabled" id="previousBtn">
							<a href="#" onclick="change()">&larr; Previous</a>
						  </li>
						  <li class="next" id="nextBtn">
							<a href="#" onclick="change(102)">Next &rarr;</a>
						  </li>
						</ul>	
						
						
						  
						
						
						

				</div>
			</div>

				
				
			<div class="span4 ">
					<div class="span12 well-white">
						<div class="page-header">
						  <h1><small>HUD</small></h1>
						</div>
						<!--Div holds hold the pie chart-->
							
						<div class="accordion" id="accordion2">
								  <div class="accordion-group">
									<div class="accordion-heading">
									  <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne2">
										Bandwidth Graph
									  </a>
									</div>
									<div id="collapseOne2" class="accordion-body collapse in">
									  <div class="accordion-inner">
											<div id="chartContainer" style="min-width: 200px; height: 225px; margin: 0 auto"></div>
									  </div>
									</div>
								  </div>
								  <div class="accordion-group">
									<div class="accordion-heading">
									  <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo2">
										Active Configuration
									  </a>
									</div>
									<div id="collapseTwo2" class="accordion-body collapse">
									  <div class="accordion-inner">
										<div id="ActiveConfigSum">
										</div>
									  </div>
									</div>
								  </div>
								   <div class="accordion-group">
									<div class="accordion-heading">
									  <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseThree2">
										Current Errors
									  </a>
									</div>
									<div id="collapseThree2" class="accordion-body collapse">
									  <div class="accordion-inner">
										<div id="ErrorListing">
											
										</div>
									  </div>
									</div>
								  </div>
						</div>
					</div>
					<br> <br>			
			</div>	
		</div>	
	</div>	
	<!-- For test reporting only-->	
	<div class="navbar navbar-fixed-bottom">
  <div class="navbar-inner">
    <a class="brand" href="#bugModal" class="btn" data-toggle="modal">Report Bug</a>
  </div>
  
</div>
	<div id="bugModal" class="modal hide fade in" style="display: none;"> 
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
			<h3>Report A Bug</h3>
		</div>
		<div class="modal-body">
			<Label> Subject:</label>
			<input type="text" id="BugSubject" placeholder="Subject">
			<Label> Discription:</label>
			<textarea id="BugDesc" rows="3"></textarea>
		</div>
		<div class="modal-footer">
			<a class="btn" data-dismiss="modal">Cancel</a>
			<input type="button" value="Submit" onclick="submitBug();" class ="btn btn-info">
		</div>
	</div>
	
	
	<div id="modalStorage">
		
	</div>

</body>
</html>
