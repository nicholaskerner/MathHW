<?php
	//Start session
	session_start();

	$errorCheck = "true";
	require('config.php');

	//Check for session logout
	if (isset($_POST["signout"])) {
		session_destroy();
		header("Location: index.php");
		exit;
	}

	//Check session status
	if (!isset($_SESSION['Login'])) {
		header("Location: index.php");
		exit;
	}

	//Check for delete operation
	if (isset($_POST['deleteID'])) {
		require_once('lib/deleteFile.php');
		deleteFile($_POST['deleteID']);
	}

	//Check for copy operation
	if (isset($_POST['copyID'])) {
		require_once('lib/copyFile.php');
		copyFile($_POST['copyID']);
	}

	//Check for rename operation
	if (isset($_POST['renameID']) && isset($_POST['rename'])) {
		require_once('lib/renameFile.php');
		renameFile($_POST['rename'], $_POST['renameID']);
	}

	//Check for preset operation
	if (isset($_POST['presetID'])) {
		require_once('lib/presetToggle.php');
		presetToggle($_POST['presetID']);
	}

	//Check for open operation
	if (isset($_POST['openID'])) {
		$_SESSION['FileID'] = $_POST['openID'];
		header("Location: wizard.php");
		exit;
	}

	//Check for upload operation
	if (isset($_FILES['upload'])) {
		require_once('lib/uploadFile.php');
		$uploadCheck = uploadFile($_FILES['upload']);

		if ($uploadCheck != "true") {
			$errorCheck = "<strong>Upload failed</strong> ".$uploadCheck;
		}

		//Delete uploaded file
		shell_exec("rm ".$uploadDir.$_FILES['upload']['name']);
	}

	//Check for download operation
	if (isset($_POST['downloadID'])) {
		require_once('lib/downloadFile.php');
		$downloadCheck = downloadFile($_POST['downloadID']);

		if ($downloadCheck[0] == "true") {
			header("Location: ini/".$downloadCheck[1]);
			exit;
		}

		else {
			$errorCheck = "<strong>Download failed</strong> ".$downloadCheck[0];
		}
	}

	//Check for new file operation
	if (isset($_POST['newNameID'])) {
		require_once('lib/newFile.php');
		$_SESSION['FileID'] = newFile($_POST['newNameID'], $_POST['newName']);
		header("Location: wizard.php");
		exit;
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Content Server</title>
		<link rel="stylesheet" href="CSS/file.css" type="text/css"/>
		<link rel="stylesheet" href="CSS/customWells.css" type="text/css"/>
		<link href="bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css">
		<link href="FortAwesome/css/font-awesome.css" rel="stylesheet" type="text/css">
		<script src="bootstrap/js/jquery.min.js"></script>
		<script type="text/javascript" src="js/FilePage.js"></script>
		<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
		<script src="js/jquery.tablesorter.min.js"></script>
		<script src="js/jquery.tablesorter.pager.js"></script>
		<script type="text/javascript" src="wizardLogic/wizard.js"></script>
		<script type="text/javascript" src="lib/Bug/submitBugs.js"></script>
		<!-- loads tooltips for page-->
		<script >
			 $(document).ready(function () {
				$("[rel=tooltip]").tooltip();
			  });
		</script>
	</head>
<body>
	<div class="row-fluid">
		<div class="span12 well-white">
			<h1 class=" pull-left" style="color: #049cdb;" > <i class="icon-music"></i> eRadioConfig </h1>
			<div class=" pull-right" style="margin-bottom:0px; padding-bottom:0px">

<?php
	//Check user type to determine if admin
	if ($_SESSION['UserType'] == "Admin") {
		echo "\t\t".'<div class="btn-group">'.PHP_EOL;
		echo "\t\t\t".'<button class="btn btn-inverse" onclick="openAdminTools()"><i class=\icon-cogs"></i> Admin Tools</button>'.PHP_EOL;
		echo "\t\t\t".'<button class="btn btn-primary" onclick="signout()"> <i class="icon-signout"></i> Signout</button>'.PHP_EOL;
		echo "\t\t".'</div>'.PHP_EOL;
	}

	else {
		echo "\t\t".'<div class="btn-group">'.PHP_EOL;
		echo "\t\t\t".'<button class="btn btn-inverse" onclick="openUserSettings()"><i class="icon-cogs"></i> User Settings</button>'.PHP_EOL;
		echo "\t\t\t".'<button class="btn btn-primary" onclick="signout()"> <i class="icon-signout"></i> Signout</button>'.PHP_EOL;
		echo "\t\t".'</div>'.PHP_EOL;
	}
?>

			</div>
		</div>
	</div>

<?php
	if ($errorCheck != "true") {
		echo "\t".'<div class="alert alert-error" align="center">'.PHP_EOL;
		echo "\t\t".'<button type="button" class="close" data-dismiss="alert">&times;</button>'.PHP_EOL;
		echo "\t\t".$errorCheck.PHP_EOL;
		echo "\t".'</div>'.PHP_EOL;
	}
?>

	<div class="container-fluid">	
		<div class="row-fluid">
			<div class="span3 well-white">
				<button class="btn btn-large btn-block btn-primary" onclick="$('#createChecker').modal('show')" type="button"><i class="icon-file"></i> Create Configuration File</button>
				<!-- The Empty 'href="#"' are there to provide the UI element of a finger/hand clicker. DO NOT REMOVE-->
				<ul class="nav nav-list">
					<li  class="divider"></li>
					<li class="nav-header">Moving Files</li>
					<li id="download" class="disabled"><a href="#" onclick="submitTableChange('download')"><i class="icon-download-alt"></i> Download</a></li>
					<li id="upload" class=""><a href="#" href="#" onclick="submitTableChange('upload')"><i class="icon-upload"></i> Upload</a></li>
					<li class="divider"></li>
					<li class="nav-header">More</li>
					<li id="open" class="disabled"><a href="#" onclick="submitTableChange('open')"><i class="icon-edit"></i> Open/Edit</a></li>
					<li id="delete" class="disabled"><a href="#" onclick="submitTableChange('delete')"><i class="icon-trash"></i> Delete</a></li>
					<li id="copy" class="disabled"><a href="#" onclick="submitTableChange('copy')"><i class="icon-copy"></i> Make A Copy</a></li>
					<li id="rename" class="disabled"><a href="#" onclick="submitTableChange('rename')"><i class="icon-pencil"></i> Rename</a></li>
					<li id="preset" class="disabled"><a href="#" onclick="submitTableChange('preset')"><i class="icon-star-empty"></i> Toggle Preset</a></li>
				</ul>
			</div>
			<div class="span9 well-white">
				<!-- Uncomment the script below to inable sorting-->
				<!--<script >
				  $(document).ready(function() 
						{ 
							$("#theTable").tablesorter(); 
						} 
					); 
				</script>-->
				 <table class=" table table-hover" id="theTable">
					<thead>
						<tr>
							<th class="{sorter: false}" style="width: 5%">
								<label class="checkbox">
									<input type="checkbox" onclick="checkAllBoxes()" id="checkAll" rel="tooltip" data-placement="top" title="Check/UnCheck All">
								</label>
							</th>
							<th style="width: 1%"></th>
							<th style="color: #049cdb;">TITLE <i class=" icon-sort"></i></th>
							<th>OWNER <i class=" icon-sort"></i></th>
							<th>LAST MODIFIED <i class=" icon-sort"></i></th>
						</tr>
					</thead>
					<tbody>
						<form id="checkboxForm"	action="file.php" method="POST">	

<?php
	//Connect to the database
	$database = new PDO('mysql:host='.$hostname.';dbname='.$databaseName, $username, $password);

	//Execute the query
	$fileQuery = $database->query("SELECT `AutoSave`.FileID, `AutoSave`.FileName, `AutoSave`.Preset, `AutoSave`.IsRealFile, `UserInfo`.Username, `AutoSave`.LastModified FROM `UserInfo`, `AutoSave` WHERE UserInfo.UserID = `AutoSave`.UserID AND `AutoSave`.FileID <> '0' AND `AutoSave`.FileID <> '1'");

	while ($row = $fileQuery->fetch(PDO::FETCH_ASSOC)) {
		echo "\t\t\t".'<tr onclick="checkBox(\''.$row{'FileID'}.'\')">'.PHP_EOL;
		echo "\t\t\t\t".'<td >'.PHP_EOL;
		echo "\t\t\t\t\t".'<label class="checkbox">'.PHP_EOL;
		echo "\t\t\t\t\t\t".'<input id="'.$row{'FileID'}.'" onclick="checkBox(\''.$row{'FileID'}.'\')" type="checkbox" class="checkBox" name="files" value="'.$row{'FileID'}.'">'.PHP_EOL;
		echo "\t\t\t\t\t".'</label>'.PHP_EOL;
		echo "\t\t\t\t".'</td>'.PHP_EOL;
		echo "\t\t\t\t".'<input type="hidden" id="0'.$row{'FileID'}.'" value="'.$row{'FileName'}.'" style="display:none"/>'.PHP_EOL;
	

		if ($row{'Preset'}) {
			echo ' <td><font class="pull-right" color="#46a546"><i class="icon-star" rel="tooltip" data-placement="left" title="Preset File"></i></font></td>';
			echo "\t\t\t\t".'<td>'.$row{'FileName'}.'</td>'.PHP_EOL;
		}

		else if ($row{'IsRealFile'}) {
			echo ' <td><font class="pull-right" color=" #049cdb"><i class="icon-save" rel="tooltip" data-placement="left" title="Valid Saved File"></i></font></td>';
			echo "\t\t\t\t".'<td>'.$row{'FileName'}.'</td>'.PHP_EOL;
		}

		else {
			echo ' <td><font class="pull-right" color=" #f89406"><i class="icon-lightbulb" rel="tooltip" data-placement="left" title="Auto Saved File"></i></font></td>';
			echo "\t\t\t\t".'<td>'.$row{'FileName'}.'</td>'.PHP_EOL;
		}

		echo "\t\t\t\t".'<td>'.$row{'Username'}.'</td>'.PHP_EOL;
		echo "\t\t\t\t".'<td>'.date("n/j/Y g:ia",strtotime($row{'LastModified'})).'</td>'.PHP_EOL;
		echo "\t\t\t".'</tr>'.PHP_EOL;
	}
?>

						</tbody>
					</table>
					<input id="action" type="hidden" name="action">
				</form>
				<div id="pager">
				</div>
			</div>
		</div>
	</div>
	<div id="confirmDelete" class="modal hide fade in" style="display: none;">  
		<div class="modal-header">
			<a class="close" data-dismiss="modal">x</a>
			<h3>Confirm Delete</h3>
		</div>
		<form class="form-horizontal" action="file.php" method="post">
			<fieldset>
				<div class="modal-body">
					<p>Are you sure you would like to delete the selection?</p>
				</div>
				<div class="modal-footer">
					<button name="deleteID" id="deleteID" type="submit" class="btn btn-danger">Delete Selection</button>
					<a class="btn" data-dismiss="modal">Cancel</a>
				</div>
			</fieldset>
		</form>
	</div>
	<div id="checkRename" class="modal hide fade in" style="display: none;">  
		<div class="modal-header">
			<a class="close" data-dismiss="modal">x</a>
			<h3>Rename File</h3>
		</div>
		<form class="form-horizontal" action="file.php" name="renameForm" method="post">
			<fieldset>
				<div class="modal-body">
					<div class="control-group">
						<label class="control-label" for="rename">New File Name</label>
						<div class="controls">
							<input type="text" class="input-xlarge" id="rename" name="rename">
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button name="renameID" id="renameID" type="submit" class="btn btn-info">Rename</button>
					<a class="btn" data-dismiss="modal">Cancel</a>
				</div>
			</fieldset>
		</form>
	</div>
	<div id="newFileName" class="modal hide fade in" style="display: none;">  
		<div class="modal-header">
			<a class="close" data-dismiss="modal">x</a>
			<h3>New File Name</h3>
		</div>
		<form class="form-horizontal" action="file.php" name="newFileForm" method="post">
			<fieldset>
				<div class="modal-body">
					<div class="control-group">
						<label class="control-label" for="newName">New File Name</label>
						<div class="controls">
							<input type="text" class="input-xlarge" id="newName" name="newName">
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button name="newNameID" id="newNameID" type="submit" class="btn btn-info">New Name</button>
					<a class="btn" data-dismiss="modal">Cancel</a>
				</div>
			</fieldset>
		</form>
	</div>
	<div id="uploadFile" class="modal hide fade in" style="display: none;">
		<div class="modal-header">
			<a class="close" data-dismiss="modal">x</a>
			<h3>Upload File</h3>
		</div>
		<form class="form-horizontal" action="file.php" name="uploadForm" method="post" enctype="multipart/form-data">
			<fieldset>
				<div class="modal-body">
					<div class="control-group">
						<div class="controls">
							<input type="file" id="upload" name="upload">
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button name="uploadID" id="uploadID" type="submit" class="btn btn-info">Upload</button>
					<a class="btn" data-dismiss="modal">Cancel</a>
				</div>
			</fieldset>
		</form>
	</div>
	<div id="createChecker" class="modal hide fade in" style="display: none;">  
		<div class="modal-header">
			<a class="close" data-dismiss="modal">x</a>
			<h3>Create Configuration File</h3>
		</div>
		<div class="modal-body">
			<form class="form-horizontal">
				<fieldset>
					<div class="control-group">
						<table class="table table-hover">
							<tr>
								<th>TITLE</th>
								<th>OWNER</th>
								<th>LAST MODIFIED</th>
								<th>OPTION</th>
							</tr>

<?php
	//Execute the query
	$createQuery = $database->query("SELECT `AutoSave`.FileID, `AutoSave`.FileName, `AutoSave`.Preset, `UserInfo`.Username, `AutoSave`.LastModified FROM `UserInfo`, `AutoSave` WHERE UserInfo.UserID = `AutoSave`.UserID");

	while ($row = $createQuery->fetch(PDO::FETCH_ASSOC)) {
		if ($row{'Preset'}) {
			echo "\t\t\t\t\t\t\t".'<tr>'.PHP_EOL;
			echo "\t\t\t\t\t\t\t\t".'<td>'.$row{'FileName'}.'</td>'.PHP_EOL;
			echo "\t\t\t\t\t\t\t\t".'<td>'.$row{'Username'}.'</td>'.PHP_EOL;
			echo "\t\t\t\t\t\t\t\t".'<td>'.date("n/j/Y g:ia",strtotime($row{'LastModified'})).'</td>'.PHP_EOL;
			echo "\t\t\t\t\t\t\t\t".'<td><input type="button" value="Select" onclick="selectFile('.$row{'FileID'}.');" class ="btn btn-success"></td>'.PHP_EOL;
			echo "\t\t\t\t\t\t\t".'</tr>'.PHP_EOL;
		}
	}

	//Close the database connection
	$database = null;
?>

							<tr>
								<td>New File</td>
								<td>None</td>
								<td>New</td>
								<td><input type="button" value="Select" onclick="selectFile(1);" class ="btn btn-info"></td>
							</tr>
						</table>
					</div>
				</fieldset>
			</form>
		</div>
	</div>
	<div class="navbar navbar-fixed-bottom">
		<div class="navbar-inner">
			<a class="brand" href="#bugModal" class="btn" data-toggle="modal">Report Bug</a>
		</div>
	</div>
	<div id="bugModal" class="modal hide fade in" style="display: none;"> 
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
			<h3>Report A Bug</h3>
		</div>
		<div class="modal-body">
			<Label> Subject:</label>
			<input type="text" id="BugSubject" placeholder="Subject">
			<Label> Discription:</label>
			<textarea id="BugDesc" rows="3"></textarea>
		</div>
		<div class="modal-footer">
			<a class="btn" data-dismiss="modal">Cancel</a>
			<input type="button" value="Submit" onclick="submitBug();" class ="btn btn-info">
		</div>
	</div>
</body>
</html>
