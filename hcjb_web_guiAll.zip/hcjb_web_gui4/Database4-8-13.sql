-- phpMyAdmin SQL Dump
-- version 3.5.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 08, 2013 at 11:00 PM
-- Server version: 5.1.67
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `greg`
--

-- --------------------------------------------------------

--
-- Table structure for table `AutoSave`
--

DROP TABLE IF EXISTS `AutoSave`;
CREATE TABLE IF NOT EXISTS `AutoSave` (
  `FileID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `LastModified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `FileName` varchar(64) DEFAULT NULL,
  `IsMostRecent` tinyint(1) DEFAULT '0',
  `IsRealFile` tinyint(1) DEFAULT '0',
  `FileLocation` varchar(64) DEFAULT NULL COMMENT 'Deprecated value',
  `ConfigurationDesc` varchar(256) DEFAULT NULL,
  `Location` int(11) DEFAULT NULL COMMENT 'Planned to use in original wizard design, no longer used',
  `SpectrumOcc` int(11) DEFAULT NULL,
  `Robustness` int(11) DEFAULT NULL,
  `InterleaverDepth` int(11) DEFAULT NULL,
  `MSCMode` int(11) DEFAULT NULL COMMENT 'Determines SDC too',
  `SDCMode` int(11) DEFAULT NULL,
  `BaseEnhancementFlag` int(11) DEFAULT NULL COMMENT 'Old variable, not in wizard',
  `ProtAInt` int(11) DEFAULT NULL,
  `ProtAValue` int(11) DEFAULT NULL,
  `ProtBInt` int(11) DEFAULT NULL,
  `ProtBValue` int(11) DEFAULT NULL,
  `ProtHValue` int(11) DEFAULT NULL,
  `ProtHInt` int(11) DEFAULT NULL,
  `HierarchicalBytes` int(11) DEFAULT NULL COMMENT 'Possibly not needed',
  `AmDRM` int(11) DEFAULT NULL,
  `S0DataLengthA` int(11) DEFAULT NULL,
  `S0DataLengthB` int(11) DEFAULT NULL,
  `S0ServiceLabel` varchar(64) DEFAULT NULL,
  `S0ServiceID` int(11) DEFAULT NULL COMMENT 'Should be hex value',
  `S0CASystemUsed` int(11) DEFAULT NULL,
  `S0LanguageInt` int(11) DEFAULT NULL,
  `S0LanguageCode` varchar(3) DEFAULT NULL COMMENT '3 character code for the language',
  `S0CountryInt` int(11) DEFAULT NULL,
  `S0CountryCode` varchar(2) DEFAULT NULL COMMENT 'Possibly not needed',
  `S0AudioDataFlag` int(11) DEFAULT NULL,
  `S0ServiceDesc` int(11) DEFAULT NULL COMMENT '0-31 code for type or program',
  `S0StreamID` int(11) DEFAULT NULL,
  `S0AudioCodec` int(11) DEFAULT NULL,
  `S0SBRFlag` tinyint(1) DEFAULT NULL COMMENT 'Codec May Effect',
  `S0AudioMode` int(11) DEFAULT NULL,
  `S0AudioSamplingRate` int(11) DEFAULT NULL,
  `S0TextFlag` tinyint(1) DEFAULT NULL,
  `S0EnhancementFlag` int(11) DEFAULT NULL,
  `S0Source` int(11) DEFAULT NULL,
  `S0AudioFileName` varchar(255) DEFAULT NULL,
  `S0RepeatAudio` int(11) DEFAULT NULL,
  `S0CoderField` int(11) DEFAULT NULL COMMENT 'May not be needed',
  `S1DataLengthA` int(11) DEFAULT NULL,
  `S1DataLengthB` int(11) DEFAULT NULL,
  `S1ServiceLabel` varchar(64) DEFAULT NULL,
  `S1ServiceID` int(11) DEFAULT NULL,
  `S1CASystemUsed` int(11) DEFAULT NULL,
  `S1LanguageInt` int(11) DEFAULT NULL,
  `S1LanguageCode` varchar(3) DEFAULT NULL,
  `S1CountryInt` int(11) DEFAULT NULL,
  `S1CountryCode` varchar(2) DEFAULT NULL,
  `S1AudioDataFlag` int(11) DEFAULT NULL,
  `S1ServiceDesc` int(11) DEFAULT NULL,
  `S1StreamID` int(11) DEFAULT NULL,
  `S1AudioCodec` int(11) DEFAULT NULL,
  `S1SBRFlag` tinyint(1) DEFAULT NULL,
  `S1AudioMode` int(11) DEFAULT NULL,
  `S1AudioSamplingRate` int(11) DEFAULT NULL,
  `S1TextFlag` tinyint(1) DEFAULT NULL,
  `S1EnhancementFlag` int(11) DEFAULT NULL,
  `S1Source` int(11) DEFAULT NULL COMMENT 'Needs to be included',
  `S1AudioFileName` varchar(255) DEFAULT NULL,
  `S1RepeatAudio` int(11) DEFAULT NULL,
  `S1CoderField` int(11) DEFAULT NULL,
  `S2DataLengthA` int(11) DEFAULT NULL,
  `S2DataLengthB` int(11) DEFAULT NULL,
  `S2ServiceLabel` varchar(64) DEFAULT NULL,
  `S2ServiceID` int(11) DEFAULT NULL,
  `S2CASystemUsed` int(11) DEFAULT NULL,
  `S2LanguageInt` int(11) DEFAULT NULL,
  `S2LanguageCode` varchar(3) DEFAULT NULL,
  `S2CountryInt` int(11) DEFAULT NULL,
  `S2CountryCode` varchar(2) DEFAULT NULL,
  `S2AudioDataFlag` int(11) DEFAULT NULL,
  `S2ServiceDesc` int(11) DEFAULT NULL,
  `S2StreamID` int(11) DEFAULT NULL,
  `S2AudioCodec` int(11) DEFAULT NULL,
  `S2SBRFlag` tinyint(1) DEFAULT NULL,
  `S2AudioMode` int(11) DEFAULT NULL,
  `S2AudioSamplingRate` int(11) DEFAULT NULL,
  `S2TextFlag` tinyint(1) DEFAULT NULL,
  `S2EnhancmentFlag` int(11) DEFAULT NULL,
  `S2Source` int(11) DEFAULT NULL COMMENT 'Needs to be Included',
  `S2AudioFileName` varchar(255) DEFAULT NULL,
  `S2RepeatAudio` int(11) DEFAULT NULL,
  `S2CoderField` int(11) DEFAULT NULL,
  `S3DataLengthA` int(11) DEFAULT NULL,
  `S3DataLengthB` int(11) DEFAULT NULL,
  `S3ServiceLabel` varchar(64) DEFAULT NULL,
  `S3ServiceID` text,
  `S3CASystemUsed` int(11) DEFAULT NULL,
  `S3LanguageInt` int(11) DEFAULT NULL,
  `S3LanguageCode` varchar(3) DEFAULT NULL,
  `S3CountryID` int(11) DEFAULT NULL,
  `S3CountryCode` varchar(2) DEFAULT NULL,
  `S3AudioDataFlag` int(11) DEFAULT NULL,
  `S3ServiceDesc` int(11) DEFAULT NULL,
  `S3StreamID` int(11) DEFAULT NULL,
  `S3AudioCodec` int(11) DEFAULT NULL,
  `S3SBRFlag` tinyint(1) DEFAULT NULL,
  `S3AudioMode` int(11) DEFAULT NULL,
  `S3AudioSamplingRate` int(11) DEFAULT NULL,
  `S3TextFlag` tinyint(1) DEFAULT NULL,
  `S3EnhancementFlag` int(11) DEFAULT NULL,
  `S3Source` int(11) DEFAULT NULL COMMENT 'Needs to be included',
  `S3AudioFileName` varchar(255) DEFAULT NULL,
  `S3RepeatAudio` int(11) DEFAULT NULL,
  `S3CoderField` int(11) DEFAULT NULL,
  `IPEnabled` int(11) DEFAULT NULL,
  `IPAddress` varchar(64) DEFAULT NULL,
  `IPPort` int(11) DEFAULT NULL,
  `IP_TCP_UDP` int(11) DEFAULT NULL,
  `FEEnabled` int(11) DEFAULT NULL,
  `FFFileName` varchar(255) DEFAULT NULL,
  `PFTEnabled` int(11) DEFAULT NULL,
  `PFTPayloadMtu` int(11) DEFAULT NULL,
  `PFTProtection` int(11) DEFAULT NULL,
  `PFTStrength` int(11) DEFAULT NULL,
  `PFTTransportation` int(11) DEFAULT NULL,
  `PFTSource` int(11) DEFAULT NULL,
  `PFTDestination` int(11) DEFAULT NULL,
  `VUMeter` int(11) DEFAULT NULL,
  `Timing` int(11) DEFAULT NULL,
  `Clocktime` int(11) DEFAULT NULL,
  `Preset` tinyint(1) NOT NULL,
  PRIMARY KEY (`FileID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=144 ;

--
-- Dumping data for table `AutoSave`
--

INSERT INTO `AutoSave` (`FileID`, `UserID`, `LastModified`, `FileName`, `IsMostRecent`, `IsRealFile`, `FileLocation`, `ConfigurationDesc`, `Location`, `SpectrumOcc`, `Robustness`, `InterleaverDepth`, `MSCMode`, `SDCMode`, `BaseEnhancementFlag`, `ProtAInt`, `ProtAValue`, `ProtBInt`, `ProtBValue`, `ProtHValue`, `ProtHInt`, `HierarchicalBytes`, `AmDRM`, `S0DataLengthA`, `S0DataLengthB`, `S0ServiceLabel`, `S0ServiceID`, `S0CASystemUsed`, `S0LanguageInt`, `S0LanguageCode`, `S0CountryInt`, `S0CountryCode`, `S0AudioDataFlag`, `S0ServiceDesc`, `S0StreamID`, `S0AudioCodec`, `S0SBRFlag`, `S0AudioMode`, `S0AudioSamplingRate`, `S0TextFlag`, `S0EnhancementFlag`, `S0Source`, `S0AudioFileName`, `S0RepeatAudio`, `S0CoderField`, `S1DataLengthA`, `S1DataLengthB`, `S1ServiceLabel`, `S1ServiceID`, `S1CASystemUsed`, `S1LanguageInt`, `S1LanguageCode`, `S1CountryInt`, `S1CountryCode`, `S1AudioDataFlag`, `S1ServiceDesc`, `S1StreamID`, `S1AudioCodec`, `S1SBRFlag`, `S1AudioMode`, `S1AudioSamplingRate`, `S1TextFlag`, `S1EnhancementFlag`, `S1Source`, `S1AudioFileName`, `S1RepeatAudio`, `S1CoderField`, `S2DataLengthA`, `S2DataLengthB`, `S2ServiceLabel`, `S2ServiceID`, `S2CASystemUsed`, `S2LanguageInt`, `S2LanguageCode`, `S2CountryInt`, `S2CountryCode`, `S2AudioDataFlag`, `S2ServiceDesc`, `S2StreamID`, `S2AudioCodec`, `S2SBRFlag`, `S2AudioMode`, `S2AudioSamplingRate`, `S2TextFlag`, `S2EnhancmentFlag`, `S2Source`, `S2AudioFileName`, `S2RepeatAudio`, `S2CoderField`, `S3DataLengthA`, `S3DataLengthB`, `S3ServiceLabel`, `S3ServiceID`, `S3CASystemUsed`, `S3LanguageInt`, `S3LanguageCode`, `S3CountryID`, `S3CountryCode`, `S3AudioDataFlag`, `S3ServiceDesc`, `S3StreamID`, `S3AudioCodec`, `S3SBRFlag`, `S3AudioMode`, `S3AudioSamplingRate`, `S3TextFlag`, `S3EnhancementFlag`, `S3Source`, `S3AudioFileName`, `S3RepeatAudio`, `S3CoderField`, `IPEnabled`, `IPAddress`, `IPPort`, `IP_TCP_UDP`, `FEEnabled`, `FFFileName`, `PFTEnabled`, `PFTPayloadMtu`, `PFTProtection`, `PFTStrength`, `PFTTransportation`, `PFTSource`, `PFTDestination`, `VUMeter`, `Timing`, `Clocktime`, `Preset`) VALUES
(142, 7, '2013-04-03 20:37:58', 'hi', 1, 1, NULL, '', NULL, -1, -1, -1, -1, -1, 0, 0, NULL, -1, NULL, NULL, 0, 0, 0, 0, 0, 'HCJB Global', 0, 0, 0, '---', NULL, '--', 2, 0, 0, 0, 1, 0, 3, 0, 0, 6, 'Analog Stereo', 1, 0, 0, 0, 'HCJB Global', 0, 0, 0, '---', NULL, '--', 2, 0, 1, 0, 1, 0, 3, 0, 0, 6, 'Analog Stereo', 1, 0, 0, 0, 'HCJB Global', 0, 0, 0, '---', NULL, '--', 2, 0, 2, 0, 1, 0, 3, 0, 0, 6, 'Analog Stereo', 1, 0, 0, 0, 'HCJB Global', '0', 0, 0, '---', NULL, '--', 2, 0, 3, 0, 1, 0, 3, 0, 0, 6, 'Analog Stereo', 1, 0, 0, '127.0.0.1', 0, 0, 0, '/home/drm/mdi/FF.mdi', 0, 1456, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(77, 3, '2013-03-27 18:14:10', 'Button2.ini', 1, 0, 'upload/.Button2.ini', 'Greg											', NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, '', 0, 0, 0, '---', 0, '--', 2, 0, 0, 0, 0, 0, 1, 0, 0, 6, '', 0, 0, 0, 0, '', 0, 0, 0, '---', 0, '--', 2, 0, 1, 0, 0, 0, 1, 0, 0, 6, '', 0, 0, 0, 0, '', 0, 0, 0, '---', 0, '--', 2, 0, 2, 0, 0, 0, 1, 0, 0, 6, '', 0, 0, 0, 0, '', '0', 0, 0, '---', 0, '--', 2, 0, 3, 0, 0, 0, 1, 0, 0, 6, '', 0, 0, 0, '', 0, 0, 0, '', 0, 1456, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(133, 2, '2013-04-06 21:19:14', 'Greg Test File2', 0, 0, NULL, '', NULL, 5, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, '', 0, 0, 0, '', 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, '', 0, 0, 0, '', 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, '', 0, 0, 0, '', 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, '', '', 0, 0, '', 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, 0, '', 0, 0, 0, '', 0, 1456, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(134, 2, '2013-03-27 16:17:00', 'Based on TestFile1.ini', 1, 0, '/home/nick/.TestFile1.ini', 'High bit rate SW - 10 kHz - weak protection - 27.44 kbps\n', NULL, 3, 1, 0, 0, 0, 0, 0, NULL, 3, NULL, NULL, 0, 0, 0, 0, 1372, 'HCJB Global\n', 10526976, 0, 5, 'eng', 0, '--', 0, 9, 0, 0, 1, 1, 3, 1, 0, 3, 'Analog Stereo\n', 1, 0, 0, 0, ' \n', 1193046, 0, 0, '---', 0, '--', 2, 0, 1, 0, 1, 0, 3, 0, 0, 6, ' \n', 1, 0, 0, 0, ' \n', 1193046, 0, 0, '---', 0, '--', 2, 0, 2, 0, 1, 0, 3, 0, 0, 6, ' \n', 1, 0, 0, 0, ' \n', '1193046\n', 0, 0, '---', 0, '--', 2, 0, 3, 0, 1, 0, 3, 0, 0, 6, ' \n', 1, 0, 1, '10.30.18.146\n', 10000, 0, 0, '/home/drm/mdi/ff.mdi\n', 0, 1456, 0, 0, 0, 0, 0, 1, 0, 0, 0),
(143, 7, '2013-03-27 18:08:38', 'yeeahh', 1, 1, '/home/nick/.TestFile1.ini', 'Sunshine\n\n												', NULL, 5, 0, 0, 0, 0, 0, 0, NULL, 3, NULL, NULL, 0, 0, 0, 0, 3598, 'Hcjb', 292, 0, 15, 'aar', 0, 'AW', 0, 13, 0, 0, 1, 2, 3, 1, 0, 3, 'Analog Stereo', 0, 0, 0, 0, '', 0, 0, 0, '---', 0, '--', 2, 0, 1, 0, 1, 1, 3, 1, 0, 6, '', 0, 0, 0, 0, '', 0, 0, 0, '---', 0, '--', 2, 0, 2, 0, 0, 0, 1, 1, 0, 6, '', 0, 0, 0, 0, '', '0', 0, 0, '---', 0, '--', 2, 0, 3, 0, 0, 0, 1, 1, 0, 6, '', 0, 0, 1, '10.30.18.146\n', 10000, 0, 0, '/home/drm/mdi/ff.mdi\n', 0, 1456, 0, 0, 0, 0, 0, 1, 0, 0, 0),
(0, NULL, '2013-03-23 18:05:48', 'BlankFile.ini', NULL, NULL, NULL, 'High bit rate SW - 10 kHz - weak protection - 27.44 kbps\n', NULL, 3, 1, 1, 0, 0, 0, 0, NULL, 1, NULL, NULL, 0, 0, 0, 0, 0, '', 0, 0, 0, '---', 0, '--', 2, 0, 0, 0, 0, 0, 0, 0, 0, 6, '', 0, 0, 0, 0, '', 0, 0, 0, '---', 0, '--', 2, 0, 1, 0, 0, 0, 0, 0, 0, 6, '', 0, 0, 0, 0, '', 0, 0, 0, '---', 0, '--', 2, 0, 2, 0, 0, 0, 0, 0, 0, 6, '', 0, 0, 0, 0, '', '0', 0, 0, '---', 0, '--', 2, 0, 3, 0, 0, 0, 0, 0, 0, 6, '', 0, 0, 0, '', 0, 0, 0, '', 0, 1456, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(132, 4, '2013-03-27 14:41:03', 'Based on TestFile1.ini', 1, 0, '/home/nick/.TestFile1.ini', 'High bit rate SW - 10 kHz - weak protection - 27.44 kbps\n', NULL, 3, 1, 0, 0, 0, 0, 0, NULL, 3, NULL, NULL, 0, 0, 0, 0, 1372, 'HCJB Global\n', 10526976, 0, 5, 'eng', 0, '--', 0, 9, 0, 0, 1, 1, 3, 1, 0, 3, 'Analog Stereo', 1, 0, 0, 0, ' \n', 1193046, 0, 0, '---', 0, '--', 2, 0, 1, 0, 1, 0, 3, 0, 0, 6, ' \n', 1, 0, 0, 0, ' \n', 1193046, 0, 0, '---', 0, '--', 2, 0, 2, 0, 1, 0, 3, 0, 0, 6, ' \n', 1, 0, 0, 0, ' \n', '1193046\n', 0, 0, '---', 0, '--', 2, 0, 3, 0, 1, 0, 3, 0, 0, 6, ' \n', 1, 0, 1, '10.30.18.146\n', 10000, 0, 0, '/home/drm/mdi/ff.mdi\n', 0, 1456, 0, 0, 0, 0, 0, 1, 0, 0, 0),
(118, 7, '2013-03-22 01:51:03', 'Copy of Button1.ini', 1, 1, NULL, 'High bit rate SW - 10 kHz - weak protection - 27.44 kbps', NULL, 3, 1, 0, 0, 0, 0, 0, NULL, 3, NULL, NULL, 0, 0, 0, 0, 1372, 'HCJB Global', 10526976, 0, 5, 'eng', NULL, '--', 0, 9, 0, 0, 1, 1, 3, 1, 0, 3, 'Analog Stereo', 1, 0, 0, 0, '', 1193046, 0, 0, '---', NULL, '--', 2, 0, 1, 0, 1, 0, 3, 0, 0, 6, '', 1, 0, 0, 0, '', 1193046, 0, 0, '---', NULL, '--', 2, 0, 2, 0, 1, 0, 3, 0, 0, 6, '', 1, 0, 0, 0, '', '1193046', 0, 0, '---', NULL, '--', 2, 0, 3, 0, 1, 0, 3, 0, 0, 6, '', 1, 0, 1, '10.30.18.146', 10000, 0, 0, '/home/drm/mdi/FF.mdi', 0, 1456, 0, 0, 0, 0, 0, 1, 0, 0, 0),
(80, 4, '2013-03-21 17:11:47', 'Based on TestFile1.ini', 1, 0, '/home/nick/.TestFile1.ini', 'High bit rate SW - 10 kHz - weak protection - 27.44 kbps\n', NULL, 3, 1, 0, 0, 0, 0, 0, NULL, 3, NULL, NULL, 0, 0, 0, 0, 1372, 'HCJB Global\n', 10526976, 0, 5, 'eng', NULL, '--', 0, 9, 0, 0, 1, 1, 3, 1, 0, 3, 'Analog Stereo\n', 1, 0, 0, 0, ' \n', 1193046, 0, 0, '---', NULL, '--', 2, 0, 1, 0, 1, 0, 3, 0, 0, 6, ' \n', 1, 0, 0, 0, ' \n', 1193046, 0, 0, '---', NULL, '--', 2, 0, 2, 0, 1, 0, 3, 0, 0, 6, ' \n', 1, 0, 0, 0, ' \n', '1193046\n', 0, 0, '---', NULL, '--', 2, 0, 3, 0, 1, 0, 3, 0, 0, 6, ' \n', 1, 0, 1, '10.30.18.146\n', 10000, 0, 0, '/home/drm/mdi/ff.mdi\n', 0, 1456, 0, 0, 0, 0, 0, 1, 0, 0, 0),
(98, 3, '2013-04-08 01:23:55', 'Button4.ini', 1, 1, NULL, 'Mode C Max Audio 21.62 kbps', NULL, 3, 2, 0, 0, 0, 0, 0, NULL, 3, NULL, NULL, 0, 0, 0, 0, 1081, 'HCJB Global', 10526976, 0, 5, 'eng', NULL, '--', 0, 9, 0, 0, 1, 1, 3, 1, 0, 3, 'Analog Stereo', 1, 0, 0, 0, '', 1193046, 0, 0, '---', NULL, '--', 2, 0, 1, 0, 1, 0, 3, 0, 0, 6, '', 1, 0, 0, 0, '', 1193046, 0, 0, '---', NULL, '--', 2, 0, 2, 0, 1, 0, 3, 0, 0, 6, '', 1, 0, 0, 0, '', '1193046', 0, 0, '---', NULL, '--', 2, 0, 3, 0, 1, 0, 3, 0, 0, 6, '', 1, 0, 1, '10.30.18.146', 10000, 0, 0, '/home/drm/mdi/FF.mdi', 0, 1456, 0, 0, 0, 0, 0, 1, 0, 0, 1),
(99, 3, '2013-03-27 16:17:52', 'Button1 with notes.ini', 1, 1, NULL, 'High bit rate SW - 10 kHz - weak protection - 27.44 kbps', NULL, 3, 1, 0, 0, 0, 0, 0, NULL, 3, NULL, NULL, 0, 0, 0, 0, 1372, 'HCJB Global', 10526976, 0, 5, 'eng', 0, '--', 0, 9, 0, 0, 1, 1, 3, 1, 0, 3, 'Analog Stereo', 1, 0, 0, 0, '', 1193046, 0, 0, '---', 0, '--', 2, 0, 1, 0, 1, 0, 3, 0, 0, 6, '', 1, 0, 0, 0, '', 1193046, 0, 0, '---', 0, '--', 2, 0, 2, 0, 1, 0, 3, 0, 0, 6, '', 1, 0, 0, 0, '', '1193046', 0, 0, '---', 0, '--', 2, 0, 3, 0, 1, 0, 3, 0, 0, 6, '', 1, 0, 1, '10.30.18.146', 10000, 0, 0, '/home/drm/mdi/FF.mdi', 0, 1456, 0, 0, 0, 0, 0, 1, 0, 0, 0),
(96, 3, '2013-03-22 01:51:03', 'Button1.ini', 1, 1, NULL, 'High bit rate SW - 10 kHz - weak protection - 27.44 kbps', NULL, 3, 1, 0, 0, 0, 0, 0, NULL, 3, NULL, NULL, 0, 0, 0, 0, 1372, 'HCJB Global', 10526976, 0, 5, 'eng', NULL, '--', 0, 9, 0, 0, 1, 1, 3, 1, 0, 3, 'Analog Stereo', 1, 0, 0, 0, '', 1193046, 0, 0, '---', NULL, '--', 2, 0, 1, 0, 1, 0, 3, 0, 0, 6, '', 1, 0, 0, 0, '', 1193046, 0, 0, '---', NULL, '--', 2, 0, 2, 0, 1, 0, 3, 0, 0, 6, '', 1, 0, 0, 0, '', '1193046', 0, 0, '---', NULL, '--', 2, 0, 3, 0, 1, 0, 3, 0, 0, 6, '', 1, 0, 1, '10.30.18.146', 10000, 0, 0, '/home/drm/mdi/FF.mdi', 0, 1456, 0, 0, 0, 0, 0, 1, 0, 0, 0),
(97, 3, '2013-03-22 01:51:17', 'Button3.ini', 1, 1, NULL, 'Mode B 16 QAM Max Audio 14.56 kbps', NULL, 3, 1, 0, 3, 0, 0, 0, NULL, 1, NULL, NULL, 0, 0, 0, 0, 728, 'HCJB Global', 10526976, 0, 5, 'eng', NULL, '--', 0, 9, 0, 0, 1, 0, 3, 1, 0, 3, 'Analog Stereo', 1, 0, 0, 0, '', 1193046, 0, 0, '---', NULL, '--', 2, 0, 1, 0, 1, 0, 3, 0, 0, 6, '', 1, 0, 0, 0, '', 1193046, 0, 0, '---', NULL, '--', 2, 0, 2, 0, 1, 0, 3, 0, 0, 6, '', 1, 0, 0, 0, '', '1193046', 0, 0, '---', NULL, '--', 2, 0, 3, 0, 1, 0, 3, 0, 0, 6, '', 1, 0, 1, '10.30.18.146', 10000, 0, 0, '/home/drm/mdi/FF.mdi', 0, 1456, 0, 0, 0, 0, 0, 1, 0, 0, 0),
(136, 4, '2013-03-27 18:08:38', 'Fun in the sun', 1, 1, '/home/nick/.TestFile1.ini', 'Sunshine\n\n												', NULL, 5, 0, 0, 0, 0, 0, 0, NULL, 3, NULL, NULL, 0, 0, 0, 0, 3598, 'Hcjb', 292, 0, 15, 'aar', 0, 'AW', 0, 13, 0, 0, 1, 2, 3, 1, 0, 3, 'Analog Stereo', 0, 0, 0, 0, '', 0, 0, 0, '---', 0, '--', 2, 0, 1, 0, 1, 1, 3, 1, 0, 6, '', 0, 0, 0, 0, '', 0, 0, 0, '---', 0, '--', 2, 0, 2, 0, 0, 0, 1, 1, 0, 6, '', 0, 0, 0, 0, '', '0', 0, 0, '---', 0, '--', 2, 0, 3, 0, 0, 0, 1, 1, 0, 6, '', 0, 0, 1, '10.30.18.146\n', 10000, 0, 0, '/home/drm/mdi/ff.mdi\n', 0, 1456, 0, 0, 0, 0, 0, 1, 0, 0, 1),
(1, 3, '2013-04-03 20:37:58', 'defaultNewFile.ini', 1, 1, NULL, '', NULL, -1, -1, -1, -1, -1, 0, 0, NULL, -1, NULL, NULL, 0, 0, 0, 0, 0, 'HCJB Global', 0, 0, 0, '---', NULL, '--', 2, 0, 0, 0, 1, 0, 3, 0, 0, 6, 'Analog Stereo', 1, 0, 0, 0, 'HCJB Global', 0, 0, 0, '---', NULL, '--', 2, 0, 1, 0, 1, 0, 3, 0, 0, 6, 'Analog Stereo', 1, 0, 0, 0, 'HCJB Global', 0, 0, 0, '---', NULL, '--', 2, 0, 2, 0, 1, 0, 3, 0, 0, 6, 'Analog Stereo', 1, 0, 0, 0, 'HCJB Global', '0', 0, 0, '---', NULL, '--', 2, 0, 3, 0, 1, 0, 3, 0, 0, 6, 'Analog Stereo', 1, 0, 0, '127.0.0.1', 0, 0, 0, '/home/drm/mdi/FF.mdi', 0, 1456, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(116, 4, '2013-03-21 17:11:47', 'Based on TestFile1.ini', 1, 0, '/home/nick/.TestFile1.ini', 'High bit rate SW - 10 kHz - weak protection - 27.44 kbps\n', NULL, 3, 1, 0, 0, 0, 0, 0, NULL, 3, NULL, NULL, 0, 0, 0, 0, 1372, 'HCJB Global\n', 10526976, 0, 5, 'eng', NULL, '--', 0, 9, 0, 0, 1, 1, 3, 1, 0, 3, 'Analog Stereo\n', 1, 0, 0, 0, ' \n', 1193046, 0, 0, '---', NULL, '--', 2, 0, 1, 0, 1, 0, 3, 0, 0, 6, ' \n', 1, 0, 0, 0, ' \n', 1193046, 0, 0, '---', NULL, '--', 2, 0, 2, 0, 1, 0, 3, 0, 0, 6, ' \n', 1, 0, 0, 0, ' \n', '1193046\n', 0, 0, '---', NULL, '--', 2, 0, 3, 0, 1, 0, 3, 0, 0, 6, ' \n', 1, 0, 1, '10.30.18.146\n', 10000, 0, 0, '/home/drm/mdi/ff.mdi\n', 0, 1456, 0, 0, 0, 0, 0, 1, 0, 0, 0),
(109, 2, '2013-03-23 20:47:01', 'Greg Test File', 1, 0, '/home/nick/.TestFile1.ini', 'High bit rate SW - 10 kHz - weak protection - 27.44 kbps\n', NULL, 4, 1, 0, 0, 0, 0, 0, NULL, 3, NULL, NULL, 0, 0, 0, 0, 1372, 'HCJB Global\n', 10526976, 0, 5, 'eng', 0, '--', 2, 9, 0, 0, 1, 1, 3, 1, 0, 6, 'Analog Stereo\n', 1, 0, 0, 0, ' \n', 1193046, 0, 0, '---', 0, '--', 2, 0, 1, 0, 1, 0, 3, 0, 0, 6, ' \n', 1, 0, 0, 0, ' \n', 1193046, 0, 0, '---', 0, '--', 2, 0, 2, 0, 1, 0, 3, 0, 0, 6, ' \n', 1, 0, 0, 0, ' \n', '1193046\n', 0, 0, '---', 0, '--', 2, 0, 3, 0, 1, 0, 3, 0, 0, 6, ' \n', 1, 0, 1, '10.30.18.146\n', 10000, 0, 0, '/home/drm/mdi/ff.mdi\n', 0, 1456, 0, 0, 0, 0, 0, 1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `Bugs`
--

DROP TABLE IF EXISTS `Bugs`;
CREATE TABLE IF NOT EXISTS `Bugs` (
  `BugID` int(11) NOT NULL AUTO_INCREMENT,
  `Subject` varchar(64) NOT NULL,
  `Description` text NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  PRIMARY KEY (`BugID`),
  KEY `UserID` (`UserID`),
  KEY `UserID_2` (`UserID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `DefaultOptions`
--

DROP TABLE IF EXISTS `DefaultOptions`;
CREATE TABLE IF NOT EXISTS `DefaultOptions` (
  `FileID` int(11) NOT NULL AUTO_INCREMENT,
  `FileName` varchar(64) DEFAULT NULL,
  `IsRealFile` tinyint(1) DEFAULT NULL,
  `FileLocation` varchar(64) DEFAULT NULL,
  `ConfigurationDesc` varchar(256) DEFAULT NULL,
  `Location` int(11) DEFAULT NULL,
  `SpectrumOcc` int(11) DEFAULT NULL,
  `Robustness` int(11) DEFAULT NULL,
  `InterleaverDepth` int(11) DEFAULT NULL,
  `MSCMode` int(11) DEFAULT NULL COMMENT 'Determines SDC too',
  `SDCMode` int(11) DEFAULT NULL,
  `BaseEnhancementFlag` int(11) DEFAULT NULL COMMENT 'Old variable, not in wizard',
  `ProtAInt` int(11) DEFAULT NULL,
  `ProtAValue` int(11) DEFAULT NULL,
  `ProtBInt` int(11) DEFAULT NULL,
  `ProtBValue` int(11) DEFAULT NULL,
  `ProtHValue` int(11) DEFAULT NULL,
  `ProtHInt` int(11) DEFAULT NULL,
  `HierarchicalBytes` int(11) DEFAULT NULL COMMENT 'Possibly not needed',
  `AmDRM` int(11) DEFAULT NULL,
  `S0DataLengthA` int(11) DEFAULT NULL,
  `S0DataLengthB` int(11) DEFAULT NULL,
  `S0ServiceLabel` varchar(64) DEFAULT NULL,
  `S0ServiceID` text COMMENT 'Should be hex value',
  `S0CASystemUsed` int(11) DEFAULT NULL,
  `S0LanguageInt` int(11) DEFAULT NULL,
  `S0LanguageCode` varchar(3) DEFAULT NULL COMMENT '3 character code for the language',
  `S0CountryInt` int(11) DEFAULT NULL,
  `S0CountryCode` varchar(2) DEFAULT NULL COMMENT 'Possibly not needed',
  `S0AudioDataFlag` int(11) DEFAULT NULL,
  `S0ServiceDesc` int(11) DEFAULT NULL COMMENT '0-31 code for type or program',
  `S0StreamID` int(11) DEFAULT NULL,
  `S0AudioCodec` int(11) DEFAULT NULL,
  `S0SBRFlag` tinyint(1) DEFAULT NULL COMMENT 'Codec May Effect',
  `S0AudioMode` int(11) DEFAULT NULL,
  `S0AudioSamplingRate` int(11) DEFAULT NULL,
  `S0TextFlag` tinyint(1) DEFAULT NULL,
  `S0EnhancementFlag` int(11) DEFAULT NULL,
  `S0Source` int(11) DEFAULT NULL,
  `S0AudioFileName` varchar(255) DEFAULT NULL,
  `S0RepeatAudio` int(11) DEFAULT NULL,
  `S0CoderField` int(11) DEFAULT NULL COMMENT 'May not be needed',
  `S1DataLengthA` int(11) DEFAULT NULL,
  `S1DataLengthB` int(11) DEFAULT NULL,
  `S1ServiceLabel` varchar(64) DEFAULT NULL,
  `S1ServiceID` int(11) DEFAULT NULL,
  `S1CASystemUsed` int(11) DEFAULT NULL,
  `S1LanguageInt` int(11) DEFAULT NULL,
  `S1LanguageCode` varchar(3) DEFAULT NULL,
  `S1CountryInt` int(11) DEFAULT NULL,
  `S1CountryCode` varchar(2) DEFAULT NULL,
  `S1AudioDataFlag` int(11) DEFAULT NULL,
  `S1ServiceDesc` int(11) DEFAULT NULL,
  `S1StreamID` int(11) DEFAULT NULL,
  `S1AudioCodec` int(11) DEFAULT NULL,
  `S1SBRFlag` tinyint(1) DEFAULT NULL,
  `S1AudioMode` int(11) DEFAULT NULL,
  `S1AudioSamplingRate` int(11) DEFAULT NULL,
  `S1TextFlag` tinyint(1) DEFAULT NULL,
  `S1EnhancementFlag` int(11) DEFAULT NULL,
  `S1Source` int(11) DEFAULT NULL COMMENT 'Needs to be included',
  `S1AudioFileName` varchar(255) DEFAULT NULL,
  `S1RepeatAudio` int(11) DEFAULT NULL,
  `S1CoderField` int(11) DEFAULT NULL,
  `S2DataLengthA` int(11) DEFAULT NULL,
  `S2DataLengthB` int(11) DEFAULT NULL,
  `S2ServiceLabel` varchar(64) DEFAULT NULL,
  `S2ServiceID` int(11) DEFAULT NULL,
  `S2CASystemUsed` int(11) DEFAULT NULL,
  `S2LanguageInt` int(11) DEFAULT NULL,
  `S2LanguageCode` varchar(3) DEFAULT NULL,
  `S2CountryInt` int(11) DEFAULT NULL,
  `S2CountryCode` varchar(2) DEFAULT NULL,
  `S2AudioDataFlag` int(11) DEFAULT NULL,
  `S2ServiceDesc` int(11) DEFAULT NULL,
  `S2StreamID` int(11) DEFAULT NULL,
  `S2AudioCodec` int(11) DEFAULT NULL,
  `S2SBRFlag` tinyint(1) DEFAULT NULL,
  `S2AudioMode` int(11) DEFAULT NULL,
  `S2AudioSamplingRate` int(11) DEFAULT NULL,
  `S2TextFlag` tinyint(1) DEFAULT NULL,
  `S2EnhancmentFlag` int(11) DEFAULT NULL,
  `S2Source` int(11) DEFAULT NULL COMMENT 'Needs to be Included',
  `S2AudioFileName` varchar(255) DEFAULT NULL,
  `S2RepeatAudio` int(11) DEFAULT NULL,
  `S2CoderField` int(11) DEFAULT NULL,
  `S3DataLengthA` int(11) DEFAULT NULL,
  `S3DataLengthB` int(11) DEFAULT NULL,
  `S3ServiceLabel` varchar(64) DEFAULT NULL,
  `S3ServiceID` text,
  `S3CASystemUsed` int(11) DEFAULT NULL,
  `S3LanguageInt` int(11) DEFAULT NULL,
  `S3LanguageCode` varchar(3) DEFAULT NULL,
  `S3CountryID` int(11) DEFAULT NULL,
  `S3CountryCode` varchar(2) DEFAULT NULL,
  `S3AudioDataFlag` int(11) DEFAULT NULL,
  `S3ServiceDesc` int(11) DEFAULT NULL,
  `S3StreamID` int(11) DEFAULT NULL,
  `S3AudioCodec` int(11) DEFAULT NULL,
  `S3SBRFlag` tinyint(1) DEFAULT NULL,
  `S3AudioMode` int(11) DEFAULT NULL,
  `S3AudioSamplingRate` int(11) DEFAULT NULL,
  `S3TextFlag` tinyint(1) DEFAULT NULL,
  `S3EnhancementFlag` int(11) DEFAULT NULL,
  `S3Source` int(11) DEFAULT NULL COMMENT 'Needs to be included',
  `S3AudioFileName` varchar(255) DEFAULT NULL,
  `S3RepeatAudio` int(11) DEFAULT NULL,
  `S3CoderField` int(11) DEFAULT NULL,
  `IPEnabled` int(11) DEFAULT NULL,
  `IPAddress` varchar(64) DEFAULT NULL,
  `IPPort` int(11) DEFAULT NULL,
  `IP_TCP_UDP` int(11) DEFAULT NULL,
  `FEEnabled` int(11) DEFAULT NULL,
  `FFFileName` varchar(255) DEFAULT NULL,
  `PFTEnabled` int(11) DEFAULT NULL,
  `PFTPayloadMtu` int(11) DEFAULT NULL,
  `PFTProtection` int(11) DEFAULT NULL,
  `PFTStrength` int(11) DEFAULT NULL,
  `PFTTransportation` int(11) DEFAULT NULL,
  `PFTSource` int(11) DEFAULT NULL,
  `PFTDestination` int(11) DEFAULT NULL,
  `VUMeter` int(11) DEFAULT NULL,
  `Timing` int(11) DEFAULT NULL,
  `Clocktime` int(11) DEFAULT NULL,
  PRIMARY KEY (`FileID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `FileInfo`
--

DROP TABLE IF EXISTS `FileInfo`;
CREATE TABLE IF NOT EXISTS `FileInfo` (
  `FileName` varchar(128) NOT NULL COMMENT 'This table is no longer used',
  `FileLocation` varchar(128) DEFAULT NULL,
  `FileID` int(11) NOT NULL,
  `IsRealFile` tinyint(1) NOT NULL,
  KEY `FileID` (`FileID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `FileInfo`
--

INSERT INTO `FileInfo` (`FileName`, `FileLocation`, `FileID`, `IsRealFile`) VALUES
('Am Config 1', 'H:\\docs\\AmFile1', 1, 0),
('FM Config 1', 'H:\\docs\\12Oct2010PM', 2, 0),
('AM File2', 'place.drive', 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `File Modification Hisotry`
--

DROP TABLE IF EXISTS `File Modification Hisotry`;
CREATE TABLE IF NOT EXISTS `File Modification Hisotry` (
  `FileID` int(11) NOT NULL COMMENT 'This table is no longer used',
  `UserID` int(11) NOT NULL,
  `LastModified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Modification Id` int(11) NOT NULL,
  PRIMARY KEY (`Modification Id`),
  KEY `FileID` (`FileID`),
  KEY `UserID` (`UserID`),
  KEY `FileID_2` (`FileID`),
  KEY `FileID_3` (`FileID`),
  KEY `UserID_2` (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `File Modification Hisotry`
--

INSERT INTO `File Modification Hisotry` (`FileID`, `UserID`, `LastModified`, `Modification Id`) VALUES
(1, 2, '2013-03-12 11:00:00', 1),
(2, 3, '2013-03-13 22:00:00', 2),
(3, 4, '2013-03-15 21:23:00', 3);

-- --------------------------------------------------------

--
-- Table structure for table `LiveAudio`
--

DROP TABLE IF EXISTS `LiveAudio`;
CREATE TABLE IF NOT EXISTS `LiveAudio` (
  `Name` varchar(128) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `LiveAudio`
--

INSERT INTO `LiveAudio` (`Name`) VALUES
('Analog Stereo'),
('Shower Singing'),
('Digital THX DST'),
('Dolby DS');

-- --------------------------------------------------------

--
-- Table structure for table `UserInfo`
--

DROP TABLE IF EXISTS `UserInfo`;
CREATE TABLE IF NOT EXISTS `UserInfo` (
  `Username` varchar(32) NOT NULL,
  `PasswordHashed` varchar(130) NOT NULL,
  `UserType` varchar(32) NOT NULL,
  `AutoSaveID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `email` varchar(64) NOT NULL,
  `SecretQuestion` varchar(128) NOT NULL,
  `SecretAnswer` varchar(130) NOT NULL,
  `HasSecretQA` tinyint(1) NOT NULL,
  `ViewType` varchar(32) NOT NULL COMMENT 'Controls if they see advanced options in variables',
  PRIMARY KEY (`UserID`),
  KEY `UserID` (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `UserInfo`
--

INSERT INTO `UserInfo` (`Username`, `PasswordHashed`, `UserType`, `AutoSaveID`, `UserID`, `email`, `SecretQuestion`, `SecretAnswer`, `HasSecretQA`, `ViewType`) VALUES
('Bongo', '95994f45345c9367c4c93aea77e4fa68a5e56cbbb3aab23dd5fd7f9c6e75b8196df01f6a947cd26c5e8cb73dde797af2cc4ef8abe6d784b62a9ab4a5a8b5ddc9', 'Admin', 0, 1, 'Bongo@Congo.com', 'testQ', 'fc70f98804bacde04e8341dba278d66f85311c7f3f451e3e791a9b4c97c104bd499941cda69d0ab23c17d105f95021b69c1ef4a1ca65d8287513afe8d513f0af', 1, 'Advanced'),
('Greg', '708af8a078e980eb48dcc5813e34f781222d2be6287d1e430ad7a98fca1c85c7ed53a3d36ba82b11fece280139418200abb22a1b56b21369908a73a20ec51e73', 'Admin', 0, 2, 'greg@email.com', 'What is sin(30) (As a fraction)', 'ec95190d6ebe67dc6e9cb36dff7787e800f3ea3fdaf4dfdc50eee1c863877abf1229bc0df7384b9c7aef5d65eef8222d3e374d54f7804256ad3b515c9398ce57', 1, 'Advanced'),
('Nick', 'f3189ec7a889d0b5b8f5b0b1ec3e14de649a15cdfddbf02a5bbf6f5e970898ecb37df2cec11b013b235d39fe3590e46a29cef5267416c36bca45761152d64ede', 'Basic', 0, 3, 'Nick@cedarville.edu', '', '', 0, 'Basic'),
('Chris', '5fab46544c09fae151bde9ecd58688d98d2a424883b4c2f7796d11ce443cc038b75a632b8407ae33f2de7284f04a274587fd68461b838095ae21a9322bf0074c', 'Admin', 0, 4, 'Chris@here.there', '', '', 0, 'Basic'),
('tim', '7fc475694fc8c604db97b2ce218360c5c66a4479347b8e75e7cf5504d5a32b54558aba1c859140f81cd5f8356cec1331f42624f3bfb1909244bbcdf3fb1647dd', 'Basic', 0, 5, 'Tim@hcjb.org', '', '', 0, ''),
('MyPW', '32c9371f9a0f1e6f522e23133c1c69e944d3f3a02d206df7d1d34f79ce154f601d65c285bafc7b5530da20139d5efee0daf9d5e11a1519ef48ea8da43e297664', 'Basic', 0, 6, 'test@email.com', '', '', 0, ''),
('Austin', '217c46786a778dab88a548b31a8e8fc77df888a1889433465d28d18353c35ddf3bc337013beeffe56af6935c55c1a54f8dac4bc69e94b8dc306d1082c8f84708', 'Admin', 0, 7, 'aklob@cedarville.edu', 'Who''s your Daddy and what does he do?', 'Radio Station Manager', 1, ''),
('123', '344907e89b981caf221d05f597eb57a6af408f15f4dd7895bbd1b96a2938ec24a7dcf23acb94ece0b6d7b0640358bc56bdb448194b9305311aff038a834a079f', 'Basic', 0, 8, 'here@thjere.com', '456', '03d58767b7bc97b35370de15ea000765dd21c7a78cbcd34a2f97e02c75c4fae69d4c25aae329aec9d9a48d01e8c5f74eea9a55e560c26909fd664e8ba27895b3', 1, 'Basic'),
('nick', '1a33914b0fa8095655ea29cc2eb01ad6c4d736c81d2ff9f8b00382ec4ffbdf47b8130a60c984f88f752b4bcc5142e95441a3a74f17b119591427c5fa6368c57c', 'basic', 0, 9, 'here@there.com', '', '', 0, ''),
('Paul', '2547a0a11879dd7039ac0bc227ed60089731a15245665a2caa5acc31d6da2c6c78e80a5fae2306ebe85222b3cd5737802827f802073f84e768e827a2acea3a6c', 'Basic', 0, 10, 'cschwinof@mail2pilot.com', '', '', 0, 'test'),
('Paul', '2547a0a11879dd7039ac0bc227ed60089731a15245665a2caa5acc31d6da2c6c78e80a5fae2306ebe85222b3cd5737802827f802073f84e768e827a2acea3a6c', 'Basic', 0, 11, 'cschwinof@cedarville.edu', '', '', 0, 'test'),
('Break', '4925da7da7a56260baf1c37925a8fa24e46ad8b107dcd21f44e39e4751bae1304fc70de7acb847ffa96126bb372de005f5320f1ede6f9df07c7d53f9c160f022', 'Basic', 0, 12, 'here@there.com', '', '', 0, 'test'),
('Break2', '344907e89b981caf221d05f597eb57a6af408f15f4dd7895bbd1b96a2938ec24a7dcf23acb94ece0b6d7b0640358bc56bdb448194b9305311aff038a834a079f', 'Basic', 0, 13, 'here@there.com', '', '', 0, 'test'),
('Break3', 'e4cb92a59e29aea7cb8756c348b220e7aa640ccdf8f5394ec3c77e23ebe5df150a379ab4b2240118a4a6c147a26eab21002c60f0e4f99eea50e3dd832e140819', 'Basic', 0, 14, 'here@there.com', '', '', 0, 'test'),
('TestAdmin', '701c3ec8f80ad19d8594cff79f1cc26f0724ac6c7b641a643e034fa8fdd8e2eb634e2dba8d0e42cc0658ed6ca1028eb8a0a5232773ee4b192220b40b712ffec4', 'Admin', 0, 15, 'Admin@test.com', '', '', 0, 'test'),
('TestBasic', 'd2da0ad9107e81f2018c0a90cf0aa03fb1584c0f1e1af6cc3fcb5921b87c1413902ec5d5e6356758357ccf2a1950123a82135949c62a196c9e06e7b5dd9dba5f', 'Basic', 0, 16, 'Basic@test.com', '', '', 0, 'test'),
('Break5', '344907e89b981caf221d05f597eb57a6af408f15f4dd7895bbd1b96a2938ec24a7dcf23acb94ece0b6d7b0640358bc56bdb448194b9305311aff038a834a079f', 'Basic', 0, 17, 'here@there.com', '', '', 0, 'test');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `File Modification Hisotry`
--
ALTER TABLE `File Modification Hisotry`
  ADD CONSTRAINT `File@0020Modification@0020Hisotry_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `UserInfo` (`UserID`),
  ADD CONSTRAINT `File@0020Modification@0020Hisotry_ibfk_2` FOREIGN KEY (`FileID`) REFERENCES `FileInfo` (`FileID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
