<?php //This function allows the user to update their password

session_start();
	include('config.php');
	
	$dbhandle = mysql_connect($hostname, $username, $password)
			or die("Unable to connect to MySQL");
			
	mysql_select_db($databaseName,$dbhandle);
	
	$userID=$_SESSION['UserID'];
	$password=$_POST['password'];
	$passwordHash=hash('whirlpool', $password);
	mysql_query("UPDATE UserInfo SET PasswordHashed='$passwordHash' WHERE UserID='$userID'");
	mysql_close($dbhandle);
	echo "$userID  $password" ;
	$_SESSION['Action']="PasswordChange1";
	header("Location: ActionComplete.php");
	
?>	
	
	