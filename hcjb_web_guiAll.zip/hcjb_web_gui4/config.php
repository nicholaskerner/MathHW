<?php
	//Configuration for database
	$username = "root";
	$password = "drmahoy2013";
	$hostname = "localhost";
	$databaseName = "hcjb";
	
	$uploadDir = "upload/";
	$iniDir = "ini/";
?>
