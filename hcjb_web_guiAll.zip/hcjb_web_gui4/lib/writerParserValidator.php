<?php

//function: lookFor(string to be found, filehandle);
//This function is to fast-forward in the file to the beginning of the
//    next section.  If $stringToBeFound is equal to [Transmission] then
//    this function will consume all lines before [Transmission] is detected
//    in a line.  The line that contains [Transmission]  will be consumed.
function lookFor( $stringToBeFound, $fh){
	
	$found = false;
	while(!feof($fh) and !$found){
		$string = fgets($fh);
		
		if(strpos($string, $stringToBeFound) === false){
		
		}
		else{
			$found = true;
		}		
	}
	
	if(feof($fh)){
		throw new Exception("reached end of file before finding ".$stringToBeFound);
	}
	else{
		return true;
	}
}


// function: getData(header, filehandle);
// Many rows of the INI file contains data like this:
// Robustness=1                             ; B 20% Guard Interval General Sky Wave
// where there is a field header "Robustness", a divider "=", data "1", 
//    a comment divider ";" and comment " B 20% Guard Interval General Sky Wave"
//
// This needs to be parsed, the field header needs to be confirmed, the data field
//    needs to be saved and the comment field may need to be saved. This is so that in 
//    the future this will be stored into the database so that it can be
//    rewritten to ini files.  That way the same file as uploaded is written.
//    The largest barier to this is the write function below.
function getData($header, $fh){
	$string = fgets($fh);
	
	list($noComment, $comment) = explode(";",$string,2);
	list($fieldHeader, $data) = explode("=",$noComment, 2);
		
	if(strpos($fieldHeader, $header) === false){
		// This is not the correct field, the field header passed into the function
		//    does not match the one that was parsed.
		throw new Exception("Error found in line: ".$string."<br>  Expected ".$header."<br> got ".$fieldHeader."<br>");
	}
	else{//returns data without leading or trailing whitespace.
		return array(trim($data),trim($comment));
	}
}

function test(){
$testvar = "0";
echo "service$testvar"."stuff";
}


//This function validates from the database
function validate($filename){

	include('config.php');//DB access and authentication information
	$endl = "<br>";//used for some error messages

	//Connect to the database
	$dbhandle = mysql_connect($hostname, $username, $password);	
	if(!$dbhandle){
		throw new Exception("Unable to connect to MySQL.".$endl);
	}
	
	//Select the database
	$selected = mysql_select_db($databaseName,$dbhandle);
	if(!$selected){
		throw new Exception("Could not select the database.".$endl);
	}
	
	//Execute the query, gathering all data from the database
	$result = mysql_query("SELECT * FROM `AutoSave` WHERE FileName = \"".$filename."\"");	
	$row = mysql_fetch_array($result);		
	if($row == false){
		throw new Exception("This file is not in the database..".$endl);
	}
	
	
	
	//Configuration description is a "Free-format string with 255 ASCII character limit, displayed for the radio station engineer"
	if(strlen(trim($row["ConfigurationDesc"])) >255){
		throw new Exception("Too many characters in configuration description".$endl);
	}
	
	//Robustness and Spectrum Occupancy
	if(!is_int($row["Robustness"]) and !ctype_digit($row["Robustness"])){
		//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
		throw new Exception("Robustness must be an integer.".$endl);
	}
	if(!is_int($row["SpectrumOcc"]) and !ctype_digit($row["SpectrumOcc"])){
		//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
		throw new Exception("SpectrumOcc must be an integer.".$endl);
	}	
	if($row["Robustness"] < 0 or $row["Robustness"] > 3){
		throw new Exception("Robustness must be between 0 and 4 (inclusive).".$endl);
	}
	if($row["SpectrumOcc"] < 0 or $row["SpectrumOcc"] > 5){
		throw new Exception("SpectrumOcc must be between 0 and 5 (inclusive).".$endl);
	}
	if($row["Robustness"] == 2 or $row["Robustness"] == 3){
		if($row["SpectrumOcc"] != 3 and $row["SpectrumOcc"] != 5){
			throw new Exception("Robustness 2 or 3 requires spectrum occupancy of 3 or 5.".$endl);
		}
	}
	else if($row["SpectrumOcc"] == 0 or $row["SpectrumOcc"] == 1 or $row["SpectrumOcc"] == 2 or $row["SpectrumOcc"] == 4){
		if($row["Robustness"] != 0 and $row["Robustness"] != 1){
			throw new Exception("Spectrum occupancy 0,1,2, and 4 requires robustness 0 or 1.".$endl);
		}
	}
	
	
	//MSCMode
	if(!is_int($row["MSCMode"]) and !ctype_digit($row["MSCMode"])){
		//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
		throw new Exception("MSCMode must be an integer.".$endl);
	}
	if($row["MSCMode"] < 0 or $row["MSCMode"] > 3){//must be an integer from 0 to 3
		throw new Exception("MSCMode must be 0-3.".$endl);	
	}
	
	
	//ProtAInt
	if(!is_int($row["ProtAInt"]) and !ctype_digit($row["ProtAInt"])){
		//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
		throw new Exception("ProtAInt must be an integer.".$endl);
	}
	if($row["ProtAInt"] < 0 or $row["ProtAInt"] > 3){//must be 0-3
		throw new Exception("ProtAInt must be from 0-3.".$endl);	
	}
	
		
	//ProtBInt
	if(!is_int($row["ProtBInt"]) and !ctype_digit($row["ProtBInt"])){
		//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
		throw new Exception("ProtBInt must be an integer.".$endl);
	}	
	if($row["ProtBInt"] < 0 or $row["ProtBInt"] > 3){//must be 0-3
		throw new Exception("ProtBInt must be from 0-3.".$endl);	
	}	
	
	
	//MSCMode, ProtAInt, ProtBInt, ProtHInt related restrictions
	if($row["MSCMode"] == 0 or $row["MSCMode"] == 3){
		//Non heirarchical/equal error protection		
		if($row["ProtAInt"] != 0){
			throw new Exception("When using equal error protection, Prot level for part A must be 0.".$endl);
		}
		if($row["S0DataLengthA"] != 0 or $row["S1DataLengthA"] != 0 or $row["S2DataLengthA"] != 0 or $row["S3DataLengthA"] != 0){
			throw new Exception("When using equal error protection, DataLengthForPartA must be 0 in all streams.".$endl);
		}
	}
	else if($row["MSCMode"] == 1 or $row["MSCMode"] == 2){
		//ProtHInt
		if(!is_int($row["ProtHInt"]) and !ctype_digit($row["ProtHInt"])){
			//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
			throw new Exception("ProtHInt must be an integer.".$endl);
		}	
		if($row["ProtHInt"] < 0 or $row["ProtHInt"] > 3){//must be 0-3
			throw new Exception("ProtHInt must be from 0-3.".$endl);	
		}
	
		if($row["ProtAInt"] > $row["ProtBInt"]){
		// I assume the level for part A must be stronger or equal to the prot level for part B.
		// Note:  lower integer for ProtAInt means stronger
			throw new Exception("When using unequal error protection, part A must have a stronger protection level than part B.".$endl);
		}	
	}
	else{
		throw new Exception("MSCMode must be from 0-3 (inclusive).".$endl);
	}
	
	
	//InterleaverDepthFlag
	if(!is_int($row["InterleaverDepth"]) and !ctype_digit($row["InterleaverDepth"])){
		//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
		throw new Exception("InterleaverDepth must be 0 or 1.".$endl);
	}
	if($row["InterleaverDepth"] != 0 and $row["InterleaverDepth"] != 1){//must be 0 or 1
		throw new Exception("InterleaverDepth must be 0 or 1.".$endl);	
	}
	
	//BaseEnhancementFlag
	if(!is_int($row["BaseEnhancementFlag"]) and !ctype_digit($row["BaseEnhancementFlag"])){
		//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
		throw new Exception("BaseEnhancementFlag must be 0 or 1.  Additionally, if used in a system newer than April 2012, should be set to 0.".$endl);
	}
	if($row["BaseEnhancementFlag"] != 0 and $row["BaseEnhancementFlag"] != 1){//must be 0 or 1
		throw new Exception("BaseEnhancementFlag must be 0 or 1.  Additionally, if used in a system newer than April 2012, should be set to 0.".$endl);	
	}
	
	//AmDRM
	if(!is_int($row["AmDRM"]) and !ctype_digit($row["AmDRM"])){
		//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
		throw new Exception("AmDRM must be an integer.".$endl);
	}	
	if($row["AmDRM"] < 0 or $row["AmDRM"] > 6){//must be 0-6
		throw new Exception("AmDRM must be from 0-6.  Additionally, this is now the responsibility of the modulator control interface (MCI) and if used in a system newer than April 2012, should be set to 0.".$endl);	
	}	
	
	
	//Stream/Service section
	
	$languageCodes = array(array("aar","Afar"),array("abk","Abkhazian"),array("ace","Achinese"),array("ach","Acoli"),array("ada","Adangme"),array("ady","Adyghe; Adygei"),array("afa","Afro-Asiatic languages"),array("afh","Afrihili"),array("afr","Afrikaans"),array("ain","Ainu"),array("aka","Akan"),array("akk","Akkadian"),array("alb","Albanian"),array("ale","Aleut"),array("alg","Algonquian languages"),array("alt","Southern Altai"),array("amh","Amharic"),array("ang","English, Old (ca.450-1100)"),array("anp","Angika"),array("apa","Apache languages"),array("arc","Aramaic"),array("arg","Aragonese"),array("arm","Armenian"),array("arn","Mapudungun; Mapuche"),array("arp","Arapaho"),array("art","Artificial languages"),array("arw","Arawak"),array("asm","Assamese"),array("ast","Asturian"),array("ath","Athapascan languages"),array("aus","Australian languages"),array("ava","Avaric"),array("ave","Avestan"),array("awa","Awadhi"),array("aym","Aymara"),array("aze","Azerbaijani"),array("bad","Banda languages"),array("bai","Bamileke languages"),array("bak","Bashkir"),array("bal","Baluchi"),array("bam","Bambara"),array("ban","Balinese"),array("baq","Basque"),array("bas","Basa"),array("bat","Baltic languages"),array("bej","Beja; Bedawiyet"),array("bel","Belarusian"),array("bem","Bemba"),array("ber","Berber languages"),array("bho","Bhojpuri"),array("bih","Bihari languages"),array("bik","Bikol"),array("bin","Bini; Edo"),array("bis","Bislama"),array("bla","Siksika"),array("bnt","Bantu languages"),array("bos","Bosnian"),array("bra","Braj"),array("bre","Breton"),array("btk","Batak languages"),array("bua","Buriat"),array("bug","Buginese"),array("bul","Bulgarian"),array("bur","Burmese"),array("byn","Blin; Bilin"),array("cad","Caddo"),array("cai","Central American Indian languages"),array("car","Galibi Carib"),array("cat","Catalan; Valencian"),array("cau","Caucasian languages"),array("ceb","Cebuano"),array("cel","Celtic languages"),array("cha","Chamorro"),array("chb","Chibcha"),array("che","Chechen"),array("chg","Chagatai"),array("chk","Chuukese"),array("chm","Mari"),array("chn","Chinook jargon"),array("cho","Choctaw"),array("chp","Chipewyan; Dene Suline"),array("chr","Cherokee"),array("chu","Church Slavic; Old Slavonic; Church Slavonic; Old Bulgarian; Old Church Slavonic"),array("chv","Chuvash"),array("chy","Cheyenne"),array("cmc","Chamic languages"),array("cop","Coptic"),array("cor","Cornish"),array("cos","Corsican"),array("cpe","Creoles and pidgins, English based"),array("cpf","Creoles and pidgins, French-based"),array("cpp","Creoles and pidgins, Portuguese-based"),array("cre","Cree"),array("crh","Crimean Tatar; Crimean Turkish"),array("crp","Creoles and pidgins"),array("csb","Kashubian"),array("cus","Cushitic languages"),array("cze","Czech"),array("dak","Dakota"),array("dan","Danish"),array("dar","Dargwa"),array("day","Land Dayak languages"),array("del","Delaware"),array("den","Slave (Athapascan)"),array("dgr","Dogrib"),array("din","Dinka"),array("div","Divehi; Dhivehi; Maldivian"),array("doi","Dogri"),array("dra","Dravidian languages"),array("dsb","Lower Sorbian"),array("dua","Duala"),array("dum","Dutch, Middle (ca.1050-1350)"),array("dyu","Dyula"),array("dzo","Dzongkha"),array("efi","Efik"),array("egy","Egyptian (Ancient)"),array("eka","Ekajuk"),array("elx","Elamite"),array("enm","English, Middle (1100-1500)"),array("epo","Esperanto"),array("est","Estonian"),array("ewe","Ewe"),array("ewo","Ewondo"),array("fan","Fang"),array("fao","Faroese"),array("fat","Fanti"),array("fij","Fijian"),array("fil","Filipino; Pilipino"),array("fin","Finnish"),array("fiu","Finno-Ugrian languages"),array("fon","Fon"),array("frm","French, Middle (ca.1400-1600)"),array("fro","French, Old (842-ca.1400)"),array("frr","Northern Frisian"),array("frs","Eastern Frisian"),array("fry","Western Frisian"),array("ful","Fulah"),array("fur","Friulian"),array("gaa","Ga"),array("gay","Gayo"),array("gba","Gbaya"),array("gem","Germanic languages"),array("geo","Georgian"),array("ger","German"),array("gez","Geez"),array("gil","Gilbertese"),array("gla","Gaelic; Scottish Gaelic"),array("gle","Irish"),array("glg","Galician"),array("glv","Manx"),array("gmh","German, Middle High (ca.1050-1500)"),array("goh","German, Old High (ca.750-1050)"),array("gon","Gondi"),array("gor","Gorontalo"),array("got","Gothic"),array("grb","Grebo"),array("grc","Greek, Ancient (to 1453)"),array("gre","Greek, Modern (1453-)"),array("grn","Guarani"),array("gsw","Swiss German; Alemannic; Alsatian"),array("guj","Gujarati"),array("gwi","Gwich'in"),array("hai","Haida"),array("hat","Haitian; Haitian Creole"),array("hau","Hausa"),array("haw","Hawaiian"),array("heb","Hebrew"),array("her","Herero"),array("hil","Hiligaynon"),array("him","Himachali languages; Western Pahari languages"),array("hit","Hittite"),array("hmn","Hmong; Mong"),array("hmo","Hiri Motu"),array("hrv","Croatian"),array("hsb","Upper Sorbian"),array("hun","Hungarian"),array("hup","Hupa"),array("iba","Iban"),array("ibo","Igbo"),array("ice","Icelandic"),array("ido","Ido"),array("iii","Sichuan Yi; Nuosu"),array("ijo","Ijo languages"),array("iku","Inuktitut"),array("ile","Interlingue; Occidental"),array("ilo","Iloko"),array("ina","Interlingua (International Auxiliary Language Association)"),array("inc","Indic languages"),array("ind","Indonesian"),array("ine","Indo-European languages"),array("inh","Ingush"),array("ipk","Inupiaq"),array("ira","Iranian languages"),array("iro","Iroquoian languages"),array("ita","Italian"),array("jbo","Lojban"),array("jpr","Judeo-Persian"),array("jrb","Judeo-Arabic"),array("kaa","Kara-Kalpak"),array("kab","Kabyle"),array("kac","Kachin; Jingpho"),array("kal","Kalaallisut; Greenlandic"),array("kam","Kamba"),array("kan","Kannada"),array("kar","Karen languages"),array("kas","Kashmiri"),array("kau","Kanuri"),array("kaw","Kawi"),array("kaz","Kazakh"),array("kbd","Kabardian"),array("kha","Khasi"),array("khi","Khoisan languages"),array("khm","Central Khmer"),array("kho","Khotanese; Sakan"),array("kik","Kikuyu; Gikuyu"),array("kin","Kinyarwanda"),array("kir","Kirghiz; Kyrgyz"),array("kmb","Kimbundu"),array("kok","Konkani"),array("kom","Komi"),array("kon","Kongo"),array("kos","Kosraean"),array("kpe","Kpelle"),array("krc","Karachay-Balkar"),array("krl","Karelian"),array("kro","Kru languages"),array("kru","Kurukh"),array("kua","Kuanyama; Kwanyama"),array("kum","Kumyk"),array("kur","Kurdish"),array("kut","Kutenai"),array("lad","Ladino"),array("lah","Lahnda"),array("lam","Lamba"),array("lao","Lao"),array("lat","Latin"),array("lav","Latvian"),array("lez","Lezghian"),array("lim","Limburgan; Limburger; Limburgish"),array("lin","Lingala"),array("lit","Lithuanian"),array("lol","Mongo"),array("loz","Lozi"),array("ltz","Luxembourgish; Letzeburgesch"),array("lua","Luba-Lulua"),array("lub","Luba-Katanga"),array("lug","Ganda"),array("lui","Luiseno"),array("lun","Lunda"),array("luo","Luo (Kenya and Tanzania)"),array("lus","Lushai"),array("mac","Macedonian"),array("mad","Madurese"),array("mag","Magahi"),array("mah","Marshallese"),array("mai","Maithili"),array("mak","Makasar"),array("mal","Malayalam"),array("man","Mandingo"),array("mao","Maori"),array("map","Austronesian languages"),array("mar","Marathi"),array("mas","Masai"),array("may","Malay"),array("mdf","Moksha"),array("mdr","Mandar"),array("men","Mende"),array("mga","Irish, Middle (900-1200)"),array("mic","Mi'kmaq; Micmac"),array("min","Minangkabau"),array("mis","Uncoded languages"),array("mkh","Mon-Khmer languages"),array("mlg","Malagasy"),array("mlt","Maltese"),array("mnc","Manchu"),array("mni","Manipuri"),array("mno","Manobo languages"),array("moh","Mohawk"),array("mon","Mongolian"),array("mos","Mossi"),array("mul","Multiple languages"),array("mun","Munda languages"),array("mus","Creek"),array("mwl","Mirandese"),array("mwr","Marwari"),array("myn","Mayan languages"),array("myv","Erzya"),array("nah","Nahuatl languages"),array("nai","North American Indian languages"),array("nap","Neapolitan"),array("nau","Nauru"),array("nav","Navajo; Navaho"),array("nbl","Ndebele, South; South Ndebele"),array("nde","Ndebele, North; North Ndebele"),array("ndo","Ndonga"),array("nds","Low German; Low Saxon; German, Low; Saxon, Low"),array("nep","Nepali"),array("new","Nepal Bhasa; Newari"),array("nia","Nias"),array("nic","Niger-Kordofanian languages"),array("niu","Niuean"),array("nno","Norwegian Nynorsk; Nynorsk, Norwegian"),array("nob","Bokm�l, Norwegian; Norwegian Bokm�l"),array("nog","Nogai"),array("non","Norse, Old"),array("nor","Norwegian"),array("nqo","N'Ko"),array("nso","Pedi; Sepedi; Northern Sotho"),array("nub","Nubian languages"),array("nwc","Classical Newari; Old Newari; Classical Nepal Bhasa"),array("nya","Chichewa; Chewa; Nyanja"),array("nym","Nyamwezi"),array("nyn","Nyankole"),array("nyo","Nyoro"),array("nzi","Nzima"),array("oci","Occitan (post 1500)"),array("oji","Ojibwa"),array("ori","Oriya"),array("orm","Oromo"),array("osa","Osage"),array("oss","Ossetian; Ossetic"),array("ota","Turkish, Ottoman (1500-1928)"),array("oto","Otomian languages"),array("paa","Papuan languages"),array("pag","Pangasinan"),array("pal","Pahlavi"),array("pam","Pampanga; Kapampangan"),array("pan","Panjabi; Punjabi"),array("pap","Papiamento"),array("pau","Palauan"),array("peo","Persian, Old (ca.600-400 B.C.)"),array("per","Persian"),array("phi","Philippine languages"),array("phn","Phoenician"),array("pli","Pali"),array("pol","Polish"),array("pon","Pohnpeian"),array("por","Portuguese"),array("pra","Prakrit languages"),array("pro","Proven�al, Old (to 1500); Occitan, Old (to 1500)"),array("pus","Pushto; Pashto"),array("qaa-qtz","Reserved for local use"),array("que","Quechua"),array("raj","Rajasthani"),array("rap","Rapanui"),array("rar","Rarotongan; Cook Islands Maori"),array("roa","Romance languages"),array("roh","Romansh"),array("rom","Romany"),array("rum","Romanian"),array("run","Rundi"),array("rup","Aromanian; Arumanian; Macedo-Romanian"),array("sad","Sandawe"),array("sag","Sango"),array("sah","Yakut"),array("sai","South American Indian languages"),array("sal","Salishan languages"),array("sam","Samaritan Aramaic"),array("san","Sanskrit"),array("sas","Sasak"),array("sat","Santali"),array("scn","Sicilian"),array("sco","Scots"),array("sel","Selkup"),array("sem","Semitic languages"),array("sga","Irish, Old (to 900)"),array("sgn","Sign Languages"),array("shn","Shan"),array("sid","Sidamo"),array("sin","Sinhala; Sinhalese"),array("sio","Siouan languages"),array("sit","Sino-Tibetan languages"),array("sla","Slavic languages"),array("slo","Slovak"),array("slv","Slovenian"),array("sma","Southern Sami"),array("sme","Northern Sami"),array("smi","Sami languages"),array("smj","Lule Sami"),array("smn","Inari Sami"),array("smo","Samoan"),array("sms","Skolt Sami"),array("sna","Shona"),array("snd","Sindhi"),array("snk","Soninke"),array("sog","Sogdian"),array("som","Somali"),array("son","Songhai languages"),array("sot","Sotho, Southern"),array("srd","Sardinian"),array("srn","Sranan Tongo"),array("srp","Serbian"),array("srr","Serer"),array("ssa","Nilo-Saharan languages"),array("ssw","Swati"),array("suk","Sukuma"),array("sun","Sundanese"),array("sus","Susu"),array("sux","Sumerian"),array("swa","Swahili"),array("swe","Swedish"),array("syc","Classical Syriac"),array("syr","Syriac"),array("tah","Tahitian"),array("tai","Tai languages"),array("tam","Tamil"),array("tat","Tatar"),array("tel","Telugu"),array("tem","Timne"),array("ter","Tereno"),array("tet","Tetum"),array("tgk","Tajik"),array("tgl","Tagalog"),array("tha","Thai"),array("tib","Tibetan"),array("tig","Tigre"),array("tir","Tigrinya"),array("tiv","Tiv"),array("tkl","Tokelau"),array("tlh","Klingon; tlhIngan-Hol"),array("tli","Tlingit"),array("tmh","Tamashek"),array("tog","Tonga (Nyasa)"),array("ton","Tonga (Tonga Islands)"),array("tpi","Tok Pisin"),array("tsi","Tsimshian"),array("tsn","Tswana"),array("tso","Tsonga"),array("tuk","Turkmen"),array("tum","Tumbuka"),array("tup","Tupi languages"),array("tur","Turkish"),array("tut","Altaic languages"),array("tvl","Tuvalu"),array("twi","Twi"),array("tyv","Tuvinian"),array("udm","Udmurt"),array("uga","Ugaritic"),array("uig","Uighur; Uyghur"),array("ukr","Ukrainian"),array("umb","Umbundu"),array("und","Undetermined"),array("urd","Urdu"),array("uzb","Uzbek"),array("vai","Vai"),array("ven","Venda"),array("vie","Vietnamese"),array("vol","Volap�k"),array("vot","Votic"),array("wak","Wakashan languages"),array("wal","Wolaitta; Wolaytta"),array("war","Waray"),array("was","Washo"),array("wel","Welsh"),array("wen","Sorbian languages"),array("wln","Walloon"),array("wol","Wolof"),array("xal","Kalmyk; Oirat"),array("xho","Xhosa"),array("yao","Yao"),array("yap","Yapese"),array("yid","Yiddish"),array("yor","Yoruba"),array("ypk","Yupik languages"),array("zap","Zapotec"),array("zbl","Blissymbols; Blissymbolics; Bliss"),array("zen","Zenaga"),array("zgh","Standard Moroccan Tamazight"),array("zha","Zhuang; Chuang"),array("znd","Zande languages"),array("zul","Zulu"),array("zun","Zuni"),array("zxx","No linguistic content; Not applicable"),array("zza","Zaza; Dimili; Dimli; Kirdki; Kirmanjki; Zazaki"));
	$firstThirteenLanguageCodes = array("---","ara","ben","chi","dut","eng","fre","ger","hin","jpn","jav","kor","por","rus","spa");
	$countryCodes = array("--","AF","AX","AL","DZ","AS","AD","AO","AI","AQ","AG","AR","AM","AW","AU","AT","AZ","BS","BH","BD","BB","BY","BE","BZ","BJ","BM","BT","BO","BQ","BA","BW","BV","BR","IO","BN","BG","BF","BI","KH","CM","CA","CV","KY","CF","TD","CL","CN","CX","CC","CO","KM","CG","CD","CK","CR","CI","HR","CU","CW","CY","CZ","DK","DJ","DM","DO","EC","EG","SV","GQ","ER","EE","ET","FK","FO","FJ","FI","FR","GF","PF","TF","GA","GM","GE","DE","GH","GI","GR","GL","GD","GP","GU","GT","GG","GN","GW","GY","HT","HM","VA","HN","HK","HU","IS","IN","ID","IR","IQ","IE","IM","IL","IT","JM","JP","JE","JO","KZ","KE","KI","KP","KR","KW","KG","LA","LV","LB","LS","LR","LY","LI","LT","LU","MO","MK","MG","MW","MY","MV","ML","MT","MH","MQ","MR","MU","YT","MX","FM","MD","MC","MN","ME","MS","MA","MZ","MM","NA","NR","NP","NL","NC","NZ","NI","NE","NG","NU","NF","MP","NO","OM","PK","PW","PS","PA","PG","PY","PE","PH","PN","PL","PT","PR","QA","RE","RO","RU","RW","BL","SH","KN","LC","MF","PM","VC","WS","SM","ST","SA","SN","RS","SC","SL","SG","SX","SK","SI","SB","SO","ZA","GS","SS","ES","LK","SD","SR","SJ","SZ","SE","CH","SY","TW","TJ","TZ","TH","TL","TG","TK","TO","TT","TN","TR","TM","TC","TV","UG","UA","AE","GB","US","UM","UY","UZ","VU","VE","VN","VG","VI","WF","EH","YE","ZM","ZW");
		
	$totalDataLengthA = 0;//sum of data lengths for part A across the 4 streams
	$totalDataLengthB = 0;//sum of data lengths for part B across the 4 streams
	$txtMessageConsumption = 0;//This is increased by 4 if a txt message is used	
	
	//start service/stream checking
	for( $serviceNum = 0; $serviceNum < 4; $serviceNum++){	
	
		if(!is_int($row["S".$serviceNum."DataLengthA"]) and !ctype_digit($row["S".$serviceNum."DataLengthA"]) and $row["S".$serviceNum."DataLengthA"] >= 0){
			//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
			throw new Exception("Service ".$serviceNum.":  DataLengthA must be a positive integer.".$endl);
		}
		if(!is_int($row["S".$serviceNum."DataLengthB"]) and !ctype_digit($row["S".$serviceNum."DataLengthB"]) and $row["S".$serviceNum."DataLengthB"] >= 0){
			//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
			throw new Exception("Service ".$serviceNum.":  DataLengthB must be a positive integer.".$endl);
		}
		$totalDataLengthA += $row["S".$serviceNum."DataLengthA"];
		$totalDataLengthB += $row["S".$serviceNum."DataLengthB"];
	
		
		
		if($row["S".$serviceNum."DataLengthA"] !=0 or $row["S".$serviceNum."DataLengthB"] != 0){
		
			$bandwidth = $row["S".$serviceNum."DataLengthA"] + $row["S".$serviceNum."DataLengthB"];
			
			//ServiceLabel
			if(strlen(trim($row["S".$serviceNum."ServiceLabel"])) >16){
				throw new Exception("Service ".$serviceNum.": Too many characters in Service label.");
			}

			//ServiceIdentifier
			if(!is_int($row["S".$serviceNum."ServiceID"]) and !ctype_digit($row["S".$serviceNum."ServiceID"])){
				//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
				throw new Exception("Service ".$serviceNum.":  ServiceID is represented as a hex value to the user, but in base 10 in the ini file.  This must be a valid base 10 number in the ini file.".$endl);
			}
			if($row["S".$serviceNum."ServiceID"] > 16777216 or $row["S".$serviceNum."ServiceID"] < 0){// unsigned int assumed.
				throw new Exception("Service ".$serviceNum.": ServiceIdentifier may be a maximum of 24 bits.".$endl);
			}
			
			//CASystemUsed
			if(!is_int($row["S".$serviceNum."CASystemUsed"]) and !ctype_digit($row["S".$serviceNum."CASystemUsed"])){
				//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
				throw new Exception("Service ".$serviceNum.":  CASystemUsed must be 0 or 1.  Additionally, if used in a system newer than April 2012, should be set to 0.".$endl);
			}
			if($row["S".$serviceNum."CASystemUsed"] != 0 and $row["S".$serviceNum."CASystemUsed"] != 1){
				throw new Exception("Service ".$serviceNum.": CASystemsUsed must be either 0 or 1.  Additionally, if used in a system newer than April 2012, should be set to 0.".$endl);
			}
			
			//Language		
			if(!is_int($row["S".$serviceNum."LanguageInt"]) and !ctype_digit($row["S".$serviceNum."LanguageInt"])){
				//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
				throw new Exception("Service ".$serviceNum.":  Language must be an integer in 0-15.".$endl);
			}
			if($row["S".$serviceNum."LanguageInt"] < 15){
				if($row["S".$serviceNum."LanguageCode"] != $firstThirteenLanguageCodes[$row["S".$serviceNum."LanguageInt"]]){
					throw new Exception("Service ".$serviceNum.": Language and language code do not match.".$endl);
				}
			}
			else if($row["S".$serviceNum."LanguageInt"] == 15){
				$languageFound = false;
				$numberOfLanguages = 486-14;//This is the list of languages not including those paired with language integers 1-14.  If more languages receive
				// integer codes, then the number 14 must be increased (the condition to get into this section, as well as the last, must also be updated).  
				// If more languages in general are added, the number 486 must be increased.  
				// Note: such an update to the standard would cause substantial backwards compatibility issues. 
				
				for($i = 0; $i < $numberOfLanguages; $i++){
					if($row["S".$serviceNum."LanguageCode"] == $languageCodes[$i][1]){
						$languageFound = true;
						$i = $numberOfLanguages;//exit the loop
					}
				}		
				
				if(!$languageFound){
					throw new Exception("Service ".$serviceNum.": Language not found in the set of languages.".$endl);
				}
			}
			else{
				throw new Exception("Service ".$serviceNum.": Invalid Language (integer) selected for service $serviceNum.".$endl);
			}
			
			
			//Country code:  Must confirm that the code provided is a valid country code
			$countryCodeFound = false;
			
			for($i=0; $i < 250; $i++){
				if($row["S".$serviceNum."CountryCode"] == $countryCodes[$i]){
					$countryCodeFound = true;
					$i = 250;
				}
			}
			
			if(!$countryCodeFound){
				throw new Exception("Service ".$serviceNum.": This is not a valid country code.".$endl);
			}
			
			
			//Service Description
			if($row["S".$serviceNum."ServiceDesc"] < 0 or $row["S".$serviceNum."ServiceDesc"] > 31){
				throw new Exception("Service ".$serviceNum.": Service description for service ".$serviceNum." is not valid.".$endl);
			}		
			if(!is_int($row["S".$serviceNum."ServiceDesc"]) and !ctype_digit($row["S".$serviceNum."ServiceDesc"])){
				//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
				throw new Exception("Service ".$serviceNum.":  Service Description must be an integer.".$endl);
			}
			
			
			//Stream ID
			if($row["S".$serviceNum."StreamID"] < 0 or $row["S".$serviceNum."StreamID"] > 3){
				throw new Exception("Service ".$serviceNum.": Stream ID must be 0,1,2, or 3.".$endl);
			}
			if(!is_int($row["S".$serviceNum."StreamID"]) and !ctype_digit($row["S".$serviceNum."StreamID"])){
				//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
				throw new Exception("Service ".$serviceNum.":  StreamID must be an integer.".$endl);
			}
			
			
			//AudioSamplingRate, Textflag and Coderfield restrictions
			if($row["S".$serviceNum."AudioDataFlag"] == 0){
				if($row["S".$serviceNum."Source"] == 2 or $row["S".$serviceNum."Source"] == 3){
				//only in the circumstance that audio data flag is 0 and source is 2 or 3 are the 
				//  audiosampling rate or text flag options available.  If it is available, then 
				//  we need to make sure the selected option is valid.
				
					//Audiomode
					if(!is_int($row["S".$serviceNum."AudioMode"]) and !ctype_digit($row["S".$serviceNum."AudioMode"])){
						//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
						throw new Exception("Service ".$serviceNum.":  AudioMode may only be 0, 1, or 2.".$endl);
					}
					if($row["S".$serviceNum."AudioMode"] != 0 and $row["S".$serviceNum."AudioMode"] != 1 and $row["S".$serviceNum."AudioMode"] != 2){
						throw new Exception("Service ".$serviceNum.": AudioMode can only be 0, 1, or 2.".$endl);
					}
				
					//AudioSamplingRate restrictions
					if($row["S".$serviceNum."AudioCodec"] == 0){//AAC, AAC+
						//AudioSamplingrate
						if($row["S".$serviceNum."AudioSamplingRate"] != 1 and $row["S".$serviceNum."AudioSamplingRate"] !=3){
							throw new Exception("Service ".$serviceNum.": If AudioCoding is 0, AudioSamplingRate may only be 1 or 3.  Additionally, this only matters because AudioDataFlag is 0 and Source is ".$row["S0Source"]." (though it may be either 2 or 3).".$endl);
						}
						
						//AAC and AAC+ restrictions
						// Bytes/DRM Frame must be within certain ranges
						if($row["S".$serviceNum."SBRFlag"] == 0){//AAC
							//Audiomode restrictions, may only use Mono for AAC
							if($row["S".$serviceNum."AudioMode"] != 0){
								throw new Exception("Service ".$serviceNum.": When using the AAC codec (as opposed to AAC+, which occurs when you set the SBR flag), you may only use AudioMode 0 (mono).".$endl);
							}
							
							//bandwidth restrictions
							//Note:  based on sample configuration files, I am lead to believe that the units used in the configuration files
							//  are Bytes/DRM Frame.
							if($row["S".$serviceNum."AudioSamplingRate"] == 1){//12kHz
								if($bandwidth < 400 or $bandwidth > 699){
									throw new Exception("Service ".$serviceNum.": Bandwidth, $bandwidth, (sum of data length for part A and part B) is out of range. Range is 400-699.".$endl);
								}
							}
							else if($row["S".$serviceNum."AudioSamplingRate"] == 3){//24kHz
								if($bandwidth < 700 or $bandwidth > 999){
									throw new Exception("Service ".$serviceNum.": Bandwidth, $bandwidth, (sum of data length for part A and part B) is out of range. Range is 700-999.".$endl);
								}
							}
						}//Note: SBRFlag has already been confirmed to be either 0 or 1.
						else{ //AAC+ 
							if($row["S".$serviceNum."AudioSamplingRate"] == 1){//12kHz, so AudioMode must be 0 (mono)
								if($row["S".$serviceNum."AudioMode"] == 0){
									if($bandwidth < 611 or $bandwidth > 699){
										throw new Exception("Service ".$serviceNum.": Bandwidth, $bandwidth, (sum of data length for part A and part B) is out of range. Range is 601-699.".$endl);
									}
								}
								else{
									throw new Exception("Service ".$serviceNum.": When using AAC+ 12Khz, you must also use Mono.".$endl); 
								}
							}
							else{//24kHz, AudioSamplingRate has been confirmed to be 1 or 3 earlier in the code.
								if($row["S".$serviceNum."AudioMode"] == 0){//Mono
									if($bandwidth < 700 or $bandwidth > 1824){
										throw new Exception("Service ".$serviceNum.": Bandwidth, $bandwidth, (sum of data length for part A and part B) is out of range. Range is 700-1824.".$endl);
									}
								}
								else if($row["S".$serviceNum."AudioMode"] == 1){//Para
									if($bandwidth < 824 or $bandwidth > 1824){
										throw new Exception("Service ".$serviceNum.": Bandwidth, $bandwidth, (sum of data length for part A and part B) is out of range. Range is 824-1824.".$endl);
									}								
								}
								else{//Stereo
								//AudioMode has been confirmed to be 0, 1, or 2 earlier in the code.
									if($bandwidth < 1324 or $bandwidth > 3700){
										throw new Exception("Service ".$serviceNum.": Bandwidth, $bandwidth, (sum of data length for part A and part B) is out of range. Range is 1324-3700.".$endl);
									}								
								}
							}
						}					
					}		
					else if($row["S".$serviceNum."AudioCodec"] == 1){
						if($row["S".$serviceNum."AudioSamplingRate"] != 0 and $row["S".$serviceNum."AudioSamplingRate"] !=2){
							throw new Exception("Service ".$serviceNum.": If the Audio Codex is 1, AudioSamplingRate may only be 0 or 2.  Additionally, this only matters because AudioDataFlag is 0 and Source is ".$row["S".$serviceNum."Source"]." (though it may be either 2 or 3).".$endl);
						}			
					}	
					else if($row["S".$serviceNum."AudioCodec"] == 2){
						if($row["S".$serviceNum."AudioSamplingRate"] != 0){
							throw new Exception("Service ".$serviceNum.": If the Audio Codex is 2, AudioSamplingRate may only be 0.  Additionally, this only matters because AudioDataFlag is 0 and Source is ".$row["S".$serviceNum."Source"]." (though it may be either 2 or 3).".$endl);
						}							
					}
					
					//Textflag restrictions
					if(!is_int($row["S".$serviceNum."TextFlag"]) and !ctype_digit($row["S".$serviceNum."TextFlag"])){
						//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
						throw new Exception("Service ".$serviceNum.":  TextFlag may only be 0 or 1.".$endl);
					}
					if($row["S".$serviceNum."TextFlag"] != 0 and $row["S".$serviceNum."TextFlag"] != 1){
						throw new Exception("Service ".$serviceNum.":  Text flag may only be 0 or 1.".$endl);
					}
					if($row["S".$serviceNum."TextFlag"] != 1){
						$txtMessageConsumption += 4;
					}
					
					//Audio Coding
					if($row["S".$serviceNum."AudioCodec"] < 0 or $row["S".$serviceNum."AudioCodec"] > 2){
						throw new Exception("AudioCoding may only be 0, 1, or 2. Service ".$serviceNum.".".$endl);
					}
					
					
					if($row["S".$serviceNum."AudioCodec"] == 0){
						//SBR Flag
						if(!is_int($row["S".$serviceNum."SBRFlag"]) and !ctype_digit($row["S".$serviceNum."SBRFlag"])){
							//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
							throw new Exception("Service ".$serviceNum.":  Only options 0 and 1 are valid for SBRFlag.".$endl);
						}	
						if($row["S".$serviceNum."SBRFlag"] != 0 and $row["S".$serviceNum."SBRFlag"] != 1){
							throw new Exception("Service ".$serviceNum.": Only options 0 and 1 are valid for SBRFlag.".$endl);
						}
						
						//Coderfield restriction (another restriction for coderfield should appear in the else statement below)
						if($row["S".$serviceNum."CoderField"] != 0){
							throw new Exception("Service ".$serviceNum.": If AudioCodec is 0, Coderfield must be 0.".$endl);
						}
					}
					else if($row["S".$serviceNum."AudioCodec"] == 1 or $row["S".$serviceNum."AudioCodec"] == 2){
						//Coderfield
						//There are no restrictions for this in the multiplexer specification document, but if there were, here 
						//  is where it would matter
					}
				}	
				
				//RepeatAudio restrictions
				//Only available if AudioDataFlag is 0 and Source is 1 or 2.
				if($row["S".$serviceNum."Source"] == 1 or $row["S".$serviceNum."Source"] == 2){
					if(!is_int($row["S".$serviceNum."RepeatAudio"]) and !ctype_digit($row["S".$serviceNum."RepeatAudio"])){
						//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
						throw new Exception("Service ".$serviceNum.": RepeatAudio must be an integer. Additionally, if used in a system newer than April 2012, should be set to 1.".$endl);
					}	
					if($row["S".$serviceNum."RepeatAudio"] != 0 and $row["S".$serviceNum."RepeatAudio"] != 1){
						throw new Exception("Service ".$serviceNum.": RepeatAudio can only have values 0 and 1.  Additionally, if used in a system newer than April 2012, should be set to 1.".$endl);
					}
				}			
			}
			
			//EnhancementFlag restrictions
			if(!is_int($row["S".$serviceNum."EnhancementFlag"]) and !ctype_digit($row["S".$serviceNum."EnhancementFlag"])){
				//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
				throw new Exception("Service ".$serviceNum.": EnhancementFlag must be an integer. Additionally, if used in a system newer than April 2012, should be set to 0.".$endl);
			}	
			if($row["S".$serviceNum."EnhancementFlag"] != 0 and $row["S".$serviceNum."EnhancementFlag"] != 1){
				throw new Exception("Service ".$serviceNum.": EnhancementFlag can only be 0 or 1. Additionally, if used in a system newer than April 2012, should be set to 0.".$endl);
			}
			
			//Source restrictions
			if(!is_int($row["S".$serviceNum."Source"]) and !ctype_digit($row["S".$serviceNum."Source"])){
				//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
				throw new Exception("Service ".$serviceNum.": Source must be an integer.".$endl);
			}		
			if($row["S".$serviceNum."Source"] < 0 or $row["S".$serviceNum."Source"] > 6){//may only be 0-6
				throw new Exception("Service ".$serviceNum.": Source may only be options 0-6.".$endl);
			}
			
			//AudioFilename		
			//Only available if AudioDataFlag is 0 or 1 and Source is 1, 2, 3 or 5
			if($row["S".$serviceNum."AudioDataFlag"] == 0 or $row["S".$serviceNum."AudioDataFlag"] == 1){			
				if($row["S".$serviceNum."Source"] == 1 or $row["S".$serviceNum."Source"] == 2 or $row["S".$serviceNum."Source"] == 3 or $row["S".$serviceNum."Source"] == 5){
					if(strlen(trim($row["S".$serviceNum."AudioFileName"])) >255){// may be up to 255 bytes
						throw new Exception("Service ".$serviceNum.": Too many characters in audio file name.".$endl);
					}
				}
			}
			
			
		}
		else{//This service is unused. DataLengthForPartA and DataLengthForPartB are both 0.
		//Source must be 6.
			if(!is_int($row["S".$serviceNum."Source"]) and !ctype_digit($row["S".$serviceNum."Source"])){
				//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
				throw new Exception("Service ".$serviceNum.": Source must be 6 in an unused service.".$endl);
			}
			else if($row["S".$serviceNum."Source"] != 6){
				throw new Exception("Service ".$serviceNum.": Source must be 6 in an unused service.".$endl);
			}
		}
	}		
		
	
	
	//compose command line parameters to be sent to the C++ code on the server that determines what usage levels are permitted. 
	$commandLineParameters = $row["Robustness"]." ".$row["SpectrumOcc"]." ".$row["MSCMode"]." ".$totalDataLengthA." ".$row["ProtAInt"]." ".$row["ProtBInt"]." ".$row["ProtHInt"]." ".$totalDataLengthB;
		
	//call C++ code
	$response = shell_exec("lib/cs_length ".$commandLineParameters);
	
	//parse the response
	$answerArray = explode(" ", $response);	
	$partALim = $answerArray[0];
	$partBLim = $answerArray[1];
	$totalLim = $answerArray[2];
	
	//partALim is the total amount that part A of the 4 streams may use
	//totalDataLengthA is the total amount the ini file is attempting to use
	//This prevents the file from exceeding what is it allowed 
	if($partALim < $totalDataLengthA){	
		$m1 = "You have allotted too much data length for part A.";
		$m2 = "Alotted: ".$totalDataLengthA;
		$m3 = "Allowed: ".$partALim;
		throw new Exception($m1.$endl.$m2.$endl.$m3.$endl);
	}
		
	//partBLim is the total amount that part A of the 4 streams may use
	//totalDataLengthB is the total amount the ini file is attempting to use
	//This prevents the file from exceeding what is it allowed
	if($partBLim < $totalDataLengthB){
		$m1 = "You have allotted too much data length for part B.";
		$m2 = "Alotted: ".$totalDataLengthB;
		$m3 = "Allowed: ".$partBLim;
		throw new Exception($m1.$endl.$m2.$endl.$m3.$endl);
	}
	
	//The total stream usages (with txt messages, consuming 4 bytes each), may not exceed the permitted usage, 
	//  as calculated by the file cs_lengths.cpp
	if($totalLim < $totalDataLengthA + $totalDataLengthB + $txtMessageConsumption){	
		$errorMessage = "You have allotted too much data length between the streams.".$endl;
		$errorMessage .= "Alotted: ".($totalDataLengthA + $totalDataLengthB + $txtMessageConsumption).$endl;
		$errorMessage .= "Allowed: ".$totalLim.$endl;
		
		if($totalLim >= $totalDataLengthA + $totalDataLengthB){//this means $txtMessageConsumption pushed it over the limit.
			$errorMessage .= "Remember each TextFlag=1 consumes 4 bytes.".$endl;
		}		
		
		throw new Exception($errorMessage.$endl);
	}
	
	
	
	
	
	//IPEnabled 
	if(!is_int($row["IPEnabled"]) and !ctype_digit($row["IPEnabled"])){ 
		//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
		throw new Exception("IPEnabled field must either be 0 or 1.".$endl);
	}
	if( $row["IPEnabled"] != 0 and $row["IPEnabled"] != 1){//must be 0 or 1
		throw new Exception("IPEnabled field must either be 0 or 1.".$endl);
	}
	
	if($row["IPEnabled"] == 1){
		if(!filter_var($row["IPAddress"], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)){//When changed to IPv6, use FILTER_FLAG_IPV6 instead. ~3/21/2013
			$errorMessage = "IPAdress field does not contain a valid format IPv4 address.".$endl;
			$errorMessage .= "Address provided: ".$row["IPAddress"].$endl;
			
			throw new Exception($errorMessage);
		}
		
		//IPPort must be a valid port number
		if(!is_int($row["IPPort"]) and !ctype_digit($row["IPPort"])){
			//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
			throw new Exception("IPPort must be an integer.".$endl);
		}
		if($row["IPPort"] < 0 or $row["IPPort"] > 65535){
			//valid port numbers range from 0 to 65535.  Some port numbers are reserved, but this list grows and changes.
			throw new Exception("IPPort is not in the proper range.  It must be between (inclusive) 0-65535.  Consider using the default value 10000.".$endl);
		}
		
		//IP_TCP_UDP must be set to 0 or 1
		if(!is_int($row["IP_TCP_UDP"]) and !ctype_digit($row["IP_TCP_UDP"])){
			//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
			throw new Exception("IP_TCP_UDP must be 0 or 1.".$endl);
		}
		if($row["IP_TCP_UDP"] != 0 and $row["IP_TCP_UDP"] != 1){//must be 0 or 1
			throw new Exception("IP_TCP_UDP must either be 0 or 1.".$endl);
		}
	}
	
	
	//FEEnabled must be set to 0 or 1
	if(!is_int($row["FEEnabled"]) and !ctype_digit($row["FEEnabled"])){
		//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
		throw new Exception("FEEnabled must be 0 or 1.".$endl);
	}
	if($row["FEEnabled"] != 0 and $row["FEEnabled"] != 1){//must be 0 or 1
		throw new Exception("FEEnabled must either be 0 or 1.".$endl);
	}
	
	//FFFileName
	if($row["FEEnabled"] == 1){
		if(strlen(trim($row["FFFileName"])) > 255){//checks to make sure FFFileName is 255 characters or less
			throw new Exception("FFFileName has a 255 character limit.".$endl);
		}
	}
	
	//PFTEnabled must be set to 0 or 1
	if(!is_int($row["PFTEnabled"]) and !ctype_digit($row["PFTEnabled"])){
		//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
		throw new Exception("PFTEnabled must be 0 or 1.".$endl);
	}
	if($row["PFTEnabled"] != 0 and $row["PFTEnabled"] != 1){//must be 0 or 1
		throw new Exception("PFTEnabled must be either 0 or 1.".$endl);
	}
	
	
	if($row["PFTEnabled"] == 1){
		//PFTPayloadMtu
		if(!is_int($row["PFTPayloadMtu"]) and !ctype_digit($row["PFTPayloadMtu"])){
			//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
			throw new Exception("PFTPayloadMtu must be an integer.".$endl);
		}
		if($row["PFTPayloadMtu"] < 50 or $row["PFTEnabled"] > 16384){//must be within range 50 .. 16384
			throw new Exception("PFTPayloadMtu out of range.  Minimum 50, maximum 16384.  Consider using the default 1456.".$endl);
		}
		
		//PFTProtection
		if(!is_int($row["PFTProtection"]) and !ctype_digit($row["PFTProtection"])){
			//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
			throw new Exception("PFTProtection must be 0 or 1.".$endl);
		}
		if($row["PFTProtection"] != 0 and $row["PFTProtection"] != 1){// must be 0 or 1
			throw new Exception("PFTProtection must be either 0 or 1.".$endl);
		}		
		
		//PFTStrength
		if($row["PFTProtection"] == 1){
			if(!is_int($row["PFTStrength"]) and !ctype_digit($row["PFTStrength"])){
				//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
				throw new Exception("PFTStrength must be an integer (between 0 and 5, inclusive).".$endl);
			}
			if($row["PFTStrength"] < 0 or $row["PFTStrength"] > 5){//check to ensure value is in range
				throw new Exception("PFTStrength must be between 0 and 5 (inclusive).  Consider using the default value 0.".$endl);
			}
		}
		
		//PFTTransportation
		if(!is_int($row["PFTTransportation"]) and !ctype_digit($row["PFTTransportation"])){
			//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
			throw new Exception("PFTTransportation must be either 0 or 1.".$endl);
		}
		if($row["PFTTransportation"] != 0 and $row["PFTTransportation"] != 1){//must be 0 or 1
			throw new Exception("PFTTransportation must be either 0 or 1.".$endl);
		}	
		
		//PFTSource, PFTDestination
		if($row["PFTTransportation"] == 1){
			//PFTSource
			if(strlen(trim($row["PFTSource"]))>2){//16 bits is 2 bytes, strlen returns 
				throw new Exception("PFTSource can only be up to 16 bits.  This is 2 characters in ASCII.".$endl);
			}
			//PFTDestination
			if(strlen(trim($row["PFTDestination"]))>2){
				throw new Exception("PFTDestination can only be up to 16 bits.  This is 2 characters in ASCII.".$endl);
			}
		}				
	}
	
	
	//VUMeter
	if(!is_int($row["VUMeter"]) and !ctype_digit($row["VUMeter"])){
		//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
		throw new Exception("VUMeter must be either 0 or 1.".$endl);
	}
	if($row["VUMeter"] != 0 and $row["VUMeter"] != 1){//must be 0 or 1
		throw new Exception("VUMeter must be either 0 or 1.".$endl);
	}	
	
	//Timing
	if(!is_int($row["Timing"]) and !ctype_digit($row["Timing"])){
		//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
		throw new Exception("Timing must be either 0 or 1.".$endl);
	}
	if($row["Timing"] != 0 and $row["Timing"] != 1){//must be 0 or 1
		throw new Exception("Timing must be either 0 or 1.".$endl);
	}	
	
	//Clocktime
	if(!is_int($row["Clocktime"]) and !ctype_digit($row["Clocktime"])){
		//must check if this is an integer, to do this we see if it is an integer or string composed solely of digits
		throw new Exception("Clocktime must be either 0 or 1.".$endl);
	}
	if($row["Clocktime"] != 0 and $row["Clocktime"] != 1){//must be 0 or 1
		throw new Exception("Clocktime must be either 0 or 1.".$endl);
	}
	
	return true;

}



//function: write(filename)
//This takes information from the database and writes the configuration file.  
//   This is done from the database in order to prevent having to write multiple functions
//   and to avoid having to rewrite function in case communication between client and server
//   is modified. 
function write($filename){
	try{
		validate($filename); 
	}
	catch(Exception $e){
		throw $e;
	}
	
	include('config.php');

	//Connect to the database
	$dbhandle = mysql_connect($hostname, $username, $password);
	
	if(!$dbhandle){
		throw new Exception("Unable to connect to MySQL");
	}
	
	
	//Select the database
	$selected = mysql_select_db($databaseName,$dbhandle);
	
	if(!$selected){
		throw new Exception("Could not select examples");
	}
	
	
	//Execute the query, gathering all data from the database
	$result = mysql_query("SELECT * FROM `AutoSave` WHERE FileName = \"".$filename."\"");

	$row = mysql_fetch_array($result);
	
	if($row == false){
		throw new Exception("This file is not in the database.");
	}
	
	
	//If the programmer sets to debug mode, calling the function will write the file 
	//   the browser instead of to the file so that results of modifying this function
	//   can readily be seen.
	$debug = false;
		
	//Convert endlines from \n which are used in the linux file to <br> which is the
	//  endline in the browser
	if($debug){
		$endl = "<br>";
	}	
	else{
		$endl = "\n";	
	}

	$file  = "; ".$filename.$endl;
	$file .= ";  generated ".date('D M d H:i:s Y').$endl;
	$file .= ";  copywright notice here".$endl;
	$file .= $endl;
	$file .= "[Transmission]".$endl;
	$file .= "ConfigurationDescription=".$row["ConfigurationDesc"].$endl;
	$file .= "Robustness=".$row["Robustness"].$endl;
	$file .= "SpectrumOccupancy=".$row["SpectrumOcc"].$endl;
	$file .= "InterleaverDepthFlag=".$row["InterleaverDepth"].$endl;
	$file .= "MSCMode=".$row["MSCMode"].$endl;
	$file .= "SDCMode=".$row["SDCMode"].$endl;
	$file .= "BaseEnhancementFlag=".$row["BaseEnhancementFlag"].$endl;
	$file .= "ProtLevelForPartA=".$row["ProtAInt"].$endl;
	$file .= "ProtLevelForPartB=".$row["ProtBInt"].$endl;
	$file .= "ProtLevelForHierarchical=".$row["ProtHInt"].$endl;
	$file .= "HierarchicalBytes=".$row["HierarchicalBytes"].$endl;
	$file .= "AmDrm=".$row["AmDRM"].$endl;
	$file .= $endl;
	
	$file .= "[Stream0]".$endl;
	$file .= "DataLengthForPartA=".$row["S0DataLengthA"].$endl;
	$file .= "DataLengthForPartB=".$row["S0DataLengthB"].$endl;
	$file .= $endl;
	$file .= "[Service0]".$endl;
	$file .= "ServiceLabel=".$row["S0ServiceLabel"].$endl;
	$file .= "ServiceIdentifier=".$row["S0ServiceID"].$endl;
	$file .= "CASystemUsed=".$row["S0CASystemUsed"].$endl;
	$file .= "Language=".$row["S0LanguageInt"].$endl;
	$file .= "LanguageCode=".$row["S0LanguageCode"].$endl;
	$file .= "CountryCode=".$row["S0CountryCode"].$endl;
	$file .= "AudioDataFlag=".$row["S0AudioDataFlag"].$endl;
	$file .= "ServiceDescriptor=".$row["S0ServiceDesc"].$endl;
	$file .= "StreamId=".$row["S0StreamID"].$endl;
	$file .= "AudioCoding=".$row["S0AudioCodec"].$endl;
	$file .= "SBRFlag=".$row["S0SBRFlag"].$endl;
	$file .= "AudioMode=".$row["S0AudioMode"].$endl;
	$file .= "AudioSamplingRate=".$row["S0AudioSamplingRate"].$endl;
	$file .= "TextFlag=".$row["S0TextFlag"].$endl;
	$file .= "EnhancementFlag=".$row["S0EnhancementFlag"].$endl;
	$file .= "Source=".$row["S0Source"].$endl;
	$file .= "AudioFilename=".$row["S0AudioFileName"].$endl;
	$file .= "RepeatAudio=".$row["S0RepeatAudio"].$endl;
	$file .= "CoderField=".$row["S0CoderField"].$endl;
	$file .= $endl;
				
	$file .= "[Stream1]".$endl;
	$file .= "DataLengthForPartA=".$row["S1DataLengthA"].$endl;
	$file .= "DataLengthForPartB=".$row["S1DataLengthB"].$endl;
	$file .= $endl;
	$file .= "[Service1]".$endl;
	$file .= "ServiceLabel=".$row["S1ServiceLabel"].$endl;
	$file .= "ServiceIdentifier=".$row["S1ServiceID"].$endl;
	$file .= "CASystemUsed=".$row["S1CASystemUsed"].$endl;
	$file .= "Language=".$row["S1LanguageInt"].$endl;
	$file .= "LanguageCode=".$row["S1LanguageCode"].$endl;
	$file .= "CountryCode=".$row["S1CountryCode"].$endl;
	$file .= "AudioDataFlag=".$row["S1AudioDataFlag"].$endl;
	$file .= "ServiceDescriptor=".$row["S1ServiceDesc"].$endl;
	$file .= "StreamId=".$row["S1StreamID"].$endl;
	$file .= "AudioCoding=".$row["S1AudioCodec"].$endl;
	$file .= "SBRFlag=".$row["S1SBRFlag"].$endl;
	$file .= "AudioMode=".$row["S1AudioMode"].$endl;
	$file .= "AudioSamplingRate=".$row["S1AudioSamplingRate"].$endl;
	$file .= "TextFlag=".$row["S1TextFlag"].$endl;
	$file .= "EnhancementFlag=".$row["S1EnhancementFlag"].$endl;
	$file .= "Source=".$row["S1Source"].$endl;
	$file .= "AudioFilename=".$row["S1AudioFileName"].$endl;
	$file .= "RepeatAudio=".$row["S1RepeatAudio"].$endl;
	$file .= "CoderField=".$row["S1CoderField"].$endl;
	$file .= $endl;
				
	$file .= "[Stream2]".$endl;
	$file .= "DataLengthForPartA=".$row["S2DataLengthA"].$endl;
	$file .= "DataLengthForPartB=".$row["S2DataLengthB"].$endl;
	$file .= $endl;
	$file .= "[Service2]".$endl;
	$file .= "ServiceLabel=".$row["S2ServiceLabel"].$endl;
	$file .= "ServiceIdentifier=".$row["S2ServiceID"].$endl;
	$file .= "CASystemUsed=".$row["S2CASystemUsed"].$endl;
	$file .= "Language=".$row["S2LanguageInt"].$endl;
	$file .= "LanguageCode=".$row["S2LanguageCode"].$endl;
	$file .= "CountryCode=".$row["S2CountryCode"].$endl;
	$file .= "AudioDataFlag=".$row["S2AudioDataFlag"].$endl;
	$file .= "ServiceDescriptor=".$row["S2ServiceDesc"].$endl;
	$file .= "StreamId=".$row["S2StreamID"].$endl;
	$file .= "AudioCoding=".$row["S2AudioCodec"].$endl;
	$file .= "SBRFlag=".$row["S2SBRFlag"].$endl;
	$file .= "AudioMode=".$row["S2AudioMode"].$endl;
	$file .= "AudioSamplingRate=".$row["S2AudioSamplingRate"].$endl;
	$file .= "TextFlag=".$row["S2TextFlag"].$endl;
	$file .= "EnhancementFlag=".$row["S2EnhancmentFlag"].$endl;
	$file .= "Source=".$row["S2Source"].$endl;
	$file .= "AudioFilename=".$row["S2AudioFileName"].$endl;
	$file .= "RepeatAudio=".$row["S2RepeatAudio"].$endl;
	$file .= "CoderField=".$row["S2CoderField"].$endl;
	$file .= $endl;
				
	$file .= "[Stream3]".$endl;
	$file .= "DataLengthForPartA=".$row["S3DataLengthA"].$endl;
	$file .= "DataLengthForPartB=".$row["S3DataLengthB"].$endl;
	$file .= $endl;
	$file .= "[Service3]".$endl;
	$file .= "ServiceLabel=".$row["S3ServiceLabel"].$endl;
	$file .= "ServiceIdentifier=".$row["S3ServiceID"].$endl;
	$file .= "CASystemUsed=".$row["S3CASystemUsed"].$endl;
	$file .= "Language=".$row["S3LanguageInt"].$endl;
	$file .= "LanguageCode=".$row["S3LanguageCode"].$endl;
	$file .= "CountryCode=".$row["S3CountryCode"].$endl;
	$file .= "AudioDataFlag=".$row["S3AudioDataFlag"].$endl;
	$file .= "ServiceDescriptor=".$row["S3ServiceDesc"].$endl;
	$file .= "StreamId=".$row["S3StreamID"].$endl;
	$file .= "AudioCoding=".$row["S3AudioCodec"].$endl;
	$file .= "SBRFlag=".$row["S3SBRFlag"].$endl;
	$file .= "AudioMode=".$row["S3AudioMode"].$endl;
	$file .= "AudioSamplingRate=".$row["S3AudioSamplingRate"].$endl;
	$file .= "TextFlag=".$row["S3TextFlag"].$endl;
	$file .= "EnhancementFlag=".$row["S3EnhancementFlag"].$endl;
	$file .= "Source=".$row["S3Source"].$endl;
	$file .= "AudioFilename=".$row["S3AudioFileName"].$endl;
	$file .= "RepeatAudio=".$row["S3RepeatAudio"].$endl;
	$file .= "CoderField=".$row["S3CoderField"].$endl;
	$file .= $endl;
		
	$file .= "[Output]".$endl;
	$file .= "IPEnabled=".$row["IPEnabled"].$endl;
	$file .= "IPAddr=".$row["IPAddress"].$endl;
	$file .= "IPPort=".$row["IPPort"].$endl;
	$file .= "IP_TCP_UDP=".$row["IP_TCP_UDP"].$endl;
	$file .= "FFEnabled=".$row["FEEnabled"].$endl;
	$file .= "FFFileName=".$row["FFFileName"].$endl;
	$file .= "PFTEnabled=".$row["PFTEnabled"].$endl;
	$file .= "PFTPayloadMtu=".$row["PFTPayloadMtu"].$endl;
	$file .= "PFTProtection=".$row["PFTProtection"].$endl;
	$file .= "PFTStrength=".$row["PFTStrength"].$endl;
	$file .= "PFTTransportation=".$row["PFTTransportation"].$endl;
	$file .= "PFTSource=".$row["PFTSource"].$endl;
	$file .= "PFTDestination=".$row["PFTDestination"].$endl;
	$file .= $endl;
	$file .= "[Display]".$endl;
	$file .= "VUMeter=".$row["VUMeter"].$endl;
	$file .= "Timing=".$row["Timing"].$endl;
	$file .= "Clocktime=".$row["Clocktime"].$endl;

	
	
	//Output to file or to browser depending on whether the programmer has set
	//   the debug value 
	if($debug){
		echo $file;
	}
	else{
		//The file is written entirely in one line so the file is not open long.
		$worked = file_put_contents($iniDir.$filename,$file);
		if($worked){
			mysql_query("UPDATE AutoSave SET IsRealFile='1' WHERE FileName='$filename'");
		}
		else{
			throw new Exception ("File did not successfully write.");		
		}
	}	
	
}


//function parse(filename)
//  This function will take a file that has been saved to the filesystem (presumable just after being uploaded)
//	 	and parse it to store its contents in the database.
function parse($filename, $UID){

	//There is a possibility that the user has uploaded a file such that, for example, Spectrum Occupancy is 2.5.  This
	//  is not a permitted value, but the database only allows integers.  Tehrefore it would be implicitly cast to 2 upon 
	//  entering the database.  This may cause the user to believe that something is the case in the database when it is not.
	//  Additionally, someone may enter a description field which may only be a certain number of characters.  If they were to 
	//  exceed this amount, only part of their description were to be there.  I have decided to err on the side of preventing
	//  the user from uploading a file like this so that if something is uploaded we are certain that, even if values are 
	//  incorrect (and therefore must be caught in the wizard), that what was uploaded is exactly what the user thought was
	//  uploaded.  Therefore strong type checking has been added to parsing.  3/23/2013

	include('config.php');
	
	//Connect to the database
	$dbhandle = mysql_connect($hostname, $username, $password);
	
	if(!$dbhandle){
		throw new Exception("Unable to connect to MySQL");
	}

	
	//Select the database
	$selected = mysql_select_db($databaseName,$dbhandle);
	
	if(!$selected){
		throw new Exception("Could not select database.");
	}

	
	//to open the file, it must exist
	if(!file_exists($uploadDir.$filename)){
		throw new Exception($uploadDir.$filename." does not exist.");
	}
	// the file must also be readable
	if(!is_readable($uploadDir.$filename)){
		throw new Exception($uploadDir.$filename." is not readable.");
	}
	
	$fh = fopen($uploadDir.$filename, "r");
	//the file must open properly
	if(!$fh){
		throw new Exception($uploadDir.$filename." did not open properly.");
	}
	
	//parse 
	lookFor("[Transmission]", $fh);
	list($ConfigurationDescription, $comment) = getData("ConfigurationDescription",$fh);
	if(strlen(trim($ConfigurationDescription)) >255){
		throw new Exception("Too many characters in configuration description".$endl);
	}
	list($Robustness, $comment) = getData("Robustness",$fh);
	if(!is_int($Robustness) and !ctype_digit($Robustness)){
		throw new Exception("Robustness must be an integer.");
	}
	
	list($SpectrumOccupancy, $comment) = getData("SpectrumOccupancy",$fh);
	if(!is_int($SpectrumOccupancy) and !ctype_digit($SpectrumOccupancy)){
		throw new Exception("SpectrumOccupancy must be an integer.");
	}
	
	list($InterleaverDepthFlag, $comment) = getData("InterleaverDepthFlag",$fh);
	if(!is_int($InterleaverDepthFlag) and !ctype_digit($InterleaverDepthFlag)){
		throw new Exception("InterleaverDepthFlag must be an integer.");
	}
	
	list($MSCMode, $comment) = getData("MSCMode",$fh);
	if(!is_int($MSCMode) and !ctype_digit($MSCMode)){
		throw new Exception("MSCMode must be an integer.");
	}
	
	list($SDCMode, $comment) = getData("SDCMode",$fh);
	if(!is_int($SDCMode) and !ctype_digit($SDCMode)){
		throw new Exception("SDCMode must be an integer.");
	}
	
	list($BaseEnhancementFlag, $comment) = getData("BaseEnhancementFlag",$fh);
	if(!is_int($BaseEnhancementFlag) and !ctype_digit($BaseEnhancementFlag)){
		throw new Exception("BaseEnhancementFlag must be an integer.");
	}
	
	list($ProtLevelForPartA, $comment) = getData("ProtLevelForPartA",$fh);
	if(!is_int($ProtLevelForPartA) and !ctype_digit($ProtLevelForPartA)){
		throw new Exception("ProtLevelForPartA must be an integer.");
	}
	
	list($ProtLevelForPartB, $comment) = getData("ProtLevelForPartB",$fh);
	if(!is_int($ProtLevelForPartB) and !ctype_digit($ProtLevelForPartB)){
		throw new Exception("ProtLevelForPartB must be an integer.");
	}
	
	list($ProtLevelForHierarchical, $comment) = getData("ProtLevelForHierarchical",$fh);
	if(!is_int($ProtLevelForHierarchical) and !ctype_digit($ProtLevelForHierarchical)){
		throw new Exception("ProtLevelForHierarchical must be an integer.");
	}
	
	list($HierarchicalBytes, $comment) = getData("HierarchicalBytes",$fh);
	if(!is_int($HierarchicalBytes) and !ctype_digit($HierarchicalBytes)){
		throw new Exception("HierarchicalBytes must be an integer.");
	}
	
	list($AmDrm, $comment) = getData("AmDrm",$fh);
	if(!is_int($AmDrm) and !ctype_digit($AmDrm)){
		throw new Exception("AmDrm must be an integer.");
	}
	
	
	
	
	
	
	lookFor("[Stream0]", $fh);	
	list($DataLengthForPartA0, $comment) = getData("DataLengthForPartA",$fh);
	if(!is_int($DataLengthForPartA0) and !ctype_digit($DataLengthForPartA0)){
		throw new Exception("DataLengthForPartA0 must be an integer.");
	}
	
	list($DataLengthForPartB0, $comment) = getData("DataLengthForPartB",$fh);
	if(!is_int($DataLengthForPartB0) and !ctype_digit($DataLengthForPartB0)){
		throw new Exception("DataLengthForPartB0 must be an integer.");
	}
	
			
			
	lookFor("[Service0]", $fh);
	list($ServiceLabel0, $comment) = getData("ServiceLabel",$fh);
	if(strlen(trim($ServiceLabel0)) >16){
		throw new Exception("Too many characters in ServiceLabel0.");
	}
	
	list($ServiceIdentifier0, $comment) = getData("ServiceIdentifier",$fh);
	if(!is_int($ServiceIdentifier0) and !ctype_digit($ServiceIdentifier0)){
		throw new Exception("ServiceIdentifier0 must be an integer.");
	}
	
	list($CASystemUsed0, $comment) = getData("CASystemUsed",$fh);
	if(!is_int($CASystemUsed0) and !ctype_digit($CASystemUsed0)){
		throw new Exception("CASystemUsed0 must be an integer.");
	}
	
	list($Language0, $comment) = getData("Language",$fh);
	if(!is_int($Language0) and !ctype_digit($Language0)){
		throw new Exception("Language0 must be an integer.");
	}
	
	list($LanguageCode0, $comment) = getData("LanguageCode",$fh);
	list($CountryCode0, $comment) = getData("CountryCode",$fh);
	list($AudioDataFlag0, $comment) = getData("AudioDataFlag",$fh);
	if(!is_int($AudioDataFlag0) and !ctype_digit($AudioDataFlag0)){
		throw new Exception("AudioDataFlag0 must be an integer.");
	}
	
	list($ServiceDescriptor0, $comment) = getData("ServiceDescriptor",$fh);
	if(!is_int($ServiceDescriptor0) and !ctype_digit($ServiceDescriptor0)){
		throw new Exception("ServiceDescriptor0 must be an integer.");
	}
	
	list($StreamId0, $comment) = getData("StreamId",$fh);
	if(!is_int($StreamId0) and !ctype_digit($StreamId0)){
		throw new Exception("StreamId0 must be an integer.");
	}
	
	list($AudioCoding0, $comment) = getData("AudioCoding",$fh);
	if(!is_int($AudioCoding0) and !ctype_digit($AudioCoding0)){
		throw new Exception("AudioCoding0 must be an integer.");
	}
	
	list($SBRFlag0, $comment) = getData("SBRFlag",$fh);
	if(!is_int($SBRFlag0) and !ctype_digit($SBRFlag0)){
		throw new Exception("SBRFlag0 must be an integer.");
	}
	
	list($AudioMode0, $comment) = getData("AudioMode",$fh);
	if(!is_int($AudioMode0) and !ctype_digit($AudioMode0)){
		throw new Exception("AudioMode0 must be an integer.");
	}
	
	list($AudioSamplingRate0, $comment) = getData("AudioSamplingRate",$fh);
	if(!is_int($AudioSamplingRate0) and !ctype_digit($AudioSamplingRate0)){
		throw new Exception("AudioSamplingRate0 must be an integer.");
	}
	
	list($TextFlag0, $comment) = getData("TextFlag",$fh);
	if(!is_int($TextFlag0) and !ctype_digit($TextFlag0)){
		throw new Exception("TextFlag0 must be an integer.");
	}
	
	list($EnhancementFlag0, $comment) = getData("EnhancementFlag",$fh);
	if(!is_int($EnhancementFlag0) and !ctype_digit($EnhancementFlag0)){
		throw new Exception("EnhancementFlag0 must be an integer.");
	}
	
	list($Source0, $comment) = getData("Source",$fh);
	if(!is_int($Source0) and !ctype_digit($Source0)){
		throw new Exception("Source0 must be an integer.");
	}
	
	list($AudioFilename0, $comment) = getData("AudioFilename",$fh);
	if(strlen(trim($AudioFilename0)) >255){// may be up to 255 bytes
		throw new Exception("Too many characters in AudioFilename0.".$endl);
	}
	
	list($RepeatAudio0, $comment) = getData("RepeatAudio",$fh);
	if(!is_int($RepeatAudio0) and !ctype_digit($RepeatAudio0)){
		throw new Exception("RepeatAudio0 must be an integer.");
	}
	
	list($CoderField0, $comment) = getData("CoderField",$fh);//is this an integer?
	
	
	
	
	
	
	lookFor("[Stream1]", $fh);	
	list($DataLengthForPartA1, $comment) = getData("DataLengthForPartA",$fh);
	if(!is_int($DataLengthForPartA1) and !ctype_digit($DataLengthForPartA1)){
		throw new Exception("DataLengthForPartA1 must be an integer.");
	}
	
	list($DataLengthForPartB1, $comment) = getData("DataLengthForPartB",$fh);
	if(!is_int($DataLengthForPartB1) and !ctype_digit($DataLengthForPartB1)){
		throw new Exception("DataLengthForPartB1 must be an integer.");
	}
	
			
	lookFor("[Service1]", $fh);
	list($ServiceLabel1, $comment) = getData("ServiceLabel",$fh);
	if(strlen(trim($ServiceLabel1)) >16){
		throw new Exception("Too many characters in ServiceLabel1.");
	}
	
	list($ServiceIdentifier1, $comment) = getData("ServiceIdentifier",$fh);
	if(!is_int($ServiceIdentifier1) and !ctype_digit($ServiceIdentifier1)){
		throw new Exception("ServiceIdentifier1 must be an integer (when stored in the ini file, not on the user interface side of things).");
	}
	
	list($CASystemUsed1, $comment) = getData("CASystemUsed",$fh);
	if(!is_int($CASystemUsed1) and !ctype_digit($CASystemUsed1)){
		throw new Exception("CASystemUsed1 must be an integer.");
	}
	
	list($Language1, $comment) = getData("Language",$fh);
	if(!is_int($Language1) and !ctype_digit($Language1)){
		throw new Exception("Language1 must be an integer.");
	}
	
	list($LanguageCode1, $comment) = getData("LanguageCode",$fh);//Language and country codes are merely strings.  
	list($CountryCode1, $comment) = getData("CountryCode",$fh);	// Therefore the type checking will be fine implicitly
	list($AudioDataFlag1, $comment) = getData("AudioDataFlag",$fh);
	if(!is_int($AudioDataFlag1) and !ctype_digit($AudioDataFlag1)){
		throw new Exception("AudioDataFlag1 must be an integer.");
	}
	
	list($ServiceDescriptor1, $comment) = getData("ServiceDescriptor",$fh);
	if(!is_int($ServiceDescriptor1) and !ctype_digit($ServiceDescriptor1)){
		throw new Exception("ServiceDescriptor0 must be an integer.");
	}
	
	list($StreamId1, $comment) = getData("StreamId",$fh);
	if(!is_int($StreamId1) and !ctype_digit($StreamId1)){
		throw new Exception("StreamId1 must be an integer.");
	}
	
	list($AudioCoding1, $comment) = getData("AudioCoding",$fh);
	if(!is_int($AudioCoding1) and !ctype_digit($AudioCoding1)){
		throw new Exception("AudioCoding1 must be an integer.");
	}
	
	list($SBRFlag1, $comment) = getData("SBRFlag",$fh);
	if(!is_int($SBRFlag1) and !ctype_digit($SBRFlag1)){
		throw new Exception("SBRFlag1 must be an integer.");
	}
	
	list($AudioMode1, $comment) = getData("AudioMode",$fh);
	if(!is_int($AudioMode1) and !ctype_digit($AudioMode1)){
		throw new Exception("AudioMode1 must be an integer.");
	}
	
	list($AudioSamplingRate1, $comment) = getData("AudioSamplingRate",$fh);
	if(!is_int($AudioSamplingRate1) and !ctype_digit($AudioSamplingRate1)){
		throw new Exception("AudioSamplingRate1 must be an integer.");
	}
	
	list($TextFlag1, $comment) = getData("TextFlag",$fh);
	if(!is_int($TextFlag1) and !ctype_digit($TextFlag1)){
		throw new Exception("TextFlag1 must be an integer.");
	}
	
	list($EnhancementFlag1, $comment) = getData("EnhancementFlag",$fh);
	if(!is_int($EnhancementFlag1) and !ctype_digit($EnhancementFlag1)){
		throw new Exception("EnhancementFlag1 must be an integer.");
	}
	
	list($Source1, $comment) = getData("Source",$fh);
	if(!is_int($Source1) and !ctype_digit($Source1)){
		throw new Exception("Source1 must be an integer.");
	}
	
	list($AudioFilename1, $comment) = getData("AudioFilename",$fh);
	if(strlen(trim($AudioFilename1)) >255){// may be up to 255 bytes
		throw new Exception("Too many characters in AudioFilename1.".$endl);
	}
	
	list($RepeatAudio1, $comment) = getData("RepeatAudio",$fh);
	if(!is_int($RepeatAudio1) and !ctype_digit($RepeatAudio1)){
		throw new Exception("RepeatAudio1 must be an integer.");
	}
	
	list($CoderField1, $comment) = getData("CoderField",$fh);
	

	
	
	
	lookFor("[Stream2]", $fh);	
	list($DataLengthForPartA2, $comment) = getData("DataLengthForPartA",$fh);
	if(!is_int($DataLengthForPartA2) and !ctype_digit($DataLengthForPartA2)){
		throw new Exception("DataLengthForPartA2 must be an integer.");
	}
	
	list($DataLengthForPartB2, $comment) = getData("DataLengthForPartB",$fh);
	if(!is_int($DataLengthForPartA2) and !ctype_digit($DataLengthForPartA2)){
		throw new Exception("DataLengthForPartA2 must be an integer.");
	}
	
			
	lookFor("[Service2]", $fh);
	list($ServiceLabel2, $comment) = getData("ServiceLabel",$fh);
	if(strlen(trim($ServiceLabel2)) >16){
		throw new Exception("Too many characters in ServiceLabel2.");
	}
	
	list($ServiceIdentifier2, $comment) = getData("ServiceIdentifier",$fh);
	if(!is_int($ServiceIdentifier2) and !ctype_digit($ServiceIdentifier2)){
		throw new Exception("ServiceIdentifier2 must be an integer.");
	}
	
	list($CASystemUsed2, $comment) = getData("CASystemUsed",$fh);
	if(!is_int($CASystemUsed2) and !ctype_digit($CASystemUsed2)){
		throw new Exception("CASystemUsed2 must be an integer.");
	}
	
	list($Language2, $comment) = getData("Language",$fh);
	if(!is_int($Language2) and !ctype_digit($Language2)){
		throw new Exception("Language2 must be an integer.");
	}
	
	list($LanguageCode2, $comment) = getData("LanguageCode",$fh);
	list($CountryCode2, $comment) = getData("CountryCode",$fh);
	list($AudioDataFlag2, $comment) = getData("AudioDataFlag",$fh);
	if(!is_int($AudioDataFlag2) and !ctype_digit($AudioDataFlag2)){
		throw new Exception("AudioDataFlag2 must be an integer.");
	}
	
	list($ServiceDescriptor2, $comment) = getData("ServiceDescriptor",$fh);
	if(!is_int($ServiceDescriptor2) and !ctype_digit($ServiceDescriptor0)){
		throw new Exception("ServiceDescriptor2 must be an integer.");
	}
	
	list($StreamId2, $comment) = getData("StreamId",$fh);
	if(!is_int($StreamId2) and !ctype_digit($StreamId2)){
		throw new Exception("StreamId2 must be an integer.");
	}
	
	list($AudioCoding2, $comment) = getData("AudioCoding",$fh);
	if(!is_int($AudioCoding2) and !ctype_digit($AudioCoding2)){
		throw new Exception("AudioCoding2 must be an integer.");
	}
	
	list($SBRFlag2, $comment) = getData("SBRFlag",$fh);
	if(!is_int($SBRFlag2) and !ctype_digit($SBRFlag2)){
		throw new Exception("SBRFlag2 must be an integer.");
	}
	
	list($AudioMode2, $comment) = getData("AudioMode",$fh);
	if(!is_int($AudioMode2) and !ctype_digit($AudioMode2)){
		throw new Exception("AudioMode2 must be an integer.");
	}
	
	list($AudioSamplingRate2, $comment) = getData("AudioSamplingRate",$fh);
	if(!is_int($AudioSamplingRate2) and !ctype_digit($AudioSamplingRate2)){
		throw new Exception("AudioSamplingRate2 must be an integer.");
	}
	
	list($TextFlag2, $comment) = getData("TextFlag",$fh);
	if(!is_int($TextFlag2) and !ctype_digit($TextFlag2)){
		throw new Exception("TextFlag2 must be an integer.");
	}
	
	list($EnhancementFlag2, $comment) = getData("EnhancementFlag",$fh);
	if(!is_int($EnhancementFlag2) and !ctype_digit($EnhancementFlag2)){
		throw new Exception("EnhancementFlag2 must be an integer.");
	}
	
	list($Source2, $comment) = getData("Source",$fh);
	if(!is_int($Source2) and !ctype_digit($Source2)){
		throw new Exception("Source2 must be an integer.");
	}
	
	list($AudioFilename2, $comment) = getData("AudioFilename",$fh);
	if(strlen(trim($AudioFilename2)) >255){// may be up to 255 bytes
		throw new Exception("Too many characters in AudioFilename2.".$endl);
	}
	
	list($RepeatAudio2, $comment) = getData("RepeatAudio",$fh);
	if(!is_int($RepeatAudio2) and !ctype_digit($RepeatAudio2)){
		throw new Exception("RepeatAudio2 must be an integer.");
	}
	
	list($CoderField2, $comment) = getData("CoderField",$fh);

	
	
	
	
	
	
	lookFor("[Stream3]", $fh);	
	list($DataLengthForPartA3, $comment) = getData("DataLengthForPartA",$fh);
	if(!is_int($DataLengthForPartA3) and !ctype_digit($DataLengthForPartA3)){
		throw new Exception("DataLengthForPartA3 must be an integer.");
	}
	
	list($DataLengthForPartB3, $comment) = getData("DataLengthForPartB",$fh);
	if(!is_int($DataLengthForPartB3) and !ctype_digit($DataLengthForPartB3)){
		throw new Exception("DataLengthForPartB3 must be an integer.");
	}
				
			
	lookFor("[Service3]", $fh);
	list($ServiceLabel3, $comment) = getData("ServiceLabel",$fh);
	if(strlen(trim($ServiceLabel3)) >16){
		throw new Exception("Too many characters in ServiceLabel3.");
	}
	list($ServiceIdentifier3, $comment) = getData("ServiceIdentifier",$fh);
	if(!is_int($ServiceIdentifier3) and !ctype_digit($ServiceIdentifier3)){
		throw new Exception("ServiceIdentifier3 must be an integer.");
	}
	
	list($CASystemUsed3, $comment) = getData("CASystemUsed",$fh);
	if(!is_int($CASystemUsed3) and !ctype_digit($CASystemUsed3)){
		throw new Exception("CASystemUsed3 must be an integer.");
	}
	
	list($Language3, $comment) = getData("Language",$fh);
	if(!is_int($Language3) and !ctype_digit($Language3)){
		throw new Exception("Language3 must be an integer.");
	}
	
	list($LanguageCode3, $comment) = getData("LanguageCode",$fh);
	list($CountryCode3, $comment) = getData("CountryCode",$fh);
	list($AudioDataFlag3, $comment) = getData("AudioDataFlag",$fh);
	if(!is_int($AudioDataFlag3) and !ctype_digit($AudioDataFlag3)){
		throw new Exception("AudioDataFlag3 must be an integer.");
	}
	
	list($ServiceDescriptor3, $comment) = getData("ServiceDescriptor",$fh);
	if(!is_int($ServiceDescriptor3) and !ctype_digit($ServiceDescriptor0)){
		throw new Exception("ServiceDescriptor3 must be an integer.");
	}
	
	list($StreamId3, $comment) = getData("StreamId",$fh);
	if(!is_int($StreamId3) and !ctype_digit($StreamId3)){
		throw new Exception("StreamId3 must be an integer.");
	}
	
	list($AudioCoding3, $comment) = getData("AudioCoding",$fh);
	if(!is_int($AudioCoding3) and !ctype_digit($AudioCoding3)){
		throw new Exception("AudioCoding3 must be an integer.");
	}
	
	list($SBRFlag3, $comment) = getData("SBRFlag",$fh);
	if(!is_int($SBRFlag3) and !ctype_digit($SBRFlag3)){
		throw new Exception("SBRFlag3 must be an integer.");
	}
	
	list($AudioMode3, $comment) = getData("AudioMode",$fh);
	if(!is_int($AudioMode3) and !ctype_digit($AudioMode3)){
		throw new Exception("AudioMode3 must be an integer.");
	}
	
	list($AudioSamplingRate3, $comment) = getData("AudioSamplingRate",$fh);
	if(!is_int($AudioSamplingRate3) and !ctype_digit($AudioSamplingRate3)){
		throw new Exception("AudioSamplingRate3 must be an integer.");
	}
	
	list($TextFlag3, $comment) = getData("TextFlag",$fh);
	if(!is_int($TextFlag3) and !ctype_digit($TextFlag3)){
		throw new Exception("TextFlag3 must be an integer.");
	}
	
	list($EnhancementFlag3, $comment) = getData("EnhancementFlag",$fh);
	if(!is_int($EnhancementFlag3) and !ctype_digit($EnhancementFlag3)){
		throw new Exception("EnhancementFlag3 must be an integer.");
	}
	
	list($Source3, $comment) = getData("Source",$fh);
	if(!is_int($Source3) and !ctype_digit($Source3)){
		throw new Exception("Source3 must be an integer.");
	}
	
	list($AudioFilename3, $comment) = getData("AudioFilename",$fh);
	if(strlen(trim($AudioFilename3)) >255){// may be up to 255 bytes
		throw new Exception("Too many characters in AudioFilename3.".$endl);
	}
	
	list($RepeatAudio3, $comment) = getData("RepeatAudio",$fh);
	if(!is_int($RepeatAudio3) and !ctype_digit($RepeatAudio3)){
		throw new Exception("RepeatAudio3 must be an integer.");
	}
	
	list($CoderField3, $comment) = getData("CoderField",$fh);
	

	
	
	lookFor("[Output]", $fh);
	list($IPEnabled, $comment) = getData("IPEnabled",$fh);
	if(!is_int($IPEnabled) and !ctype_digit($IPEnabled)){
		throw new Exception("IPEnabled must be an integer.");
	}
	
	list($IPAddr, $comment) = getData("IPAddr",$fh);
	if(!filter_var($IPAddr, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)){//When changed to IPv6, use FILTER_FLAG_IPV6 instead. ~3/21/2013
		throw new Exception("IPAddress must be a properly formatted IPv4 address.");
	}
	
	list($IPPort, $comment) = getData("IPPort",$fh);
	if(!is_int($IPPort) and !ctype_digit($IPPort)){
		throw new Exception("IPPort must be an integer.");
	}
	
	list($IP_TCP_UDP, $comment) = getData("IP_TCP_UDP",$fh);
	if(!is_int($IP_TCP_UDP) and !ctype_digit($IP_TCP_UDP)){
		throw new Exception("IP_TCP_UDP must be an integer.");
	}
	
	list($FFEnabled, $comment) = getData("FFEnabled",$fh);
	if(!is_int($FFEnabled) and !ctype_digit($FFEnabled)){
		throw new Exception("FFEnabled must be an integer.");
	}
	
	list($FFFileName, $comment) = getData("FFFileName",$fh);
	if(strlen(trim($FFFileName)) > 255){//checks to make sure FFFileName is 255 characters or less
		throw new Exception("FFFileName has a 255 character limit.".$endl);
	}
	
	
	list($PFTEnabled, $comment) = getData("PFTEnabled",$fh);
	if(!is_int($PFTEnabled) and !ctype_digit($PFTEnabled)){
		throw new Exception("PFTEnabled must be an integer.");
	}
	
	list($PFTPayloadMtu, $comment) = getData("PFTPayloadMtu",$fh);
	if(!is_int($PFTPayloadMtu) and !ctype_digit($PFTPayloadMtu)){
		throw new Exception("PFTPayloadMtu must be an integer.");
	}
	
	list($PFTProtection, $comment) = getData("PFTProtection",$fh);
	if(!is_int($PFTProtection) and !ctype_digit($PFTProtection)){
		throw new Exception("PFTProtection must be an integer.");
	}
	
	list($PFTStrength, $comment) = getData("PFTStrength",$fh);
	if(!is_int($PFTStrength) and !ctype_digit($PFTStrength)){
		throw new Exception("PFTStrength must be an integer.");
	}
	
	list($PFTTransportation, $comment) = getData("PFTTransportation",$fh);
	if(!is_int($PFTTransportation) and !ctype_digit($PFTTransportation)){
		throw new Exception("PFTTransportation must be an integer.");
	}
	
	list($PFTSource, $comment) = getData("PFTSource",$fh);
	if(!is_int($PFTSource) and !ctype_digit($PFTSource)){
		throw new Exception("PFTSource must be an integer.");
	}
	
	list($PFTDestination, $comment) = getData("PFTDestination",$fh);
	if(!is_int($PFTDestination) and !ctype_digit($PFTDestination)){
		throw new Exception("PFTDestination must be an integer.");
	}
	
	
	
	

	lookFor("[Display]", $fh);
	list($VUMeter, $comment) = getData("VUMeter",$fh);
	if(!is_int($VUMeter) and !ctype_digit($VUMeter)){
		throw new Exception("VUMeter must be an integer.");
	}
	
	list($Timing, $comment) = getData("Timing",$fh);
	if(!is_int($Timing) and !ctype_digit($Timing)){
		throw new Exception("Timing must be an integer.");
	}
	
	list($Clocktime, $comment) = getData("Clocktime",$fh);
	if(!is_int($Clocktime) and !ctype_digit($Clocktime)){
		throw new Exception("Clocktime must be an integer.");
	}
	
	
        $result = mysql_query("INSERT INTO `$databaseName`.`AutoSave` (`UserID`,`FileID`, `FileLocation`,`FileName`, `IsMostRecent`, `IsRealFile`, `ConfigurationDesc`, `Location`, `SpectrumOcc`, `Robustness`, `InterleaverDepth`, `MSCMode`, `SDCMode`, `BaseEnhancementFlag`, `ProtAInt`, `ProtAValue`, `ProtBInt`, `ProtBValue`, `ProtHValue`, `ProtHInt`, `HierarchicalBytes`, `AmDRM`, `S0DataLengthA`, `S0DataLengthB`, `S0ServiceLabel`, `S0ServiceID`, `S0CASystemUsed`, `S0LanguageInt`, `S0LanguageCode`, `S0CountryInt`, `S0CountryCode`, `S0AudioDataFlag`, `S0ServiceDesc`, `S0StreamID`, `S0AudioCodec`, `S0SBRFlag`, `S0AudioMode`, `S0AudioSamplingRate`, `S0TextFlag`, `S0EnhancementFlag`, `S0Source`, `S0AudioFileName`, `S0RepeatAudio`, `S0CoderField`, `S1DataLengthA`, `S1DataLengthB`, `S1ServiceLabel`, `S1ServiceID`, `S1CASystemUsed`, `S1LanguageInt`, `S1LanguageCode`, `S1CountryInt`, `S1CountryCode`, `S1AudioDataFlag`, `S1ServiceDesc`, `S1StreamID`, `S1AudioCodec`, `S1SBRFlag`, `S1AudioMode`, `S1AudioSamplingRate`, `S1TextFlag`, `S1EnhancementFlag`, `S1Source`, `S1AudioFileName`, `S1RepeatAudio`, `S1CoderField`, `S2DataLengthA`, `S2DataLengthB`, `S2ServiceLabel`, `S2ServiceID`, `S2CASystemUsed`, `S2LanguageInt`, `S2LanguageCode`, `S2CountryInt`, `S2CountryCode`, `S2AudioDataFlag`, `S2ServiceDesc`, `S2StreamID`, `S2AudioCodec`, `S2SBRFlag`, `S2AudioMode`, `S2AudioSamplingRate`, `S2TextFlag`, `S2EnhancmentFlag`, `S2Source`, `S2AudioFileName`, `S2RepeatAudio`, `S2CoderField`, `S3DataLengthA`, `S3DataLengthB`, `S3ServiceLabel`, `S3ServiceID`, `S3CASystemUsed`, `S3LanguageInt`, `S3LanguageCode`, `S3CountryID`, `S3CountryCode`, `S3AudioDataFlag`, `S3ServiceDesc`, `S3StreamID`, `S3AudioCodec`, `S3SBRFlag`, `S3AudioMode`, `S3AudioSamplingRate`, `S3TextFlag`, `S3EnhancementFlag`, `S3Source`, `S3AudioFileName`, `S3RepeatAudio`, `S3CoderField`, `IPEnabled`, `IPAddress`, `IPPort`, `IP_TCP_UDP`, `FEEnabled`, `FFFileName`, `PFTEnabled`, `PFTPayloadMtu`, `PFTProtection`, `PFTStrength`, `PFTTransportation`, `PFTSource`, `PFTDestination`, `VUMeter`, `Timing`, `Clocktime`, `Preset`) VALUES ('$UID','', NULL,'$filename', '1', '0',  '$ConfigurationDescription', NULL,'$SpectrumOccupancy', '$Robustness', '$InterleaverDepthFlag', '$MSCMode', '$SDCMode', '$BaseEnhancementFlag', '$ProtLevelForPartA', NULL, '$ProtLevelForPartB', NULL, NULL, '$ProtLevelForHierarchical', '$HierarchicalBytes', '$AmDrm', '$DataLengthForPartA0', '$DataLengthForPartB0', '$ServiceLabel0', '$ServiceIdentifier0', '$CASystemUsed0', '$Language0', '$LanguageCode0', NULL, '$CountryCode0', '$AudioDataFlag0', '$ServiceDescriptor0', '$StreamId0', '$AudioCoding0', '$SBRFlag0', '$AudioMode0', '$AudioSamplingRate0', '$TextFlag0', '$EnhancementFlag0', '$Source0', '$AudioFilename0', '$RepeatAudio0', '$CoderField0', '$DataLengthForPartA1', '$DataLengthForPartB1', '$ServiceLabel1', '$ServiceIdentifier1', '$CASystemUsed1', '$Language1', '$LanguageCode1', NULL, '$CountryCode1', '$AudioDataFlag1', '$ServiceDescriptor1', '$StreamId1', '$AudioCoding1', '$SBRFlag1', '$AudioMode1', '$AudioSamplingRate1', '$TextFlag1', '$EnhancementFlag1', '$Source1', '$AudioFilename1', '$RepeatAudio1', '$CoderField1', '$DataLengthForPartA2', '$DataLengthForPartB2', '$ServiceLabel2', '$ServiceIdentifier2', '$CASystemUsed2', '$Language2', '$LanguageCode2', NULL, '$CountryCode2', '$AudioDataFlag2', '$ServiceDescriptor2', '$StreamId2', '$AudioCoding2', '$SBRFlag2', '$AudioMode2', '$AudioSamplingRate2', '$TextFlag2', '$EnhancementFlag2', '$Source2', '$AudioFilename2', '$RepeatAudio2', '$CoderField2', '$DataLengthForPartA3', '$DataLengthForPartB3', '$ServiceLabel3', '$ServiceIdentifier3', '$CASystemUsed3', '$Language3', '$LanguageCode3', NULL, '$CountryCode3', '$AudioDataFlag3', '$ServiceDescriptor3', '$StreamId3', '$AudioCoding3', '$SBRFlag3', '$AudioMode3', '$AudioSamplingRate3', '$TextFlag3', '$EnhancementFlag3', '$Source3', '$AudioFilename3', '$RepeatAudio3', '$CoderField3', '$IPEnabled', '$IPAddr', '$IPPort', '$IP_TCP_UDP', '$FFEnabled', '$FFFileName', '$PFTEnabled', '$PFTPayloadMtu', '$PFTProtection', '$PFTStrength', '$PFTTransportation', '$PFTSource', '$PFTDestination', '$VUMeter', '$Timing', '$Clocktime' , '0');");
	
        if($result == false){
                throw new Exception("Could not place this file in the database.".$endl);
        }	
	
	fclose($fh);
}



?>
