<?php
	function renameFile($rename, $file) {
		//Connect to the database
		require('config.php');
		$database = new PDO('mysql:host='.$hostname.';dbname='.$databaseName, $username, $password);

		//Rename the selected file
		$database->exec("UPDATE AutoSave SET FileName = '".$rename."' WHERE FileID = ".$file);

		//Close the database connection
		$datebase = null;
	}
?>
