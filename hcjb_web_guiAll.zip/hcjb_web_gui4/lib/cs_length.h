// vim:set tabstop=3 shiftwidth=3:

#ifndef CS_LENGTH_H
#define CS_LENGTH_H

// SM: Standard Mapping
// HMMix: mixed Hierarchical Mapping
// HMSym: symmetrical Hierarchical Mapping

// MSC_mode: 64QAM SM=0, HMMix(HonI)=1, HMSym(HonIQ)=2, 16QAM SM=3
// spectrum_occupancy: 4.5 kHz=0, 5 kHz=1, 9 kHz=2, 10 kHz=3, 18 kHz=4, 20 kHz=5

// You can use part_A_cells, part_B_cells, cells,
// part_A_bits, part_B_bits, VSPP_bits,
// part_A_bytes, part_B_bytes, VSPP_bytes,
// length_bits, and length_bytes
// to display lengths for the user.

bool parameter_ok(int p, int p_low, int p_high);
bool parameters_ok(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC, int Code_Rate_Part_1, int Code_Rate_Part_2, int Code_Rate_Hier);
int find_p_max(int MSC_mode);
int cells(int robustness_mode, int spectrum_occupancy);
int find_L1(int MSC_mode,int Code_Rate_Part_1, int N1);
int part_A_cells(int MSC_mode, int Part_A_bytes_from_SDC, int Code_Rate_Part_1);
int part_A_bits(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC, int Code_Rate_Part_1);
float part_A_bytes(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC, int Code_Rate_Part_1);
int int_part_A_bytes(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC, int Code_Rate_Part_1);
int find_L2(int MSC_mode,int Code_Rate_Part_2, int N2);
int part_B_cells3(int robustness_mode, int spectrum_occupancy, int N1); // Passing N1 allows N1 to be calculated once by caller for its own use and then passed as well.
int part_B_cells(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC, int Code_Rate_Part_1);
int part_B_bits(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC, int Code_Rate_Part_1, int Code_Rate_Part_2);
float part_B_bytes(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC, int Code_Rate_Part_1, int Code_Rate_Part_2);
int int_part_B_bytes(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC, int Code_Rate_Part_1, int Code_Rate_Part_2);
int find_LVSPP(int MSC_mode,int Code_Rate_Hier,int N1, int N2);
int VSPP_bits(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC, int Code_Rate_Part_1, int Code_Rate_Hier);
float VSPP_bytes(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC, int Code_Rate_Part_1, int Code_Rate_Hier);
int int_VSPP_bytes(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC, int Code_Rate_Part_1, int Code_Rate_Hier);
int length_bits(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC, int Code_Rate_Part_1, int Code_Rate_Part_2, int Code_Rate_Hier);
float length_bytes(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC, int Code_Rate_Part_1, int Code_Rate_Part_2, int Code_Rate_Hier);
int int_length_bytes(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC,int Code_Rate_Part_1, int Code_Rate_Part_2, int Code_Rate_Hier);

// Typically, use part_A_bytes_OK to check requested Part A.
// If it is bad, it is typically too large.
// Then use int_part_B_bytes and int_VSPP_bytes
// to fill in Part B and VSPP integer byte lengths for the user.

// part_A_bytes_OK presently unimplemented
//int part_A_bytes_OK(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC, int Code_Rate_Part_1);

#endif
