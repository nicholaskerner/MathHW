<?php
	//Start the session and connect to the database
	session_start();
	require('../../config.php');

	$database = new PDO('mysql:host='.$hostname.';dbname='.$databaseName, $username, $password);

	$subject = $_GET["Subject"];
	$description = $_GET["Description"];
	$userID = $_SESSION['UserID'];
	
	//Insert bug into database
	$bugInsert = $database->prepare("INSERT INTO `Bugs` (`Subject`, `Description`, `UserID`) VALUES (:Subject, :Description, :UserID)");
	$bugInsert->bindParam(':Subject', $subject);
	$bugInsert->bindParam(':Description', $description);
	$bugInsert->bindParam(':UserID', $userID);
	$bugInsert->execute();

	//Close the database connection
	$database = null;
?>
