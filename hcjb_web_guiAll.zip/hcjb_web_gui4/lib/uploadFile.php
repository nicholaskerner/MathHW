<?php
	function uploadFile($file) {
		require('config.php');
		require('lib/writerParserValidator.php');

		//Check for errors
		if ($file['error'] > 0) {
			return "The file has uploaded with errors";
		}

		//Check file type
		if ($file['type'] != "application/x-wine-extension-ini" and $file['type'] != "application/octet-stream") {
			return "You have submitted an invalid file type, only ini files are accepted, and you submitted an ".$file['type'];
		}

		//Check if file exists
		if (file_exists($uploadDir.$file['name'])) {
			return "File already exists in upload directory";
		}

		//Connect to database
		$database = new PDO('mysql:host='.$hostname.';dbname='.$databaseName, $username, $password);

		//Check for file with duplicate names in database
		$nameQuery = $database->query("SELECT `FileID` FROM `AutoSave` WHERE FileName = '".$file['name']."' LIMIT 1");
		$row = $nameQuery->fetch(PDO::FETCH_ASSOC);

		if (isset($row{'FileID'})) {
			$database = null;
			return "A file with the same name already exists in the database";
		}

		else {
			$database = null;
		}

		//Save uploaded file
		move_uploaded_file($file["tmp_name"], $uploadDir.$file['name']);

		//Parse and write the file to the database and file
		try {
			parse($file['name'], $_SESSION['UserID']);
			write($file['name']);
		}

		catch (Exception $e) {
			return 'Caught exception: '.$e->getMessage();
		}

		return "true";
	}
?>
