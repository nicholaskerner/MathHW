<?php
	function copyFile($selection) {
		//Seperate files
		$copy = explode("*", $selection);

		//Connect to the database
		require('config.php');
		$database = new PDO('mysql:host='.$hostname.';dbname='.$databaseName, $username, $password);

		//Copy the one row into a new row
		foreach ($copy as $file) {
			$database->exec("CREATE TEMPORARY TABLE tempTable SELECT * FROM `AutoSave` WHERE `FileID` = ".$file);

			//Get file name
			$nameQuery = $database->query("SELECT `FileName` FROM `AutoSave` WHERE FileID = ".$file);
			$row = $nameQuery->fetch(PDO::FETCH_ASSOC);
			$copiedName = "Copy of " . $row{'FileName'};

			$database->exec("UPDATE tempTable SET FileID = NULL, FileName = '".$copiedName."', UserID = '".$_SESSION['UserID']."'");
			$database->exec("INSERT INTO `AutoSave` SELECT * FROM tempTable;");
			$database->exec("DROP TEMPORARY TABLE IF EXISTS tempTable;");
		}

		//Close the database connection
		$datebase = null;
	}
?>
