#include<iostream>
#include<sstream>
#include "../SampleConfigs/C++ Files/cs_length.h"

using namespace std;

int main(int argc, char* argv[]){

	const int num = 8;

	stringstream ss;  
	int data[num];
	
	for(int i = 1; i < num+1; i++){
		stringstream ss;  
		ss << argv[i];
		ss >> data[i-1];		
	}
	
	int Robustness = data[0];
	int SpectrumOccupancy = data[1];
	int MSCMode = data[2];
	int Part_A_Bytes_from_SDC = data[3];
	int ProtLevelForPartA = data[4];
	int ProtLevelForPartB = data[5];
	int ProtLevelForHierarchical = data[6];	
	int Part_B_Bytes = data[7];
	
	int PartA = int_part_A_bytes(Robustness, SpectrumOccupancy, MSCMode, Part_A_Bytes_from_SDC, ProtLevelForPartA);
	int PartB = int_part_B_bytes(Robustness, SpectrumOccupancy, MSCMode, Part_A_Bytes_from_SDC, ProtLevelForPartA, ProtLevelForPartB);
	int TotalPerStream = int_length_bytes(Robustness, SpectrumOccupancy, MSCMode, Part_A_Bytes_from_SDC, ProtLevelForPartA, ProtLevelForPartB, ProtLevelForHierarchical);
	
	cout << PartA << " " << PartB << " " << TotalPerStream;


	/*
	cout << Robustness << " " << SpectrumOccupancy << " " << MSCMode << " " << Part_A_Bytes_from_SDC << " " << ProtLevelForPartA << " " << ProtLevelForPartB << endl;	
	cout << PartA << " " << PartB << " " << TotalPerStream << endl;
		
	cout << Robustness << endl << SpectrumOccupancy << endl << MSCMode << endl << Part_A_Bytes_from_SDC << endl << ProtLevelForPartA << endl << ProtLevelForPartB << endl << ProtLevelForHierarchical << endl << Part_B_Bytes << endl;
	cout << endl;
	cout << "Results: " << endl;
	cout << "Part A actual: " << Part_A_Bytes_from_SDC << endl;
	cout << "Part A possible: " << PartA << endl << endl;
	
	cout << "Part B actual: " << Part_B_Bytes << endl;
	cout << "Part B possible: " << PartB << endl << endl;
	
	cout << "Total: " << TotalPerStream << endl;
*/


	
	return 0;
}
