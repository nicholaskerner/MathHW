<?php
	function deleteFile($selection) {
		//Seperate files
		$delete = explode("*", $selection);

		//Connect to the database
		require('config.php');
		$database = new PDO('mysql:host='.$hostname.';dbname='.$databaseName, $username, $password);

		//Delete the file selection
		foreach ($delete as $file) {
			//Delete physical file if it exists
			$fileQuery = $database->query("SELECT `IsRealFile`, `FileName` FROM `AutoSave` WHERE FileID = '".$file."' LIMIT 1");
			$row = $fileQuery->fetch(PDO::FETCH_ASSOC);

			if ($row{'IsRealFile'}) {
				shell_exec("rm ".$iniDir.$row{'FileName'});
			}

			$database->exec("DELETE FROM `AutoSave` WHERE `AutoSave`.`FileID` = ".$file);
		}

		//Close the database connection
		$datebase = null;
	}
?>
