<?php
	function downloadFile($file) {
		//Connect to the database
		require('config.php');
		$database = new PDO('mysql:host='.$hostname.';dbname='.$databaseName, $username, $password);

		$fileQuery = $database->query("SELECT `IsRealFile`, `FileName` FROM `AutoSave` WHERE FileID = '".$file."' LIMIT 1");
		$row = $fileQuery->fetch(PDO::FETCH_ASSOC);

		$isReal = $row{'IsRealFile'};
		$fileName = $row{'FileName'};

		//Close connection to database
		$database = null;

		if ($isReal) {
			$database = null;
			return array("true", $fileName);
		}

		else {
			return array("The file must be validated in order to be downloaded", $fileName);
		}
	}
?>
