<?php
	function newFile($id, $name) {
		//Connect to the database
		require('config.php');
		$database = new PDO('mysql:host='.$hostname.';dbname='.$databaseName, $username, $password);

		//Copy the one row into a new row
		$database->exec("CREATE TEMPORARY TABLE tempTable SELECT * FROM `AutoSave` WHERE `FileID` = ".$id);
		$database->exec("UPDATE tempTable SET FileID = NULL, Preset = 0, UserID = '".$_SESSION['UserID']."', FileName = '".$name."'");
		$database->exec("INSERT INTO `AutoSave` SELECT * FROM tempTable;");
		$database->exec("DROP TEMPORARY TABLE IF EXISTS tempTable;");

		//Retrieve newest file ID
		$fileIDQuery = $database->query("SELECT `FileID` FROM `AutoSave` ORDER BY `FileID` DESC LIMIT 1");
		$fileIDResults = $fileIDQuery->fetch(PDO::FETCH_ASSOC);

		$fileID = $fileIDResults{'FileID'};

		//Close the database connection
		$datebase = null;

		return $fileID;
	}
?>
