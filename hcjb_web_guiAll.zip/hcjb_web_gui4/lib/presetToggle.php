<?php
	function presetToggle($selection) {
		//Seperate files
		$preset = explode("*", $selection);

		//Connect to the database
		require('config.php');
		$database = new PDO('mysql:host='.$hostname.';dbname='.$databaseName, $username, $password);

		//Toggle preset for the selection
		foreach ($preset as $file) {
			//Get preset for toggle
			$presetQuery = $database->query("SELECT `Preset` FROM `AutoSave` WHERE FileID = ".$file);
			$row = $presetQuery->fetch(PDO::FETCH_ASSOC);

			if ($row{'Preset'}) {
				$preset = 0;
			}

			else {
				$preset = 1;
			}

			$database->exec("UPDATE AutoSave SET Preset = '".$preset."' WHERE FileID = ".$file);
		}

		//Close the database connection
		$datebase = null;
	}
?>
