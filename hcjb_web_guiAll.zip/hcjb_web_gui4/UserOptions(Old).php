<!DOCTYPE html>
<html lang="en">
	<head>
<link href="bootstrap/css/bootstrap.css" rel="stylesheet">
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>

<script src="js/validatorAdminCredentials.js"></script>
	</head>
<body>
<div class="bs-docs-example">
            <ul id="myTab" class="nav nav-tabs">
              <li class="active"><a href="#UpdatePW" data-toggle="tab">Update Password</a></li>
              <li><a href="#ChangeQA" data-toggle="tab">Change Secret Question and Answer</a></li>
              <li><a href="#ChangeViewMode" data-toggle="tab">Change View Mode</a></li>
			  <li><a href="file.php" >Return to File Page</a></li>
            </ul>
			
           <div id="myTabContent" class="tab-content">
              <div class="tab-pane fade in active" id="UpdatePW">
			<form class="form-horizontal" name="passwordChange" onsubmit="return validatorPW()" action="UpdatePW_BE.php" method="post">
				
				<fieldset>
				<legend>Change Password</legend>
				<div class="control-group" id="passwordGroup">
					<label class="control-label" for="password">New Password</label>
					<div class="controls">
						<input type="password" class="input-xlarge" id="password" name="password">
						<span class="help-inline" id="passwordHelp"></span>
					</div>
				</div>
				<div class="control-group" id="passwordConfirmGroup">
					<label class="control-label" for="passwordConfirm">Confirm Password</label>
					<div class="controls">
						<input type="password" class="input-xlarge" id="passwordConfirm" name="passwordConfirm">
						<span class="help-inline" id="passwordConfirmHelp"></span>
					</div>
				</div>
				<div class="form-actions">
					<button value="submit" type="submit" class="btn btn-primary">Submit</button>
					<button class="btn" value="Reload Page" onClick="document.location.reload(true)">Cancel</button>
				</div>
			</fieldset>
			</form>
			</div>
			
			<div class="tab-pane fade" id="ChangeQA">
			<form class="form-horizontal" name="questionChange" onsubmit="return validatorQA()" action="UpdateQA_BE.php" method="post">
			<fieldset>
				<legend>Update Secret Question + Answer</legend>
				<div class="control-group" id="secretQuestionGroup">
					<label class="control-label" for="question">New Secret Question</label>
					<div class="controls">
						<input type="text" class="input-xlarge" id="question" name="question">
						<span class="help-inline" id="questionHelp"></span>
					</div>
				</div>
				<div class="control-group" id="secretAnswerGroup">
					<label class="control-label" for="answer">New Secret Answer</label>
					<div class="controls">
						<input type="text" class="input-xlarge" id="answer" name="answer">
						<span class="help-inline" id="answerHelp"></span>
					</div>
				</div>
				<div class="control-group" id="secretAnswerConfirmGroup">
					<label class="control-label" for="answer">Confirm Answer</label>
					<div class="controls">
						<input type="text" class="input-xlarge" id="answerConfirm" name="answerConfirm">
						<span class="help-inline" id="answerConfirmHelp"></span>
					</div>
				</div>
				
				<div class="form-actions">
					<button value="submit" type="submit" class="btn btn-primary">Submit</button>
					<button class="btn" value="Reload Page" onClick="document.location.reload(true)">Cancel</button>
				</div>
			</fieldset>
			</form>
			</div>
			
			<div class="tab-pane fade" id="ChangeViewMode">
                <form class="form-horizontal" name="userChangeView" id="userChangeView" onsubmit="" action="UpdateViewBE.php" method="post">
			<fieldset>
			<div class="control-group" id="userTypeGroup">
					<label class="control-label" for="userType">User Type</label>
					<div class="controls">
						<select id="viewType" name="viewType"><!--TODO: Add js to give warning if swiching to advanced mode -->
							<option>Basic</option>
							<option>Advanced</option>
						</select>
					</div>
				</div>
				<div class="form-actions">
					<button value="submit" type="submit" class="btn btn-primary">Submit</button>
					<button class="btn" value="Reload Page" onClick="document.location.reload(true)">Cancel</button>
				</div>
			</fieldset>
		</form>
		</div>
	</div>
</div>
</body>
</html>
			
		