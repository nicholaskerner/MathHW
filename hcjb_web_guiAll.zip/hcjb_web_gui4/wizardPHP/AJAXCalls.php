<?php

session_start();
include('../config.php');
include('../lib/writerParserValidator.php');
include('../lib/setActive.php');
	//Connect to the database
	$dbhandle = mysql_connect($hostname, $username, $password)
		or die("Unable to connect to MySQL");

	//Select the database
	$selected = mysql_select_db($databaseName,$dbhandle)
		or die("Could not select examples");
		
	

  if($_GET["ToDo"] == "loadFile"){
	 getFileContents($_GET["FileID"]);
  }
  elseif($_GET["ToDo"]== "liveAudio"){
	getLiveAudio();	
  }
  elseif($_GET["ToDo"]== "autoSave"){
	loadAutoSave($_GET["FileID"], 0);	
  }
  elseif($_GET["ToDo"]== "save"){
	loadSave($_GET["FileID"]);	
  }
  elseif($_GET["ToDo"]== "activate"){
	loadSave($_GET["FileID"]);	
  }
  elseif($_GET["ToDo"] == "loadActive"){
	 getFileContents($_GET["FileID"]);
  }
  else{
	$a = array("Status ","failed");
	echo  json_encode($a);
	die("He's Dead Jim");
	
  }
 
function loadSave($FileID){
	loadAutoSave($FileID, 1);
	$result = mysql_query("SELECT  `FileName` FROM  `AutoSave` WHERE FileID = \"".$FileID."\"");
	$row = mysql_fetch_array($result);
	try{
		write($row["FileName"]);
		echo json_encode(array("Status","WroteFile"));
	}
	catch(Exception $e){
		echo json_encode(array("Status ",$e->getMessage()));
	}
		

} 


function activateFile($FileID){
	loadSave($FileID);
	 $temp = setActive($FileID);
	if($temp){
		echo json_encode(array("Status","activated"));
	}
	else{
		echo json_encode(array("Status","failed"));
	}
}
 
 function loadAutoSave($FileID, $IsRealFile){
	
	
	
	$ConfDesc=$_GET["ConfigurationDesc"];
	$Robustness=$_GET["Robustness"];
	$SpectrumOcc=$_GET["SpectrumOcc"];
	$InterleaverDepth=$_GET["InterleaverDepth"];
	$MSCMode=$_GET["MSCMode"];
	$SDCMode=$_GET["SDCMode"];
	$BaseEnhancementFlag=$_GET["BaseEnhancementFlag"];
	$ProtAInt=$_GET["ProtAInt"];
	$ProtBInt=$_GET["ProtBInt"];
	$ProtLevelForHierarchical=$_GET["ProtLevelForHierarchical"];
	$HierarchicalBytes=$_GET["HierarchicalBytes"];
	$AmDrm=$_GET["AmDrm"];
	$S0DataLengthA=$_GET["S0DataLengthA"];
	$S0DataLengthB=$_GET["S0DataLengthB"];
	$S0ServiceLabel=$_GET["S0ServiceLabel"];
	$S0ServiceID=$_GET["S0ServiceID"];
	$S0CASystemUsed=$_GET["S0CASystemUsed"];
	$S0LanguageInt=$_GET["S0LanguageInt"];
	$S0LanguageCode=$_GET["S0LanguageCode"];
	$S0CountryCode=$_GET["S0CountryCode"];
	$S0AudioDataFlag=$_GET["S0AudioDataFlag"];
	$S0ServiceDesc=$_GET["S0ServiceDesc"];
	$S0StreamID=$_GET["S0StreamID"];
	$S0AudioCodec=$_GET["S0AudioCodec"];
	$S0SBRFlag=$_GET["S0SBRFlag"];
	$S0AudioMode=$_GET["S0AudioMode"];
	$S0AudioSamplingRate=$_GET["S0AudioSamplingRate"];
	$S0TextFlag=$_GET["S0TextFlag"];
	$S0EnhancementFlag=$_GET["S0EnhancementFlag"];
	$S0Source=$_GET["S0Source"];
	$S0AudioFileName=$_GET["S0AudioFileName"];
	$S0RepeatAudio=$_GET["S0RepeatAudio"];
	$S0CoderField=$_GET["S0CoderField"];
	$S1DataLengthA=$_GET["S1DataLengthA"];
	$S1DataLengthB=$_GET["S1DataLengthB"];
	$S1ServiceLabel=$_GET["S1ServiceLabel"];
	$S1ServiceID=$_GET["S1ServiceID"];
	$S1CASystemUsed=$_GET["S1CASystemUsed"];
	$S1LanguageInt=$_GET["S1LanguageInt"];
	$S1LanguageCode=$_GET["S1LanguageCode"];
	$S1CountryCode=$_GET["S1CountryCode"];
	$S1AudioDataFlag=$_GET["S1AudioDataFlag"];
	$S1ServiceDesc=$_GET["S1ServiceDesc"];
	$S1StreamID=$_GET["S1StreamID"];
	$S1AudioCodec=$_GET["S1AudioCodec"];
	$S1SBRFlag=$_GET["S1SBRFlag"];
	$S1AudioMode=$_GET["S1AudioMode"];
	$S1AudioSamplingRate=$_GET["S1AudioSamplingRate"];
	$S1TextFlag=$_GET["S1TextFlag"];
	$S1EnhancementFlag=$_GET["S1EnhancementFlag"];
	$S1Source=$_GET["S1Source"];
	$S1AudioFileName=$_GET["S1AudioFileName"];
	$S1RepeatAudio=$_GET["S1RepeatAudio"];
	$S1CoderField=$_GET["S1CoderField"];
	$S2DataLengthA=$_GET["S2DataLengthA"];
	$S2DataLengthB=$_GET["S2DataLengthB"];
	$S2ServiceLabel=$_GET["S2ServiceLabel"];
	$S2ServiceID=$_GET["S2ServiceID"];
	$S2CASystemUsed=$_GET["S2CASystemUsed"];
	$S2LanguageInt=$_GET["S2LanguageInt"];
	$S2LanguageCode=$_GET["S2LanguageCode"];
	$S2CountryCode=$_GET["S2CountryCode"];
	$S2AudioDataFlag=$_GET["S2AudioDataFlag"];
	$S2ServiceDesc=$_GET["S2ServiceDesc"];
	$S2StreamID=$_GET["S2StreamID"];
	$S2AudioCodec=$_GET["S2AudioCodec"];
	$S2SBRFlag=$_GET["S2SBRFlag"];
	$S2AudioMode=$_GET["S2AudioMode"];
	$S2AudioSamplingRate=$_GET["S2AudioSamplingRate"];
	$S2TextFlag=$_GET["S2TextFlag"];
	$S2EnhancementFlag=$_GET["S2EnhancementFlag"];
	$S2Source=$_GET["S2Source"];
	$S2AudioFileName=$_GET["S2AudioFileName"];
	$S2RepeatAudio=$_GET["S2RepeatAudio"];
	$S2CoderField=$_GET["S2CoderField"];
	$S3DataLengthA=$_GET["S3DataLengthA"];
	$S3DataLengthB=$_GET["S3DataLengthB"];
	$S3ServiceLabel=$_GET["S3ServiceLabel"];
	$S3ServiceID=$_GET["S3ServiceID"];
	$S3CASystemUsed=$_GET["S3CASystemUsed"];
	$S3LanguageInt=$_GET["S3LanguageInt"];
	$S3LanguageCode=$_GET["S3LanguageCode"];
	$S3CountryCode=$_GET["S3CountryCode"];
	$S3AudioDataFlag=$_GET["S3AudioDataFlag"];
	$S3ServiceDesc=$_GET["S3ServiceDesc"];
	$S3StreamID=$_GET["S3StreamID"];
	$S3AudioCodec=$_GET["S3AudioCodec"];
	$S3SBRFlag=$_GET["S3SBRFlag"];
	$S3AudioMode=$_GET["S3AudioMode"];
	$S3AudioSamplingRate=$_GET["S3AudioSamplingRate"];
	$S3TextFlag=$_GET["S3TextFlag"];
	$S3EnhancementFlag=$_GET["S3EnhancementFlag"];
	$S3Source=$_GET["S3Source"];
	$S3AudioFileName=$_GET["S3AudioFileName"];
	$S3RepeatAudio=$_GET["S3RepeatAudio"];
	$S3CoderField=$_GET["S3CoderField"];
	$IPEnabled=$_GET["IPEnabled"];
	$IPAddress=$_GET["IPAddress"];
	$IPPort=$_GET["IPPort"];
	$IP_TCP_UDP=$_GET["IP_TCP_UDP"];
	$FEEnabled=$_GET["FEEnabled"];
	$FFFileName=$_GET["FFFileName"];
	$PFTEnabled=$_GET["PFTEnabled"];
	$PFTPayloadMtu=$_GET["PFTPayloadMtu"];
	$PFTProtection=$_GET["PFTProtection"];
	$PFTStrength=$_GET["PFTStrength"];
	$PFTTransportation=$_GET["PFTTransportation"];
	$PFTSource=$_GET["PFTSource"];
	$PFTDestination=$_GET["PFTDestination"];
	$Display=$_GET["Display"];
	$VUMeter=$_GET["VUMeter"];
	$Timing=$_GET["Timing"];
	$Clocktime=$_GET["Clocktime"];
	
	mysql_query("UPDATE AutoSave SET ConfigurationDesc='$ConfDesc', SpectrumOcc='$SpectrumOcc', Robustness='$Robustness', InterleaverDepth='$InterleaverDepth', MSCMode='$MSCMode', SDCMode='$SDCMode', BaseEnhancementFlag='$BaseEnhancementFlag', ProtAInt='$ProtAInt', ProtBInt='$ProtBInt', ProtHInt='$ProtLevelForHierarchical', HierarchicalBytes='$HierarchicalBytes', AmDRM='$AmDRM', S0DataLengthA='$S0DataLengthA', S0DataLengthB='$S0DataLengthB', S0ServiceLabel='$S0ServiceLabel', S0ServiceID='$S0ServiceID', S0CASystemUsed='$S0CASystemUsed', S0LanguageInt='$S0LanguageInt', S0LanguageCode='$S0LanguageCode', S0CountryInt='$S0CountryInt', S0CountryCode='$S0CountryCode', S0AudioDataFlag='$S0AudioDataFlag', S0ServiceDesc='$S0ServiceDesc', S0StreamID='$S0StreamID',  S0AudioCodec='$S0AudioCodec', S0SBRFlag='$S0SBRFlag', S0AudioMode='$S0AudioMode', S0AudioSamplingRate='$S0AudioSamplingRate', S0TextFlag='$S0TextFlag', S0EnhancementFlag='$S0EnhancementFlag', S0Source='$S0Source', S0AudioFileName='$S0AudioFileName', S0RepeatAudio='$S0RepeatAudio', S0CoderField='$S0CoderField', S1DataLengthA='$S1DataLengthA', S1DataLengthB='$S1DataLengthB', S1ServiceLabel='$S1ServiceLabel', S1ServiceID='$S1ServiceID', S1CASystemUsed='$S1CASystemUsed', S1LanguageInt='$S1LanguageInt', S1LanguageCode='$S1LanguageCode', S1CountryInt='$S1CountryInt', S1CountryCode='$S1CountryCode', S1AudioDataFlag='$S1AudioDataFlag', S1ServiceDesc='$S1ServiceDesc', S1StreamID='$S1StreamID', S1AudioCodec='$S1AudioCodec', S1SBRFlag='$S1SBRFlag', S1AudioMode='$S1AudioMode', S1AudioSamplingRate='$S1AudioSamplingRate', S1TextFlag='$S1TextFlag', S1EnhancementFlag='$S1EnhancementFlag', S1Source='$S1Source', S1AudioFileName='$S1AudioFileName', S1RepeatAudio='$S1RepeatAudio',S1CoderField='$S1CoderField', S2DataLengthA='$S2DataLengthA', S2DataLengthB='$S2DataLengthB', S2ServiceLabel='$S2ServiceLabel', S2ServiceID='$S2ServiceID', S2CASystemUsed='$S2CASystemUsed', S2LanguageInt='$S2LanguageInt', S2LanguageCode='$S2LanguageCode', S2CountryInt='$S2CountryInt',  S2CountryCode='$S2CountryCode',S2AudioDataFlag='$S2AudioDataFlag',S2ServiceDesc='$S2ServiceDesc', S2StreamID='$S2StreamID', S2AudioCodec='$S2AudioCodec', S2SBRFlag='$S2SBRFlag', S2AudioMode='$S2AudioMode', S2AudioSamplingRate='$S2AudioSamplingRate', S2TextFlag='$S2TextFlag', S2EnhancmentFlag='$S2EnhancmentFlag', S2Source='$S2Source', S2AudioFileName='$S2AudioFileName', S2RepeatAudio='$S2RepeatAudio', S2CoderField='$S2CoderField', S3DataLengthA='$S3DataLengthA', S3DataLengthB='$S3DataLengthB', S3ServiceLabel='$S3ServiceLabel', S3ServiceID='$S3ServiceID', S3CASystemUsed='$S3CASystemUsed', S3LanguageInt='$S3LanguageInt', S3LanguageCode='$S3LanguageCode', S3CountryID='$S3CountryID', S3CountryCode='$S3CountryCode', S3AudioDataFlag='$S3AudioDataFlag', S3ServiceDesc='$S3ServiceDesc', S3StreamID='$S3StreamID', S3AudioCodec='$S3AudioCodec', S3SBRFlag='$S3SBRFlag', S3AudioMode='$S3AudioMode', S3AudioSamplingRate='$S3AudioSamplingRate', S3TextFlag='$S3TextFlag', S3EnhancementFlag='$S3EnhancementFlag', S3Source='$S3Source', S3AudioFileName='$S3AudioFileName', S3RepeatAudio='$S3RepeatAudio', S3CoderField='$S3CoderField', IPEnabled='$IPEnabled', IPAddress='$IPAddress', IPPort='$IPPort', IP_TCP_UDP='$IP_TCP_UDP', FEEnabled='$FEEnabled', FFFileName='$FFFileName', PFTEnabled='$PFTEnabled', PFTPayloadMtu='$PFTPayloadMtu', PFTProtection='$PFTProtection', PFTStrength='$PFTStrength', PFTTransportation='$PFTTransportation', PFTSource='$PFTSource', PFTDestination='$PFTDestination', VUMeter='$VUMeter', Timing='$Timing', Clocktime='$Clocktime', IsRealFile='$IsRealFile' WHERE FileID='$FileID'")
	or die ("He's dead Jim");
	
	
 
 
 
 
 
 
 }
 
 
  function getLiveAudio(){
	$result = mysql_query("SELECT * FROM `LiveAudio`");
  
	$row = mysql_fetch_array($result);
	
	echo"{";
	echo "\"LiveAudioInputs\": [";
	while($row!= false){
		echo "{ \"inputName\":", json_encode($row["Name"]), "}";
		
		$row = mysql_fetch_array($result);
		if($row!=false){
		echo", \n";	
		}
	
	}
	echo"]";
	echo"}";
	
  
  }
  
  function getFileContents($FileID){
	//Execute the query, gathering all data from the database
	$result = mysql_query("SELECT * FROM `AutoSave` WHERE FileID = \"".$FileID."\"");

	$row = mysql_fetch_array($result);

	echo"{";
	echo "\"ConfigurationDesc\": ", json_encode($row["ConfigurationDesc"]), ",\n";
	echo "\"Robustness\": ", json_encode($row["Robustness"]), ",\n";
	echo "\"SpectrumOcc\": ", json_encode($row["SpectrumOcc"]), ",\n";
	echo "\"InterleaverDepth\": ", json_encode($row["InterleaverDepth"]), ",\n";
	echo "\"MSCMode\": ", json_encode($row["MSCMode"]), ",\n";
	echo "\"SDCMode\": ", json_encode($row["SDCMode"]), ",\n";
	echo "\"BaseEnhancementFlag\": ", json_encode($row["BaseEnhancementFlag"]), ",\n";
	echo "\"ProtAInt\": ", json_encode($row["ProtAInt"]), ",\n";
	echo "\"ProtBInt\": ", json_encode($row["ProtBInt"]), ",\n";
	echo "\"ProtLevelForHierarchical\": ", json_encode($row["ProtHInt"]), ",\n";
	echo "\"HierarchicalBytes\": ", json_encode($row["HierarchicalBytes"]), ",\n";
	echo "\"AmDrm\": ", json_encode($row["AmDRM"]), ",\n";
	echo "\"S0DataLengthA\": ", json_encode($row["S0DataLengthA"]), ",\n";
	echo "\"S0DataLengthB\": ", json_encode($row["S0DataLengthB"]), ",\n";
	echo "\"S0ServiceLabel\": ", json_encode($row["S0ServiceLabel"]), ",\n";
	echo "\"S0ServiceID\": ", json_encode($row["S0ServiceID"]), ",\n";
	echo "\"S0CASystemUsed\": ", json_encode($row["S0CASystemUsed"]), ",\n";
	echo "\"S0LanguageInt\": ", json_encode($row["S0LanguageInt"]), ",\n";
	echo "\"S0LanguageCode\": ", json_encode($row["S0LanguageCode"]), ",\n";
	echo "\"S0CountryCode\": ", json_encode($row["S0CountryCode"]), ",\n";	
	echo "\"S0AudioDataFlag\": ", json_encode($row["S0AudioDataFlag"]), ",\n";	
	echo "\"S0ServiceDesc\": ", json_encode($row["S0ServiceDesc"]), ",\n";		
	echo "\"S0StreamID\": ", json_encode($row["S0StreamID"]), ",\n";
	echo "\"S0AudioCodec\": ", json_encode($row["S0AudioCodec"]), ",\n";
	echo "\"S0SBRFlag\": ", json_encode($row["S0SBRFlag"]), ",\n";	
	echo "\"S0AudioMode\": ", json_encode($row["S0AudioMode"]), ",\n";	
	echo "\"S0AudioSamplingRate\": ", json_encode($row["S0AudioSamplingRate"]), ",\n";	
	echo "\"S0TextFlag\": ", json_encode($row["S0TextFlag"]), ",\n";
	echo "\"S0EnhancementFlag\": ", json_encode($row["S0EnhancementFlag"]), ",\n";		
	echo "\"S0Source\": ", json_encode($row["S0Source"]), ",\n";	
	echo "\"S0AudioFileName\": ", json_encode($row["S0AudioFileName"]), ",\n";
	echo "\"S0RepeatAudio\": ", json_encode($row["S0RepeatAudio"]), ",\n";
	echo "\"S0CoderField\": ", json_encode($row["S0CoderField"]), ",\n";
	echo "\"S1DataLengthA\": ", json_encode($row["S1DataLengthA"]), ",\n";
	echo "\"S1DataLengthB\": ", json_encode($row["S1DataLengthB"]), ",\n";
	echo "\"S1ServiceLabel\": ", json_encode($row["S1ServiceLabel"]), ",\n";
	echo "\"S1ServiceID\": ", json_encode($row["S1ServiceID"]), ",\n";
	echo "\"S1CASystemUsed\": ", json_encode($row["S1CASystemUsed"]), ",\n";
	echo "\"S1LanguageInt\": ", json_encode($row["S1LanguageInt"]), ",\n";
	echo "\"S1LanguageCode\": ", json_encode($row["S1LanguageCode"]), ",\n";
	echo "\"S1CountryCode\": ", json_encode($row["S1CountryCode"]), ",\n";	
	echo "\"S1AudioDataFlag\": ", json_encode($row["S1AudioDataFlag"]), ",\n";	
	echo "\"S1ServiceDesc\": ", json_encode($row["S1ServiceDesc"]), ",\n";		
	echo "\"S1StreamID\": ", json_encode($row["S1StreamID"]), ",\n";
	echo "\"S1AudioCodec\": ", json_encode($row["S1AudioCodec"]), ",\n";
	echo "\"S1SBRFlag\": ", json_encode($row["S1SBRFlag"]), ",\n";	
	echo "\"S1AudioMode\": ", json_encode($row["S1AudioMode"]), ",\n";	
	echo "\"S1AudioSamplingRate\": ", json_encode($row["S1AudioSamplingRate"]), ",\n";	
	echo "\"S1TextFlag\": ", json_encode($row["S1TextFlag"]), ",\n";
	echo "\"S1EnhancementFlag\": ", json_encode($row["S1EnhancementFlag"]), ",\n";		
	echo "\"S1Source\": ", json_encode($row["S1Source"]), ",\n";	
	echo "\"S1AudioFileName\": ", json_encode($row["S1AudioFileName"]), ",\n";
	echo "\"S1RepeatAudio\": ", json_encode($row["S1RepeatAudio"]), ",\n";
	echo "\"S1CoderField\": ", json_encode($row["S1CoderField"]), ",\n";				
	echo "\"S2DataLengthA\": ", json_encode($row["S2DataLengthA"]), ",\n";
	echo "\"S2DataLengthB\": ", json_encode($row["S2DataLengthB"]), ",\n";
	echo "\"S2ServiceLabel\": ", json_encode($row["S2ServiceLabel"]), ",\n";
	echo "\"S2ServiceID\": ", json_encode($row["S2ServiceID"]), ",\n";
	echo "\"S2CASystemUsed\": ", json_encode($row["S2CASystemUsed"]), ",\n";
	echo "\"S2LanguageInt\": ", json_encode($row["S2LanguageInt"]), ",\n";
	echo "\"S2LanguageCode\": ", json_encode($row["S2LanguageCode"]), ",\n";
	echo "\"S2CountryCode\": ", json_encode($row["S2CountryCode"]), ",\n";	
	echo "\"S2AudioDataFlag\": ", json_encode($row["S2AudioDataFlag"]), ",\n";	
	echo "\"S2ServiceDesc\": ", json_encode($row["S2ServiceDesc"]), ",\n";		
	echo "\"S2StreamID\": ", json_encode($row["S2StreamID"]), ",\n";
	echo "\"S2AudioCodec\": ", json_encode($row["S2AudioCodec"]), ",\n";
	echo "\"S2SBRFlag\": ", json_encode($row["S2SBRFlag"]), ",\n";	
	echo "\"S2AudioMode\": ", json_encode($row["S2AudioMode"]), ",\n";	
	echo "\"S2AudioSamplingRate\": ", json_encode($row["S2AudioSamplingRate"]), ",\n";	
	echo "\"S2TextFlag\": ", json_encode($row["S2TextFlag"]), ",\n";
	echo "\"S2EnhancementFlag\": ", json_encode($row["S2EnhancementFlag"]), ",\n";		
	echo "\"S2Source\": ", json_encode($row["S2Source"]), ",\n";	
	echo "\"S2AudioFileName\": ", json_encode($row["S2AudioFileName"]), ",\n";
	echo "\"S2RepeatAudio\": ", json_encode($row["S2RepeatAudio"]), ",\n";
	echo "\"S2CoderField\": ", json_encode($row["S2CoderField"]), ",\n";
	echo "\"S3DataLengthA\": ", json_encode($row["S3DataLengthA"]), ",\n";
	echo "\"S3DataLengthB\": ", json_encode($row["S3DataLengthB"]), ",\n";
	echo "\"S3ServiceLabel\": ", json_encode($row["S3ServiceLabel"]), ",\n";
	echo "\"S3ServiceID\": ", json_encode($row["S3ServiceID"]), ",\n";
	echo "\"S3CASystemUsed\": ", json_encode($row["S3CASystemUsed"]), ",\n";
	echo "\"S3LanguageInt\": ", json_encode($row["S3LanguageInt"]), ",\n";
	echo "\"S3LanguageCode\": ", json_encode($row["S3LanguageCode"]), ",\n";
	echo "\"S3CountryCode\": ", json_encode($row["S3CountryCode"]), ",\n";	
	echo "\"S3AudioDataFlag\": ", json_encode($row["S3AudioDataFlag"]), ",\n";	
	echo "\"S3ServiceDesc\": ", json_encode($row["S3ServiceDesc"]), ",\n";		
	echo "\"S3StreamID\": ", json_encode($row["S3StreamID"]), ",\n";
	echo "\"S3AudioCodec\": ", json_encode($row["S3AudioCodec"]), ",\n";
	echo "\"S3SBRFlag\": ", json_encode($row["S3SBRFlag"]), ",\n";	
	echo "\"S3AudioMode\": ", json_encode($row["S3AudioMode"]), ",\n";	
	echo "\"S3AudioSamplingRate\": ", json_encode($row["S3AudioSamplingRate"]), ",\n";	
	echo "\"S3TextFlag\": ", json_encode($row["S3TextFlag"]), ",\n";
	echo "\"S3EnhancementFlag\": ", json_encode($row["S3EnhancementFlag"]), ",\n";		
	echo "\"S3Source\": ", json_encode($row["S3Source"]), ",\n";	
	echo "\"S3AudioFileName\": ", json_encode($row["S3AudioFileName"]), ",\n";
	echo "\"S3RepeatAudio\": ", json_encode($row["S3RepeatAudio"]), ",\n";
	echo "\"S3CoderField\": ", json_encode($row["S3CoderField"]), ",\n";	
	echo "\"IPEnabled\": ", json_encode($row["IPEnabled"]), ",\n";	
	echo "\"IPAddress\": ", json_encode($row["IPAddress"]), ",\n";		
	echo "\"IPPort\": ", json_encode($row["IPPort"]), ",\n";	
	echo "\"IP_TCP_UDP\": ", json_encode($row["IP_TCP_UDP"]), ",\n";
	echo "\"FEEnabled\": ", json_encode($row["FEEnabled"]), ",\n";
	echo "\"FFFileName\": ", json_encode($row["FFFileName"]), ",\n";
	echo "\"PFTEnabled\": ", json_encode($row["PFTEnabled"]), ",\n";
	echo "\"PFTPayloadMtu\": ", json_encode($row["PFTPayloadMtu"]), ",\n";
	echo "\"PFTProtection\": ", json_encode($row["PFTProtection"]), ",\n";
	echo "\"PFTStrength\": ", json_encode($row["PFTStrength"]), ",\n";
	echo "\"PFTTransportation\": ", json_encode($row["PFTTransportation"]), ",\n";
	echo "\"PFTSource\": ", json_encode($row["PFTSource"]), ",\n";
	echo "\"PFTDestination\": ", json_encode($row["PFTDestination"]), ",\n";
	echo "\"Display\": ", json_encode($row["Display"]), ",\n";
	echo "\"VUMeter\": ", json_encode($row["VUMeter"]), ",\n";
	echo "\"Timing\": ", json_encode($row["Timing"]), ",\n";
	echo "\"Clocktime\": ", json_encode($row["Clocktime"]), "\n";
	echo "}";
  
  
  
  }

?>
