


	<div class="span12"> 
							<div class="page-header">
								<h5 class="span4">Select Number of Services :</h5>
							
								<select class="span3 inline" id="servicesSelect" onchange="servicesToDisplay()">
									<option value=""></option>
									<option value="1"> 1 </option>
									<option value="2"> 2 </option>
									<option value="3"> 3 </option>
									<option value="4"> 4 </option>
							
							
								</select>
								
							</div>
							
							<div class="page-header" id="stream0" style="display: none;">
								<h4> Stream 0: </h4>
								<br>
								<div class="tabbable tabs-left">
								  <ul class="nav nav-tabs">
									<li class="active"><a  href="#tab301" data-toggle="tab" ><i class="icon-tags"></i> Service Identification </a></li>
									<li><a href="#tab302" data-toggle="tab" ><i class="icon-screenshot"></i> Protection Levels </a></li>
									<li><a href="#tab303" data-toggle="tab" ><i class="icon-group"></i> Language & Service Type </a></li>
									<li><a href="#tab304" data-toggle="tab" ><i class="icon-play-circle"></i> Audio Settings </a></li>
									<!--<li><a href="#tab205" data-toggle="tab" ><i class="icon-check"></i> CA System Used </a></li>-->
									<!--<li><a href="#tab206" data-toggle="tab" ><i class="icon-tasks"></i> Media Type </a></li>-->									
									<li><a href="#tab307" data-toggle="tab" ><i class="icon-flag"></i> Flags </a></li>								
									
								  </ul>
								  </ul>
								  
								  <div class="tab-content">
										<div class="tab-pane active" id="tab301">
											<form class="form">
												<div class="control-group page-header">
													<label class="control-label" for="S0ServiceLabel"><b>Service Label</b></label>
													<div class="controls">
													  <input type="text" placeholder="Service Label" id="S0ServiceLabel">
													  <span class="help-block">Name displayed for the service.</span>
													</div>
												 </div>
												 
												<div class="control-group">
													<label class="control-label" for="S0ServiceID"><b>Service Identifier</b></label>
													<div class="controls">
													  <input type="text" placeholder="Service Identifier" id="S0ServiceID"> 
													  <span class="help-block">Unique ID, which is a whole number.</span>
													</div>
												 </div> 
											</form>	 
										</div>
										
										<div class="tab-pane" id="tab302">
											<form class="form-inline">

												<input type="text" placeholder="Stream 0 Part A"> 
												<input type="text" placeholder="Stream 0 Part B"> 
												<span class="help-block">SDFSDGF</span>
													
											</form>	 
										</div>
										
										<div class="tab-pane" id="tab303">
											<div class="page-header">
												<b> Service Descriptor </b>
												<br>
												<select>

												  <option>0 None Selected</option>
												  <option>1 No Program Type</option>
												  <option>2 News</option>
												  <option>3 Current Affairs</option>
												  <option>4 Information</option>
												  <option>5 Sport</option>
												  <option>6 Education</option>
												  <option>7 Drama</option>
												  <option>8 Culture</option>
												  <option>9 Science</option>
												  <option>10 Varied</option>
												  <option>11 Pop Music</option>
												  <option>12 Rock Music</option>
												  <option>13 Easy Listening</option>
												  <option>14 Light Classical</option>
												  <option>15 Serious Classical</option>
												  <option>16 Other music</option>
												  <option>17 Weather</option>
												  <option>18 Finance</option>
												  <option>19 Childrens</option>
												  <option>20 Social Affairs</option>
												  <option>21 Religion</option>
												  <option>22 Phone in</option>
												  <option>23 Travel</option>
												  <option>24 Leisure</option>
												  <option>25 Jazz Music</option>
												  <option>26 Country Music</option>
												  <option>27 National Music</option>
												  <option>28 Oldies Music</option>
												  <option>29 Folk Music</option>
												  <option>30 Documentery</option>
												  
								
												</select>
											</div>
											<br>
											<b> Language </b>
											<br>
											<select>
											  <option>0 None Selected</option>
											  <option>0 None Sepecified</option>
											  <option>1 Arabic</option>ara
											  <option>2 Bengali</option>ben
											  <option>3 Chinese (Mand.)</option>chi
											  <option>4 Dutch</option>dum
											  <option>5 English</option>eng
											  <option>6 French</option>fre
											  <option>7 German</option>ger
											  <option>8 Hindi</option>hin
											  <option>9 Japanese</option>jpn
											  <option>10 Javanese</option>jav
											  <option>11 Korean</option>kor
											  <option>12 Portugese</option>por
											  <option>13 Russian</option>rus
											  <option>14 Spanish</option>spa
											  <option>15 Other music</option>
											</select> 
										</div>
										
										<div class="tab-pane row-fluid" id="tab304">
											<div class="page-header">
												
												<b> Audio Mode </b>
												<br>
												<label class="radio inline">
													<input type="radio" name="S0AudioMode" id="S0optionAudM1" value="option1">
													Mono
												</label>
												<label class="radio inline">
													<input type="radio" name="S0AudioMode" id="S0optionAudM2" value="option2">
													Parem Stereo
												</label>
												<label class="radio inline">
													<input type="radio" name="S0AudioMode" id="S0optionAudM3" value="option3">
													Stereo
												</label>
											</div>
											<div class="page-header">
												<b> Audio Sampling </b>
												<br>
												<label class="radio inline">
													<input type="radio" name="S0AudioSampling" id="S0optionAudS1" value="option1">
													8 kHz
												</label>
												<label class="radio inline">
													<input type="radio" name="S0AudioSampling" id="S0optionAudS2" value="option2">
													12 kHz
												</label>
												<label class="radio inline">
													<input type="radio" name="S0AudioSampling" id="S0optionAudS3" value="option3">
													16 kHz
												</label>
												<label class="radio inline">
													<input type="radio" name="S0AudioSampling" id="S0optionAudS4" value="option1">
													24 kHz
												</label>
											</div>
											<div class="">
												 <b> Auido Coding </b>
												 <br>
													<label class="radio inline">
														<input type="radio" name="S0AudioCoding" id="S0optionAC1" value="option1">
														MPEG ACC
													</label>
													<label class="radio inline">
														<input type="radio" name="S0AudioCoding" id="S0optionAC2" value="option2">
														CELP
													</label>
													<label class="radio inline">
														<input type="radio" name="S0AudioCoding" id="S0optionAC3" value="option3">
														HVXC
													</label>
											</div>
										</div>
										
										<div class="tab-pane row-fluid" id="tab305">
											<b> CA System Used </b>
											<br>
											<label class="radio inline">
												<input type="radio" name="S0CAUsed" id="S0optionCA1" value="option1">
												Yes
											</label>
											<label class="radio inline">
												<input type="radio" name="S0CAUsed" id="S0optionCA2" value="option2">
												No
											</label>
										</div>
										
										<div class="tab-pane row-fluid" id="tab306">
											<b> Audio/Data </b>
											<br>
											<label class="radio inline">
												<input type="radio" name="S0AudioData" id="S0optionAD1" value="option1">
												Audio
											</label>
											<label class="radio inline">
												<input type="radio" name="S0AudioData" id="S0optionAD2" value="option2">
												Data
											</label>
											<label class="radio inline">
												<input type="radio" name="S0AudioData" id="S0optionAD3" value="option3">
												None
											</label>
										</div>
										
										<div class="tab-pane row-fluid" id="tab307">
											<!--<div class="page-header">
												<b> Enhancement Flag </b>
												<br>
												<label class="radio inline">
													<input type="radio" name="S0EFlag" id="S0optionEF1" value="option1">
													Yes
												</label>
												<label class="radio inline">
													<input type="radio" name="S0EFlag" id="S0optionEF2" value="option2">
													No
												</label>
											</div>-->
											<b> SBR Flag </b>
											<br>
											<label class="radio inline">
												<input type="radio" name="S0SBR" id="S0optionSBR1" value="option1">
												Yes
											</label>
											<label class="radio inline">
												<input type="radio" name="S0SBR" id="S0optionSBR2" value="option2">
												No
											</label>
										</div>
									
								  </div>
								</div>
								
								
								
								
								
								
							
								
								
							
							</div>
							<div class="page-header" id="stream1" style="display: none;">
								<h4> Stream 1: </h4>
								
								
								
								
								
																
							
								
								
							
							</div>	
						  </div>













?>