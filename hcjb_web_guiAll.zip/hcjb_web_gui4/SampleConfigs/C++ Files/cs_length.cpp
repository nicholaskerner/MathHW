// vim:set tabstop=4 shiftwidth=4:
// Section and table references updated for ETSI ES 201 980 V3.2.1 (2012-06)

#include <math.h> // for ceil() and floor()
#include "cs_length.h"

// spectrum_occupancy  0	   1	   2	   3	   4	   5	from 7.7 Tables 76-79, line 3
int Nmux[4][6]	= {{1259,	1422,	2632,	2959,	5464,	6118},	// Mode A
				   { 966,	1110,	2051,	2337,	4249,	4774},	// Mode B
				   {   0,	   0,	   0,	1844,	   0,	3867},	// Mode C
				   {   0,	   0,	   0,	1226,	   0,	2606}};	// Mode D

// Code rate numerators
int RX[4][4][3][2] = // [64QAM SM=0, HMMix(HonI)=1, HMSym(HonIQ)=2, 16QAM SM=3][Code Rate Idx=0->3]
// [RX0->2][Real or Imaginary]
	// 64QAM SM (Ref: Section 7.5.1.1 Table 67)
	{{{{1, 0}, {1, 0}, {3, 0}},	// Code Rate Idx 0 RX 0->2, Reals, (Imag = 0)
	  {{1, 0}, {2, 0}, {4, 0}},	//				 1
	  {{1, 0}, {3, 0}, {7, 0}},	//				 2
	  {{2, 0}, {4, 0}, {8, 0}}},//				 3
	// 64QAM HMMix (Hierarchical on I) (Ref: Section 7.5.1.2 Table 69 and Section 7.5.1.3 Table 70)
	 {{{1, 1}, {3, 1}, {3, 3}},	// Code Rate Idx 0 RX 0->2, {Real, Imag}
	  {{4, 1}, {4, 2}, {8, 4}},	//				 1
	  {{3, 1}, {4, 3}, {7, 7}},	//				 2
	  {{2, 2}, {2, 4}, {8, 8}}},//				 3
	// 64QAM HMSym (Hierarchical on I and Q) (Ref: Section 7.5.1.2 Tables 68 and 69)
	 {{{1, 0}, {3, 0}, {3, 0}},	// Code Rate Idx 0 RX 0->2, Reals, (Imag = 0, RX0 = VSPP)
	  {{4, 0}, {4, 0}, {8, 0}},	//				 1
	  {{3, 0}, {4, 0}, {7, 0}},	//				 2
	  {{2, 0}, {2, 0}, {8, 0}}},//				 3
	// 16QAM SM (Ref: Section 7.5.1.1 Table 65)
	 {{{1, 0}, {2, 0}, {0, 0}},	// Code Rate Idx 0 RX 0->1, Reals, (Imag = 0, RX2 = 0)
	  {{1, 0}, {3, 0}, {0, 0}},	//				 1
	  {{0, 0}, {0, 0}, {0, 0}},	//(Code Rate Idx 2 = 0)
	  {{0, 0}, {0, 0}, {0, 0}}}};//(Code Rate Idx 3 = 0)

// Code rate denominators
int RY[4][4][3][2] = // [64QAM SM=0, HMMix(HonI)=1, HMSym(HonIQ)=2, 16QAM SM=3][Code Rate Idx=0->3]
// [RY0->2][Real or Imaginary]
	// 64QAM SM (Ref: Section 7.5.1.1 Table 67)
	{{{{4, 0}, {2, 0}, {4, 0}},	// Code Rate Idx 0 RY 0->2, Reals, (Imag = 0)
	  {{3, 0}, {3, 0}, {5, 0}},	//				 1
	  {{2, 0}, {4, 0}, {8, 0}},	//				 2
	  {{3, 0}, {5, 0}, {9, 0}}},//				 3
	// 64QAM HMMix (Hierarchical on I) (Ref: Section 7.5.1.2 Table 69 and Section 7.5.1.3 Table 70)
	 {{{2, 4}, {10,2}, {5, 4}},	// Code Rate Idx 0 RY 0->2, {Real, Imag}
	  {{7, 3}, {11,3}, {11,5}},	//				 1
	  {{5, 2}, {7, 4}, {8, 8}},	//				 2
	  {{3, 3}, {3, 5}, {9, 9}}},//				 3
	// 64QAM HMSym (Hierarchical on I and Q) (Ref: Section 7.5.1.2 Tables 68 and 69)
	 {{{2, 0}, {10,0}, {5, 0}},	// Code Rate Idx 0 RY 0->2, Reals, (Imag = 0, RY0 = VSPP)
	  {{7, 0}, {11,0}, {11,0}},	//				 1
	  {{5, 0}, {7, 0}, {8, 0}},	//				 2
	  {{3, 0}, {3, 0}, {9, 0}}},//				 3
	// 16QAM SM (Ref: Section 7.5.1.1 Table 65)
	 {{{3, 0}, {3, 0}, {0, 0}},	// Code Rate Idx 0 RY 0->1, Reals, (Imag = 0, RY2 = 0)
	  {{2, 0}, {4, 0}, {0, 0}},	//				 1
	  {{0, 0}, {0, 0}, {0, 0}},	//(Code Rate Idx 2 = 0)
	  {{0, 0}, {0, 0}, {0, 0}}}};//(Code Rate Idx 3 = 0)

// Code rate denominators' least common multiple
int RYlcm[4][4] = // [64QAM SM=0, HMMix(HonI)=1, HMSym(HonIQ)=2, 16QAM SM=3][Code Rate Idx=0->3]
	// 64QAM SM (Ref: Section 7.5.1.1 Table 67)
	{{4,						// Code Rate Idx 0 (LCM is of Reals only)
	  15,						//				 1
	  8,						//				 2
	  45},						//				 3
	// 64QAM HMMix (Hierarchical on I) (Ref: Section 7.5.1.2 Table 69 and Section 7.5.1.3 Table 70)
	 {20,						// Code Rate Idx 0 (LCM is of RY1,2, Reals only)
	  165,						//				 1
	  56,						//				 2
	  45},						//				 3
	// 64QAM HMSym (Hierarchical on I and Q) (Ref: Section 7.5.1.2 Tables 68 and 69)
	 {10,						// Code Rate Idx 0 (LCM is of RY0Imag, RY1,2)
	  11,						//				 1
	  56,						//				 2
	  9},						//				 3
	// 16QAM SM (Ref: Section 7.5.1.1 Table 65)
	 {3,						// Code Rate Idx 0 (LCM is of Code Rate Idx 0,1 RY0,1 Reals only)
	  4,						//				 1
	  0,						//(Code Rate Idx 2 = 0)
	  0}};						//(Code Rate Idx 3 = 0)

// SM: Standard Mapping
// HMMix: mixed Hierarchical Mapping
// HMSym: symmetrical Hierarchical Mapping

// MSC_mode: 64QAM SM=0, HMMix(HonI)=1, HMSym(HonIQ)=2, 16QAM SM=3
// spectrum_occupancy: 4.5 kHz=0, 5 kHz=1, 9 kHz=2, 10 kHz=3, 18 kHz=4, 20 kHz=5

bool parameter_ok(int p, int p_low, int p_high)  {
	return ((p >= p_low) && (p <= p_high));
}

bool parameters_ok(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC,
	int Code_Rate_Part_1, int Code_Rate_Part_2, int Code_Rate_Hier)  {
	return
		parameter_ok(robustness_mode,0,3)          &&
		parameter_ok(spectrum_occupancy,0,5)       &&
		parameter_ok(MSC_mode,0,3)                 &&
		parameter_ok(Part_A_bytes_from_SDC,0,5000) &&
		parameter_ok(Code_Rate_Part_1,0,3)         &&
		parameter_ok(Code_Rate_Part_2,0,3)         &&
		parameter_ok(Code_Rate_Hier,0,3)           &&
		(MSC_mode == 3)?(parameter_ok(Code_Rate_Part_1,0,1) && parameter_ok(Code_Rate_Part_2,0,1)):1 ;
}

int find_p_max(int MSC_mode)  {
	return (MSC_mode == 3) ? 2 : 3;			// 2 bits per cell per axis for 16 QAM, else 3 bits
}

int cells(int robustness_mode, int spectrum_occupancy)  {
	if( parameters_ok(robustness_mode, spectrum_occupancy, 0, 0, 0, 0, 0) == false )
		return -1;
	return Nmux[robustness_mode][spectrum_occupancy];
}

int find_L1(int MSC_mode,int Code_Rate_Part_1, int N1)  {
	int L1 = 0;
	int p_max = find_p_max(MSC_mode);
	int p;

	switch(MSC_mode) // (Ref: Section 7.2.1.1)
	{
		case 0:	// SM 64QAM
		case 3:	// or SM 16QAM
			for(p = 0; p <= p_max-1; p++) // sigma summation
				L1 += (int)(2 * N1 * ((float)RX[MSC_mode][Code_Rate_Part_1][p][0]) /
											 RY[MSC_mode][Code_Rate_Part_1][p][0]);
			break;
		case 1: // HMMix
			for(p = 1; p <= 2; p++) // sigma summation
				L1 += (int)(N1 * (((float)RX[MSC_mode][Code_Rate_Part_1][p][0]) /
										  RY[MSC_mode][Code_Rate_Part_1][p][0] +
								  ((float)RX[MSC_mode][Code_Rate_Part_1][p][1]) /
										  RY[MSC_mode][Code_Rate_Part_1][p][1]));
				L1 += (int)(N1 * ((float)RX[MSC_mode][Code_Rate_Part_1][0][1]) /
										 RY[MSC_mode][Code_Rate_Part_1][0][1]);
			break;
		case 2: // HMSym
			for(p = 1; p <= 2; p++) // sigma summation
				L1 += (int)(2 * N1 * ((float)RX[MSC_mode][Code_Rate_Part_1][p][0]) /
											 RY[MSC_mode][Code_Rate_Part_1][p][0]);
			break;
	}
	return L1;
}

int part_A_cells(int MSC_mode, int Part_A_bytes_from_SDC, int Code_Rate_Part_1)  {
	int N1 = -1;	// for case of invalid MSC_mode
	int p_max = find_p_max(MSC_mode);
	int rate_sum = 0;    // RX0/RY0 + RX1/RY1 + if exists RX2/RY2
	int p = 0;

	switch(MSC_mode)  {		// (to find N1,N2 = cells in Parts A,B, Ref: Section 7.2.1.1)
		case 0:	// SM 64QAM
		case 3:	// or SM 16QAM
			for(p = 0; p <= p_max-1; p++) // sigma summation
				rate_sum += (2 * RYlcm[MSC_mode][Code_Rate_Part_1] * RX[MSC_mode][Code_Rate_Part_1][p][0]) /
																	 RY[MSC_mode][Code_Rate_Part_1][p][0];
			N1 = (int)ceil(8.0*Part_A_bytes_from_SDC / rate_sum) *
				RYlcm[MSC_mode][Code_Rate_Part_1];
			break;
		case 1: // HMMix
			for(p = 1; p <= 2; p++) // sigma summation
				rate_sum += (RYlcm[MSC_mode][Code_Rate_Part_1] * RX[MSC_mode][Code_Rate_Part_1][p][0]) /
																 RY[MSC_mode][Code_Rate_Part_1][p][0]
						 +  (RYlcm[MSC_mode][Code_Rate_Part_1] * RX[MSC_mode][Code_Rate_Part_1][p][1]) /
																 RY[MSC_mode][Code_Rate_Part_1][p][1];
			// Add R0, Imaginary, code rate
			rate_sum += (RYlcm[MSC_mode][Code_Rate_Part_1] * RX[MSC_mode][Code_Rate_Part_1][0][1]) /
															 RY[MSC_mode][Code_Rate_Part_1][0][1];
			N1 = (int)ceil(8.0*Part_A_bytes_from_SDC / rate_sum) * RYlcm[MSC_mode][Code_Rate_Part_1];
			break;
		case 2: // HMSym
			for(p = 1; p <= 2; p++) // sigma summation
				rate_sum += (2 * RYlcm[MSC_mode][Code_Rate_Part_1] * RX[MSC_mode][Code_Rate_Part_1][p][0]) /
																	 RY[MSC_mode][Code_Rate_Part_1][p][0];
			N1 = (int)ceil(8.0*Part_A_bytes_from_SDC / rate_sum) * RYlcm[MSC_mode][Code_Rate_Part_1];
			break;
	}
	return N1;
}

int part_A_bits(int robustness_mode, int spectrum_occupancy, int MSC_mode,
	int Part_A_bytes_from_SDC, int Code_Rate_Part_1)  {

	if( parameters_ok(robustness_mode, spectrum_occupancy, MSC_mode,
		Part_A_bytes_from_SDC, Code_Rate_Part_1, 0, 0) == false )
			return -1;
	int N1 = part_A_cells(MSC_mode, Part_A_bytes_from_SDC,Code_Rate_Part_1);
	int L1 = find_L1(MSC_mode, Code_Rate_Part_1, N1);				// part A input bits

	return L1;
}

float part_A_bytes(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC,
	int Code_Rate_Part_1)  {
	int A_bits = part_A_bits(robustness_mode, spectrum_occupancy, MSC_mode, Part_A_bytes_from_SDC,
		Code_Rate_Part_1);
	return (A_bits == -1) ? -1 : A_bits/8.0;
}

// Part_A_bytes_from_SDC parameter represents number of bytes requested,
// return value represents number of bytes assigned (permitted).
int int_part_A_bytes(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC,
	int Code_Rate_Part_1)  {
	return (int)part_A_bytes(robustness_mode, spectrum_occupancy, MSC_mode, Part_A_bytes_from_SDC,
		Code_Rate_Part_1);
}

int find_L2(int MSC_mode,int Code_Rate_Part_2, int N2) {
	int L2 = 0;
	int p_max = find_p_max(MSC_mode);
	int p;

	switch(MSC_mode)  { // (Ref: Section 7.2.1.1)
		case 0:	// SM 64QAM
		case 3:	// or SM 16QAM
			for(p = 0; p <= p_max-1; p++) // sigma summation
				L2 += (int)(RX[MSC_mode][Code_Rate_Part_2][p][0] *
					floor((2*N2 - 12) / RY[MSC_mode][Code_Rate_Part_2][p][0]));
			break;
		case 1: // HMMix
			for(p = 1; p <= 2; p++) // sigma summation
				L2 += (int)(RX[MSC_mode][Code_Rate_Part_2][p][0] *
					floor((N2 - 12) / RY[MSC_mode][Code_Rate_Part_2][p][0]) +
							RX[MSC_mode][Code_Rate_Part_2][p][1] *
					floor((N2 - 12) / RY[MSC_mode][Code_Rate_Part_2][p][1]));
			L2 += (int)(RX[MSC_mode][Code_Rate_Part_2][0][1] *
				floor((N2 - 12) / RY[MSC_mode][Code_Rate_Part_2][0][1]));
			break;
		case 2: // HMSym
			for(p = 1; p <= 2; p++) // sigma summation
				L2 += (int)(RX[MSC_mode][Code_Rate_Part_2][p][0] *
					floor((2*N2 - 12) / RY[MSC_mode][Code_Rate_Part_2][p][0]));
			break;
	}
	return L2;
}

int part_B_cells3(int robustness_mode,int spectrum_occupancy,int N1)  {		// 3 args version
	return Nmux[robustness_mode][spectrum_occupancy] - N1;
}

int part_B_cells(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC,
	int Code_Rate_Part_1)  {
	if( parameters_ok(robustness_mode, spectrum_occupancy, MSC_mode,
		Part_A_bytes_from_SDC, Code_Rate_Part_1, 0, 0) == false )
			return -1;
	int N1 = part_A_cells(MSC_mode, Part_A_bytes_from_SDC,Code_Rate_Part_1);
	int N2 = part_B_cells3(robustness_mode, spectrum_occupancy, N1);
	return N2;
}

int part_B_bits(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC,
	int Code_Rate_Part_1, int Code_Rate_Part_2)  {

	if( parameters_ok(robustness_mode, spectrum_occupancy, MSC_mode,
		Part_A_bytes_from_SDC, Code_Rate_Part_1, Code_Rate_Part_2, 0 ) == false )
			return -1;

	int N2 = part_B_cells(robustness_mode, spectrum_occupancy, MSC_mode, Part_A_bytes_from_SDC,
		Code_Rate_Part_1);
	int L2 = find_L2(MSC_mode, Code_Rate_Part_2, N2);				// part B input bits
	return L2;
}

float part_B_bytes(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC,
	int Code_Rate_Part_1, int Code_Rate_Part_2)  {
	int B_bits = part_B_bits(robustness_mode, spectrum_occupancy, MSC_mode, Part_A_bytes_from_SDC,
		Code_Rate_Part_1, Code_Rate_Part_2);
	return (B_bits == -1) ? -1 : B_bits/8.0;
}

int int_part_B_bytes(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC,
	int Code_Rate_Part_1, int Code_Rate_Part_2)  {
	return (int)part_B_bytes(robustness_mode, spectrum_occupancy, MSC_mode, Part_A_bytes_from_SDC,
		Code_Rate_Part_1, Code_Rate_Part_2);
}

int find_LVSPP(int MSC_mode,int Code_Rate_Hier,int N1, int N2)  {
	int LVSPP = -1;		// for case of invalid MSC_mode

	switch(MSC_mode)  {		// (Ref: Section 7.2.1.1)
		case 0:	// SM 64QAM
		case 3:	// or SM 16QAM
			LVSPP = 0;
			break;
		case 1: // HMMix
			LVSPP = (int)(RX[MSC_mode][Code_Rate_Hier][0][0] *
				floor((N1+N2 - 12) / RY[MSC_mode][Code_Rate_Hier][0][0]));
			break;
		case 2: // HMSym
			LVSPP = (int)(RX[MSC_mode][Code_Rate_Hier][0][0] *
				floor((2*(N1+N2) - 12) / RY[MSC_mode][Code_Rate_Hier][0][0]));
			break;
	}
	return LVSPP;
}

int VSPP_bits(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC,
	int Code_Rate_Part_1, int Code_Rate_Hier)  {
	if( parameters_ok(robustness_mode, spectrum_occupancy, MSC_mode,
		Part_A_bytes_from_SDC, Code_Rate_Part_1, 0, Code_Rate_Hier) == false )
			return -1;

	int N1 = part_A_cells(MSC_mode, Part_A_bytes_from_SDC,Code_Rate_Part_1);
	int N2 = part_B_cells3(robustness_mode, spectrum_occupancy, N1);
	int LVSPP = find_LVSPP(MSC_mode, Code_Rate_Hier, N1, N2);		// VSPP   input bits
	return LVSPP;
}

float VSPP_bytes(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC,
	int Code_Rate_Part_1, int Code_Rate_Hier)  {
	int Hier_bits = VSPP_bits(robustness_mode, spectrum_occupancy, MSC_mode, Part_A_bytes_from_SDC,
		Code_Rate_Part_1, Code_Rate_Hier);
	return (Hier_bits == -1) ? -1 : Hier_bits / 8.0;
}

int int_VSPP_bytes(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC,
	int Code_Rate_Part_1, int Code_Rate_Hier)  {
	return (int)VSPP_bytes(robustness_mode, spectrum_occupancy, MSC_mode, Part_A_bytes_from_SDC,
		Code_Rate_Part_1, Code_Rate_Hier);
}

int length_bits(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC,
	int Code_Rate_Part_1, int Code_Rate_Part_2, int Code_Rate_Hier)  {

	if( parameters_ok(robustness_mode, spectrum_occupancy, MSC_mode,
		Part_A_bytes_from_SDC, Code_Rate_Part_1, Code_Rate_Part_2, Code_Rate_Hier) == false )
			return -1;

	int N1 = part_A_cells(MSC_mode, Part_A_bytes_from_SDC, Code_Rate_Part_1);
	int N2 = part_B_cells3(robustness_mode, spectrum_occupancy, N1);
	int L1 = find_L1(MSC_mode, Code_Rate_Part_1, N1);				// part A input bits
	int L2 = find_L2(MSC_mode, Code_Rate_Part_2, N2);				// part B input bits
	int LVSPP = find_LVSPP(MSC_mode, Code_Rate_Hier, N1, N2);		// VSPP   input bits
	int Lmux = L1 + L2 + LVSPP;										// total MSC input bits
	return Lmux;
}

float length_bytes(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC,
	int Code_Rate_Part_1, int Code_Rate_Part_2, int Code_Rate_Hier)  {
	int length = length_bits(robustness_mode, spectrum_occupancy, MSC_mode, Part_A_bytes_from_SDC,
		Code_Rate_Part_1, Code_Rate_Part_2, Code_Rate_Hier);
	return (length == -1) ? -1 : length/8.0;
}

int int_length_bytes(int robustness_mode, int spectrum_occupancy, int MSC_mode, int Part_A_bytes_from_SDC,
	int Code_Rate_Part_1, int Code_Rate_Part_2, int Code_Rate_Hier)  {
	return (int)length_bytes(robustness_mode, spectrum_occupancy, MSC_mode, Part_A_bytes_from_SDC,
		Code_Rate_Part_1, Code_Rate_Part_2, Code_Rate_Hier);
}
