/***************************************************************************
                          DRMSizeTables.h  -  description
                             -------------------
    begin                : Mon Apr 29 2002
    copyright            : (C) 2002 by WRMF, Inc.
    email                : bmoore@hcjbeng.org
 ***************************************************************************/

#ifndef DRMSIZETABLES_H
#define DRMSIZETABLES_H

extern int BytesOfSDCData[4][2][6];  // From 6.4.2 Table 65
// BytesOfSDCData[Robustness][SDC_QAM][Spectrum_Occupancy]

extern int BitsInSDCBlock[4][2][6];  // From Annex J, Tables J.22 to J.25
// This is the available space in the constellation.
// The remainder bits are zeroes, placed after the CRC16.
// BitsInSDCBlock[Robustness][SDC_QAM][Spectrum_Occupancy]

extern int BitsInMSC[5][4][2][4][6]; // From Annex J, Tables J.1 to J.4 and J.6 to J.21
// BitsInMSC[EEP][Robustness][MSC_QAM][ProtectionLevel][SpectrumOccupancy]

#endif
