#include <stdio.h>
#include "cs_length.h"

int main(void) {
	// initial values like Button5.ini
	int robustness_mode = 1, spectrum_occupancy = 3, MSC_mode = 0;
	int Code_Rate_Part_1 = 0, Code_Rate_Part_2 = 1, Code_Rate_Hier = 0;
	int Part_A_bytes_from_SDC = 0, part_A = 0, part_B = 0, length = 0;

	for(Part_A_bytes_from_SDC = 0; Part_A_bytes_from_SDC <= 200; Part_A_bytes_from_SDC +=10) {
		part_A = int_part_A_bytes(robustness_mode, spectrum_occupancy, MSC_mode, Part_A_bytes_from_SDC, Code_Rate_Part_1);
		part_B = int_part_B_bytes(robustness_mode, spectrum_occupancy, MSC_mode, Part_A_bytes_from_SDC, Code_Rate_Part_1, Code_Rate_Part_2);
		length = int_length_bytes(robustness_mode, spectrum_occupancy, MSC_mode, Part_A_bytes_from_SDC, Code_Rate_Part_1, Code_Rate_Part_2, Code_Rate_Hier);
		printf("request: %4d   part A: %4d   part B: %4d   total: %4d\n", Part_A_bytes_from_SDC, part_A, part_B, length);
	}
	return 0;
}
