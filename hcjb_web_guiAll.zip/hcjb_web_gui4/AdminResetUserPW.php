<?php //This function allows an admin to update a user's password
//Start session
	session_start();

	//Determination variables
	$user = 0;//0=empty UserName field, 1=fields don't match database, 2=correct
	

	include('config.php');
	
	$dbhandle = mysql_connect($hostname, $username, $password)
			or die("Unable to connect to MySQL");
			
	mysql_select_db($databaseName,$dbhandle);
	$username=$_POST['username'];
	$password=$_POST['password'];
	$passwordHash=hash('whirlpool', $password);
	$type=$_POST['userType'];
	
	
	$pass=mysql_query("UPDATE UserInfo SET PasswordHashed='$passwordHash', UserType='$type' WHERE Username='$username'");
	$row=mysql_query("SELECT * FROM UserInfo WHERE Username='$username'");
	
	
	mysql_close($dbhandle);
	
?>	

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>HCJB DRM Web GUI</title>
		<link href="bootstrap/css/bootstrap.css" rel="stylesheet">
	</head>
	<body>
	<script src="js/validatorAdminResetUser.js"></script>
		<div class="navbar">
			<div class="navbar-inner">
				<a class="brand" href="#">HCJB DRM Web GUI <sub>Version 0.5</sub></a>
				<ul class="nav">
					<li>
						<a href="adminCreate.php">Create User</a>
					</li>
					<li class="active">
						<a href="AdminResetUserPW.php">Change User PW</a>
					</li>
					<li>
						<a href="AdminUpdateCredentials.php">Change Own Password</a>
					</li>
				</ul>
			</div>
		</div>
	<form class="form-horizontal" name="resetPassword" onsubmit="return validator()" action="AdminResetUserPW.php" method="post">
	<fieldset>
				<legend>Update User Info</legend>
				<div class="control-group" id="usernameGroup">
				<?php
	if ($user == 1) {
		echo "\t\t\t\t".'<div class="control-group error">'.PHP_EOL;
	}

	else {
		echo "\t\t\t\t".'<div class="control-group">'.PHP_EOL;
	}
?>
					<label class="control-label" for="password">User ID:</label>
					<div class="controls">
						<input type="text" class="input-xlarge" id="username" name="username">
						<span class="help-inline" id="usernameHelp"></span>
					</div>
<?php
					if ($user == 1) {
						echo "\t\t\t\t\t\t\t".'<span class="help-inline">Invalid Username</span>'.PHP_EOL;
	}
?>
				</div>
				<div class="control-group" id="passwordGroup">
					<label class="control-label" for="password">New Password</label>
					<div class="controls">
						<input type="password" class="input-xlarge" id="password" name="password">
						<span class="help-inline" id="passwordHelp"></span>
					</div>
				</div>
				<div class="control-group" id="passwordConfirmGroup">
					<label class="control-label" for="passwordConfirm">Confirm Password</label>
					<div class="controls">
						<input type="password" class="input-xlarge" id="passwordConfirm" name="passwordConfirm">
						<span class="help-inline" id="passwordConfirmHelp"></span>
					</div>
				</div>
				<div class="control-group" id="userTypeGroup">
					<label class="control-label" for="userType">User Type</label>
					<div class="controls">
						<select id="userType" name="userType">
							<option>Basic</option>
							<option>Admin</option>
						</select>
					</div>
				</div>
	</fieldset>
	<div class="form-actions">
					<button value="submit" type="submit" class="btn btn-primary">Submit</button>
					<button class="btn" value="Reload Page" onClick="document.location.reload(true)">Cancel</button>
				</div>	