<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>HCJB DRM Web GUI</title>
		
		<link href="bootstrap/css/bootstrap.css" rel="stylesheet">
		<script src="http://code.jquery.com/jquery-latest.js"></script>
		<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
		<script src="js/validatorAdminCreate.js"></script>
		<script src="js/validatorAdminCredentials.js"></script>
		<script src="js/validatorAdminResetUser.js"></script>
		<link rel="stylesheet" href="CSS/file.css" type="text/css"/>
		<link rel="stylesheet" href="CSS/customWells.css" type="text/css"/>
		<link href="FortAwesome/css/font-awesome.css" rel="stylesheet" type="text/css">
		<script src="js/validatorForgotPW.js"></script>	
	</head>
	<body>
	<div class="row-fluid">
		<div class="span12 well-white">
			<h1 class=" pull-left" style="color: #049cdb;" > <i class="icon-music"></i> eRadioConfig </h1>
			
			<div class=" pull-right" style="margin-bottom:0px; padding-bottom:0px">
					<a href="file.php" class="btn btn-primary"><i class="icon-home"></i> Back to File Page</a>
			</div>

		</div>
	</div>
		<div class="container-fluid">	
		<div class="row-fluid">
			<div class="span11.5 offset.5 well-white">
	<form class="form-horizontal" name="ForgotPassword" onsubmit="return validatorID()" action="retrievePW1.php" method="post">
	<fieldset>
				<legend>Forgot Password</legend>
				<div class="control-group" id="usernameGroup">
					<label class="control-label" for="user">Username:</label>
					<div class="controls">
						<input type="text" class="input-xlarge" id="username" name="username">
						<span class="help-inline" id="usernameHelp"></span>
					</div>
				</div>
				
	</fieldset>
	<div class="form-actions">
					<button value="submit" type="submit" class="btn btn-primary">Submit</button>
					<button class="btn" value="Reload Page" type="reset">Clear</button>
				</div>		
		</div>
			</div>
			</div>
	</body>
</html>