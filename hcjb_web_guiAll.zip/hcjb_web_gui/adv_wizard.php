
<!DOCTYPE html>		
<html>
	<head>
		<title> Content Server</title>
		 
		<link rel="stylesheet" href="CSS/wizard.css" type="text/css"/>
		<link rel="stylesheet" href="CSS/customWells.css" type="text/css"/>
		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
		<link href="FortAwesome/css/font-awesome.css" rel="stylesheet" type="text/css">
		<link href="JQuery-UI/jquery-ui-bootstrap-gh-pages/css/custom-theme/jquery-ui-1.10.0.custom.css" rel="stylesheet" type="text/css">
		<script src="http://code.jquery.com/jquery-latest.js"></script>
		<script type="text/javascript" src="JQuery-UI/jquery-ui-bootstrap-gh-pages/assets/js/jquery-ui-1.10.0.custom.min.js"></script>
		<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="wizard.js"></script>
		<script type="text/javascript" src="wizardLogic.js"></script>
		
		<!-- loads tooltips for page-->
		<script type="text/javascript">
			 $(document).ready(function () {
				$("[rel=tooltip]").tooltip();
			  });
		</script>

		
	</head>
	<body>
<?php
	$_SESSION['ViewType']="Adv";
	echo $_SESSION['ViewType'];
?>		
	
	
		<div class="row-fluid">
			<div class="span12 well-white">
				<h1 style="color: #049cdb;" > <i class="icon-music"></i> eRadioConfig !adv!</h1>
				
			</div>
		</div>
			
		<div class="container-fluid">	
			<div class="row-fluid">
				<div class="span8 well-white" >
						
						<ul class="nav nav-tabs" id="myTab0">
						  <li class="active"><a href="#tab1xx" onclick="change(101)">Transmission</a></li>
<?php					
					if($_SESSION['ViewType']=="Basic"){
					  echo" <li ><a href=\"#tab2xx\" onclick=\"change(201)\">Service Combinations</a></li>";
					}  
?>					  
					  <li ><a href="#tab3xx" onclick="change(300)">Services</a></li>
					</ul>
					 
					<div class="tab-content">
		 
						<div class="tab-pane active " id="tab1xx">
							<div class="span11 "> 
								<div class="tabbable tabs-left"> <!-- Only required for left/right tabs -->
								  <ul class="nav nav-tabs" id="myTab1">
									<li class="active"><a href="#tab101" onclick="change(101)" ><i class="icon-edit"></i> File Description </a></li>
									<li><a href="#tab102" onclick="change(102)" ><i class="icon-globe"></i> Location </a></li>
									<li><a href="#tab103" onclick="change(103)"><i class="icon-bar-chart"></i> Spectrum Occupency</a></li>
									<li><a href="#tab104" onclick="change(104)"><i class="icon-signal"></i> Robustness </a></li>
									<li><a href="#tab105" onclick="change(105)"><i class="icon-exchange"></i> Interleaver Depth</a></li>
									<li><a href="#tab106" onclick="change(106)"><i class="icon-spinner"></i> MSC</a></li>
<?php

							if($_SESSION['ViewType']=="Adv"){
							
								echo"		<li><a href=\"#tab107\" onclick=\"change(107)\"><i class=\"icon-quote-left\"></i> SDC</a></li>
											<li><a href=\"#tab108\" onclick=\"change(108)\"><i class=\"icon-resize-horizontal\"></i>Data Length</a></li>
								";
							}
?>									
									
								  </ul>
								  <div class="tab-content">
									<div class="tab-pane active" id="tab101">
										<div class="span6 well">
											<dl>
											  <dt>Configuration Description</dt>
											  <dd>255 Character limit, that describes this file.</dd>
											</dl>
										</div>
										<div class="span5 offset1" >
											<div class="page-header">
											<h5>Description:</h5>
											</div>
												<textarea rows="5"></textarea>
											<br>
										</div>
									</div>
									
									<div class="tab-pane" id="tab102">
										<div class="span6 well">
											<dl>
											  <dt>Location</dt>
											  <dd>Continent being broadcast from</dd>
											</dl>
										</div>
										<div class="span5 offset1" >
											<div class="page-header">
											<h5>Options:</h5>
											</div>
											
												<label class="radio">
												  <input type="radio" name="Loc" id="optionsRadios1" value="0" onclick="logic(this.name, this.value)">
												  America's
												</label>
												<label class="radio">
												  <input type="radio" name="Loc" id="optionsRadios2" value="1" onclick="logic(this.name, this.value)">
												  Europe
												</label>
												<label class="radio">
												  <input type="radio" name="Loc" id="optionsRadios3" value="2" onclick="logic(this.name, this.value)">
												  Other
												</label>
											
											<br>
										</div>
									</div>
									
									
									<div class="tab-pane" id="tab103">
									  <div class="span6 well">
											<dl>
											  <dt>Spectrum Occupency</dt>
											  <dd>The hertz the transmission is operating on, most basic option. Set to 4.5, 9, 18 kHz for Europe and 5,10,20 for US Higher means better quality. 18,20 not used by FHG receivers. 9,10 is typical.</dd>
											</dl>
										</div>
										<div class="span5 offset1" >
											<div class="page-header">
											<h5>Options:</h5>
											</div>
												<label class="radio">
												  <input type="radio" name="SO" id="optionsRadios45" value="0" onclick="logic(this.name, this.value)">
													4.5 kHz
												</label>
												<label class="radio">
												  <input type="radio" name="SO" id="optionsRadios5" value="1" onclick="logic(this.name, this.value)">
													5 kHz
												</label>
												<label class="radio">
												  <input type="radio" name="SO" id="optionsRadios9" value="2" onclick="logic(this.name, this.value)">
													9 kHz
												</label>
												<label class="radio">
												  <input type="radio" name="SO" id="optionsRadios10" value="3" onclick="logic(this.name, this.value)">
													10 kHz
												</label>
												<label class="radio">
												 <input type="radio" name="SO" id="optionsRadios18" value="4" onclick="logic(this.name, this.value)">
													18 kHz
												</label>
												<label class="radio">
												  <input type="radio" name="SO" id="optionsRadios45" value="5" onclick="logic(this.name, this.value)">
													20 kHz
												</label>
											<br>
										</div>
									</div>
									
									<div class="tab-pane" id="tab104">
										<div class="span6 well">
											<dl>
											  <dt>Robustness </dt>
											  <dd>Protects against loss of data along transmission. Higher value means more stability but lesser quality.</dd>
											</dl>
										</div>
										<div class="span5 offset1" >
											<div class="page-header">
											<h5>Options:</h5>
											</div>
											<label class="radio" rel="tooltip" data-placement="left" title="guard interval local medium wave">
											 <input type="radio" name="Robust" id="optionsRobust1" value="0" onclick="logic(this.name, this.value)">
												A 5%
											</label>
											<label class="radio" rel="tooltip" data-placement="left" title="guard interval general sky wave">
											 <input type="radio" name="Robust" id="optionsRobust2" value="1" onclick="logic(this.name, this.value)">
											 B 20 %
											</label>
											<label class="radio" rel="tooltip" data-placement="left" title="guard interval severe multipath">
											 <input type="radio" name="Robust" id="optionsRobust3" value="2" onclick="logic(this.name, this.value)">
											C 27%
											</label>
											<label class="radio" rel="tooltip" data-placement="left" title="guard interval severe multipath & Doppler">
											 <input type="radio" name="Robust" id="optionsRobust4" value="3" onclick="logic(this.name, this.value)">
											D 44%
											</label>
											<br>
										</div>
									</div>
									
									
									
									<div class="tab-pane" id="tab105">
										<div class="span6 well">
											<dl>
											  <dt>Interleaver Depth</dt>
											  <dd>Amount of time audio frame is spread between (.4 or 2 sec)
												(Long interleave increases decoding delay but increases signals robustness)</dd>
											</dl>
										</div>
										<div class="span5 offset1" >
											<div class="page-header">
											<h5>Options:</h5>
											</div>
											<label class="radio">
												 <input type="radio" name="Interleaver" id="optionsID1" value="0" onclick="logic(this.name, this.value)">
												2.0 sec
												</label>
											<label class="radio">
												 <input type="radio" name="Interleaver" id="optionsID2" value="1" onclick="logic(this.name, this.value)">
												0.4 sec
												</label>
											<br>
										</div>
									</div>
									
									<div class="tab-pane" id="tab106">
										<div class="span6 well">
											<dl>
											  <dt>MSC</dt>
											  <dd> Adds redundancy to transmission. </dd>
											</dl>
										</div>
										<div class="span5 offset1" >
											<div class="page-header">
											<h5>Options:</h5>
											</div>
											<label class="radio" rel="tooltip" data-placement="left" title="non-hierarchical ">
											 <input type="radio" name="MSC" id="optionsMSC1" value="0" onclick="logic(this.name, this.value)">
											64 QAM SM
											</label>
											
											</label>

											<label class="radio" rel="tooltip" data-placement="left" title="non-hierarchical">
											 <input type="radio" name="MSC" id="optionsMSC4" value="3" onclick="logic(this.name, this.value)">
											16 QAM SM
											</label>
											<br>
										</div>
									</div>

<?php		

				if($_SESSION['ViewType']=="Adv"){
				
					echo"			<div class=\"tab-pane\" id=\"tab107\">
										<div class=\"span6 well\">
											<dl>
											  <dt>SDC</dt>
											  <dd> Service Description Channel. </dd>
											</dl>
										</div>
										<div class=\"span5 offset1\" >
											<div class=\"page-header\">
											<h5>Options:</h5>
											</div>
											<label class=\"radio\" rel=\"tooltip\" >
											 <input type=\"radio\" name=\"SDC\" id=\"optionsSDC0\" value=\"0\" onclick=\"logic(this.name, this.value)\">
											16 QAM
											</label>
											
											</label>

											<label class=\"radio\" rel=\"tooltip\">
											 <input type=\"radio\" name=\"SDC\" id=\"optionsSDC1\" value=\"1\" onclick=\"logic(this.name, this.value)\">
											4 QAM
											</label>
											<br>
										</div>
									</div>
									
									<div class=\"tab-pane\" id=\"tab108\">
										<div class=\"span6 well\">
											<dl>
											  <dt>Data Length</dt>
											  <dd> bandwidth distribution among streams. </dd>
											</dl>
										</div>
										<div class=\"span5 offset1\" >
											<div class=\"page-header\">
											<h5>Streams:</h5>
											</div>
											   
														<label>Stream 0:</label>
														<input class=\"span5\" type=\"text\" name=\"DataLengthB\" id=\"DatalengthS0\" placeholder=\"Percentage\" onclick=\"logic(this.name, this.value)\">
														<label>Stream 1:</label>
														<input class=\"span5\" type=\"text\" name=\"DataLengthB\" id=\"DatalengthS1\" placeholder=\"Percentage\" onclick=\"logic(this.name, this.value)\">
														<label>Stream 2:</label>
														<input class=\"span5\" type=\"text\" name=\"DataLengthB\" id=\"DatalengthS2\" placeholder=\"Percentage\" onclick=\"logic(this.name, this.value)\">
														<label>Stream 3:</label>
														<input class=\"span5\" type=\"text\" name=\"DataLengthB\" id=\"DatalengthS3\" placeholder=\"Percentage\" onclick=\"logic(this.name, this.value)\">
													
													
										</div>
									</div>
									
									
									
									
									";
				}					
?>									

									
									
								  </div>
								</div>	
							</div>		
						 </div>
						 
						

						<div class="tab-pane" id="tab3xx">
						  <div class="span12"> 
							<div class="page-header">
								<h5 class="span4">Select Number of Services :</h5>
							
								<select class="span3 inline" id="servicesSelect" onchange="servicesToDisplay()">
									<option value=""></option>
									<option value="1"> 1 </option>
									<option value="2"> 2 </option>
									<option value="3"> 3 </option>
									<option value="4"> 4 </option>
							
							
								</select>
								
							</div>
							
							<div class="page-header" id="stream0" style="display: none;">
								<h4> Stream 0: </h4>
								<br>
								<div class="tabbable tabs-left">
								  <ul class="nav nav-tabs">
									<li class="active"><a  href="#tab301" data-toggle="tab" ><i class="icon-tags"></i> Service Identification </a></li>
									<li><a href="#tab302" data-toggle="tab" ><i class="icon-screenshot"></i> Protection Levels </a></li>
									<li><a href="#tab303" data-toggle="tab" ><i class="icon-group"></i> Language & Service Type </a></li>
									<li><a href="#tab304" data-toggle="tab" ><i class="icon-play-circle"></i> Audio Settings </a></li>
									<!--<li><a href="#tab205" data-toggle="tab" ><i class="icon-check"></i> CA System Used </a></li>-->
									<!--<li><a href="#tab206" data-toggle="tab" ><i class="icon-tasks"></i> Media Type </a></li>-->									
									<li><a href="#tab307" data-toggle="tab" ><i class="icon-flag"></i> Flags </a></li>								
									
								  </ul>
								  </ul>
								  
								  <div class="tab-content">
										<div class="tab-pane active" id="tab301">
											<form class="form">
												<div class="control-group page-header">
													<label class="control-label" for="S0ServiceLabel"><b>Service Label</b></label>
													<div class="controls">
													  <input type="text" placeholder="Service Label" id="S0ServiceLabel">
													  <span class="help-block">Name displayed for the service.</span>
													</div>
												 </div>
												 
												<div class="control-group">
													<label class="control-label" for="S0ServiceID"><b>Service Identifier</b></label>
													<div class="controls">
													  <input type="text" placeholder="Service Identifier" id="S0ServiceID"> 
													  <span class="help-block">Unique ID, which is a whole number.</span>
													</div>
												 </div> 
											</form>	 
										</div>
										
										<div class="tab-pane" id="tab302">
											<form class="form-inline">

												<input type="text" placeholder="Stream 0 Part A"> 
												<input type="text" placeholder="Stream 0 Part B"> 
												<span class="help-block">SDFSDGF</span>
													
											</form>	 
										</div>
										
										<div class="tab-pane" id="tab303">
											<div class="page-header">
												<b> Service Descriptor </b>
												<br>
												<select>

												  <option>0 None Selected</option>
												  <option>1 No Program Type</option>
												  <option>2 News</option>
												  <option>3 Current Affairs</option>
												  <option>4 Information</option>
												  <option>5 Sport</option>
												  <option>6 Education</option>
												  <option>7 Drama</option>
												  <option>8 Culture</option>
												  <option>9 Science</option>
												  <option>10 Varied</option>
												  <option>11 Pop Music</option>
												  <option>12 Rock Music</option>
												  <option>13 Easy Listening</option>
												  <option>14 Light Classical</option>
												  <option>15 Serious Classical</option>
												  <option>16 Other music</option>
												  <option>17 Weather</option>
												  <option>18 Finance</option>
												  <option>19 Childrens</option>
												  <option>20 Social Affairs</option>
												  <option>21 Religion</option>
												  <option>22 Phone in</option>
												  <option>23 Travel</option>
												  <option>24 Leisure</option>
												  <option>25 Jazz Music</option>
												  <option>26 Country Music</option>
												  <option>27 National Music</option>
												  <option>28 Oldies Music</option>
												  <option>29 Folk Music</option>
												  <option>30 Documentery</option>
												  
								
												</select>
											</div>
											<br>
											<b> Language </b>
											<br>
											<select>
											  <option>0 None Selected</option>
											  <option>1 None Sepecified</option>
											  <option>2 Arabic</option>
											  <option>3 Bengali</option>
											  <option>4 Chinese (Mand.)</option>
											  <option>5 Dutch</option>
											  <option>6 English</option>
											  <option>7 French</option>
											  <option>8 German</option>
											  <option>9 Hindi</option>
											  <option>10 Japanese</option>
											  <option>11 Javanese</option>
											  <option>12 Korean</option>
											  <option>13 Portugese</option>
											  <option>14 Russian</option>
											  <option>15 Spanish</option>
											  <option>16 Other music</option>
											</select> 
										</div>
										
										<div class="tab-pane row-fluid" id="tab304">
											<div class="page-header">
												
												<b> Audio Mode </b>
												<br>
												<label class="radio inline">
													<input type="radio" name="S0AudioMode" id="S0optionAudM1" value="option1">
													Mono
												</label>
												<label class="radio inline">
													<input type="radio" name="S0AudioMode" id="S0optionAudM2" value="option2">
													Parem Stereo
												</label>
												<label class="radio inline">
													<input type="radio" name="S0AudioMode" id="S0optionAudM3" value="option3">
													Stereo
												</label>
											</div>
											<div class="page-header">
												<b> Audio Sampling </b>
												<br>
												<label class="radio inline">
													<input type="radio" name="S0AudioSampling" id="S0optionAudS1" value="option1">
													8 kHz
												</label>
												<label class="radio inline">
													<input type="radio" name="S0AudioSampling" id="S0optionAudS2" value="option2">
													12 kHz
												</label>
												<label class="radio inline">
													<input type="radio" name="S0AudioSampling" id="S0optionAudS3" value="option3">
													16 kHz
												</label>
												<label class="radio inline">
													<input type="radio" name="S0AudioSampling" id="S0optionAudS4" value="option1">
													24 kHz
												</label>
											</div>
											<div class="">
												 <b> Auido Coding </b>
												 <br>
													<label class="radio inline">
														<input type="radio" name="S0AudioCoding" id="S0optionAC1" value="option1">
														MPEG ACC
													</label>
													<label class="radio inline">
														<input type="radio" name="S0AudioCoding" id="S0optionAC2" value="option2">
														CELP
													</label>
													<label class="radio inline">
														<input type="radio" name="S0AudioCoding" id="S0optionAC3" value="option3">
														HVXC
													</label>
											</div>
										</div>
										
										<div class="tab-pane row-fluid" id="tab305">
											<b> CA System Used </b>
											<br>
											<label class="radio inline">
												<input type="radio" name="S0CAUsed" id="S0optionCA1" value="option1">
												Yes
											</label>
											<label class="radio inline">
												<input type="radio" name="S0CAUsed" id="S0optionCA2" value="option2">
												No
											</label>
										</div>
										
										<div class="tab-pane row-fluid" id="tab306">
											<b> Audio/Data </b>
											<br>
											<label class="radio inline">
												<input type="radio" name="S0AudioData" id="S0optionAD1" value="option1">
												Audio
											</label>
											<label class="radio inline">
												<input type="radio" name="S0AudioData" id="S0optionAD2" value="option2">
												Data
											</label>
											<label class="radio inline">
												<input type="radio" name="S0AudioData" id="S0optionAD3" value="option3">
												None
											</label>
										</div>
										
										<div class="tab-pane row-fluid" id="tab307">
											<!--<div class="page-header">
												<b> Enhancement Flag </b>
												<br>
												<label class="radio inline">
													<input type="radio" name="S0EFlag" id="S0optionEF1" value="option1">
													Yes
												</label>
												<label class="radio inline">
													<input type="radio" name="S0EFlag" id="S0optionEF2" value="option2">
													No
												</label>
											</div>-->
											<b> SBR Flag </b>
											<br>
											<label class="radio inline">
												<input type="radio" name="S0SBR" id="S0optionSBR1" value="option1">
												Yes
											</label>
											<label class="radio inline">
												<input type="radio" name="S0SBR" id="S0optionSBR2" value="option2">
												No
											</label>
										</div>
									
								  </div>
								</div>
								
								
								
								
								
								
							
								
								
							
							</div>
							<div class="page-header" id="stream1" style="display: none;">
								<h4> Stream 1: </h4>
								
								
								
								
								
																
							
								
								
							
							</div>	
						  </div>
						</div>
						 
						<!-- This helps control what tab is shown first. For greater detail checkout first link.-->
						<!--<script>
						  $(function () {
							$('#myTab li:eq(0) a').tab('show');
						  })
						</script>-->
					
						
						
				</div>
				
				<div>
						<ul class="pager" id="Page1">
						  <li class="previous disabled" id="previousBtn">
							<a href="#" onclick="change()">&larr; Previous</a>
						  </li>
						  <li class="next" id="nextBtn">
							<a href="#" onclick="change(102)">Next &rarr;</a>
						  </li>
						</ul>	
						
						
						  
						
						
						
						<div class="progress">
						  <div class="bar" id="ProgressBar" style="width: 0%;"></div>
						</div>
				</div>
			</div>

				
				
			<div class="span4 ">
					<div class="span12 well-white">
						<div class="page-header">
						  <h1><small>Whats filling up the bandwidth?</small></h1>
						</div>
						<!--Div holds hold the pie chart-->
						<div id="chart_div" style="padding: 0;"></div>
					</div>
					<br> <br>
					<div class="span11 well-white">
					
					</div>
					
				
					 
			</div>	
		</div>	
	</div>	
 


	
</body>
</html>
