<html>
<head>
<script>
function func(rowID, BugID){

	xmlhttp= new XMLHttpRequest();
	xmlhttp.open("POST", "delete.php", false);
	xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");	
	xmlhttp.send("BugID="+BugID);
	
	if(xmlhttp.responseText=="1"){
		var rowIndex = document.getElementById(rowID).rowIndex;
		document.getElementById("table").deleteRow(rowIndex);
	}
}
</script>
</head>
<body>

<?php
	include('../../config.php');
	
	//Connect to the database
	$dbhandle = mysql_connect($hostname, $username, $password);
	
	if(!$dbhandle){
		echo "Could not connect to database";
	}

	
	//Select the database
	$selected = mysql_select_db($databaseName,$dbhandle);
	
	if(!$selected){
		echo "Could not select database.";
	}

	$result = mysql_query("SELECT `Subject`, `Description`,`Username`, BugID FROM `Bugs`,`UserInfo` WHERE `UserInfo`.UserID = `Bugs`.UserID");
	
	if($result == false){
			echo "No bugs to display.";
	}	
	else{	
	
		echo "<table border=\"1\" id=\"table\">";
			echo "<tr>";
			echo "<td>Subject</td>";
			echo "<td>Description</td>";
			echo "<td>Username</td>";
			echo "<td width=\"50\"></td>";
			echo "</tr>";		
		
			$row = mysql_fetch_array($result);		
			$i = 0;
			while($row != FALSE){
				echo "<tr id='x$i'>";
				echo "<td>".$row["Subject"]."</td>";
				echo "<td>".$row["Description"]."</td>";
				echo "<td>".$row["Username"]."</td>";
				echo "<td><button onclick=\"func('x$i',".$row["BugID"].")\">Delete</button></td>";
				echo "</tr>";
				$i++;
				
				$row = mysql_fetch_array($result);	
			}
		
		echo "</table>";
	}
?>

</body>
</html>
