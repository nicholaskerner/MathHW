<?php
	function fail(){
		//send back failure
		echo "0";
	}
	function success(){
		//send back success
		echo "1";
	}

	include('../../config.php');
	
	//Connect to the database
	$dbhandle = mysql_connect($hostname, $username, $password);
	
	if(!$dbhandle){
		fail();
	}
	
	//Select the database
	$selected = mysql_select_db($databaseName,$dbhandle);
	
	if(!$selected){
		fail();
	}

	$result = mysql_query("DELETE FROM `Bugs` WHERE BugID = ".$_POST["BugID"]);
	
	if($result == false){
		fail();
	}	
	else{
		success();
	}
?>