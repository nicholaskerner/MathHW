<?php
	//Connect to the database
	require('../config.php');
	$database = new PDO('mysql:host='.$hostname.';dbname='.$databaseName, $username, $password);

	$fileQuery = $database->query("SELECT `IsRealFile`, `FileName` FROM `AutoSave` WHERE FileID = '".$_GET["id"]."' LIMIT 1");
	$row = $fileQuery->fetch(PDO::FETCH_ASSOC);

	$real = $row{'IsRealFile'};
	$name = $row{'FileName'};

	//Close the database connection
	$datebase = null;

	if ($real) {
		shell_exec("cp ".$iniDir.$name." /home/drm/config/DRM.ini");
		return true;
	}

	else {
		return false;
	}
?>
