<?php
	//Start session
	session_start();

	//Check session status
	if (isset($_SESSION['Login'])) {
		header("Location: file.php");
		exit;
	}

	//Login attempt determination variable
	$login = false;

	//Check for post
	if (isset($_POST["username"]) || isset($_POST["password"])) {
		$login = true;

		//Check for blank username or password
		if ($_POST["username"] != "" || $_POST["password"] != "") {
			//Hash password
			$hashed = hash('whirlpool', $_POST["password"]);

			//Connect to database
			require('config.php');
			$database = new PDO('mysql:host='.$hostname.';dbname='.$databaseName, $username, $password);

			$loginQuery = $database->query("SELECT `PasswordHashed`,`UserType`,`UserID`,`ViewType` FROM `UserInfo` WHERE `Username` = '".$_POST["username"]."'");

			$row = $loginQuery->fetch(PDO::FETCH_ASSOC);

			//Check for correct password
			if ($hashed == $row{'PasswordHashed'}) {

				//Initialize the session and redirect
				$_SESSION['Login'] = true;
				$_SESSION['UserType'] = $row{'UserType'};
				$_SESSION['UserID'] = $row{'UserID'};
				$_SESSION['ViewType'] = $row{'ViewType'};

				//Close the database connection
				$database = null;

				//Redirect to file.php
				header("Location: file.php");
				exit;
			}

			else {
				//Close the database connection
				$database = null;
			}
		}
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Content Server</title>
		<link rel="stylesheet" href="CSS/Login.css" type="text/css"/>
		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
		<link href="FortAwesome/css/font-awesome.css" rel="stylesheet" type="text/css">
		<script src="bootstrap/js/jquery.min.js"></script>
		<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="lib/Bug/submitBugs.js"></script>
	</head>
	<body>
		<div id="formbox">
			<h1 class="clearfix" style="color: #049cdb;"><i class="icon-music"></i> eRadioConfig</h1>
			<form class="form-horizontal" action="index.php" method="POST">

<?php
	if ($login) {
		echo "\t\t\t\t".'<div class="alert alert-error">'.PHP_EOL;
		echo "\t\t\t\t\t".'<button type="button" class="close" data-dismiss="alert">&times;</button>'.PHP_EOL;
		echo "\t\t\t\t\t".'<strong>Invalid Login</strong> You have entered an invalid username or password'.PHP_EOL;
		echo "\t\t\t\t".'</div>'.PHP_EOL;
	}
?>

				<div class="control-group">
					<label class="control-label" for="inputUsername">Username</label>
					<div class="controls">
						<input type="text" id="username" name="username" placeholder="Username">
					</div>
				</div>
				<div class="control-group">
					<label class="control-label" for="inputPassword">Password</label>
					<div class="controls">
						<input type="password" id="password" name="password" placeholder="Password">
					</div>
				</div>
				<div class="control-group">
					<div class="controls">
						<button type="submit" class="btn btn-primary"><i class="icon-user icon-white"></i>Sign in</button>
					<!--<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal" onclick="$('#myModal').modal(show);"> -->
						<button type="button" class="btn btn-primary" onClick="window.location='ForgotPW.php' ">
							<i class="icon-question-sign icon-white"></i>
							Forgot Password
						</button>
					</div>
				</div>
			</form>
		</div>
		<div class="modal hide fade in" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="control-group">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
					<h3 id="myModalLabel">Fogot Password</h3>
				</div>
				<div class="modal-body">
					<form class="form-horizontal">
						<p>Please enter username and email associated with your account.</p>
						<div class="control-group">
							<label class="control-label" for="inputUserName">Username</label>
							<div class="controls">
								<input type="text" id="inputUserName" placeholder="Username">
							</div>
						</div>
						<div class="control-group">
							<label class="control-label" for="inputEmail">Email</label>
							<div class="controls">
								<input type="text" id="inputEmail" placeholder="Email">
							</div>
						</div>
						<div class="modal-footer">
							<div class="control-group">
								<div class="controls">
									<button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
									<button class="btn btn-primary" data-toggle="modal" data-target="#myModal1, #myModal" onclick="$('#myModal1').modal(show); $('#myModal').modal(hide); ">Submit</button>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<!-- For test reporting only-->	
	<div class="navbar navbar-fixed-bottom">
  <div class="navbar-inner">
    <a class="brand" href="#bugModal" class="btn" data-toggle="modal">Report Bug</a>
  </div>
  
</div>
	<div id="bugModal" class="modal hide fade in" style="display: none;"> 
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
			<h3>Report A Bug</h3>
		</div>
		<div class="modal-body">
			<Label> Subject:</label>
			<input type="text" id="BugSubject" placeholder="Subject">
			<Label> Description:</label>
			<textarea id="BugDesc" rows="3"></textarea>
		</div>
		<div class="modal-footer">
			<a class="btn" data-dismiss="modal">Cancel</a>
			<input type="button" value="Submit" onclick="submitBug();" class ="btn btn-info">
		</div>
	</div>
	</body>
</html>
