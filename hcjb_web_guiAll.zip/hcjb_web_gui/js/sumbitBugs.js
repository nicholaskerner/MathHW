function logOut(){
	var pageName = location.pathname;
	$.post( pageName, { "signout": true} );
	window.location.reload();

$.getJSON("wizardPHP/AJAXCalls.php", {"ToDo": "liveAudio"},
		function(data){
		var tempList = new Array();
		
		for(var i=0; i<data.LiveAudioInputs.length; i++){
			tempList[i] = data.LiveAudioInputs[i].inputName;
		
		}	
			setLiveAudio(tempList);	
			checkAndLoadServices();
		}); 

}		