<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>HCJB DRM Web GUI</title>
		<link href="bootstrap/css/bootstrap.css" rel="stylesheet">
		<script src="http://code.jquery.com/jquery-latest.js"></script>
		<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
		<script src="js/validatorAdminCreate.js"></script>
		<script src="js/validatorAdminCredentials.js"></script>
		<script src="js/validatorAdminResetUser.js"></script>
		<link rel="stylesheet" href="CSS/file.css" type="text/css"/>
		<link rel="stylesheet" href="CSS/customWells.css" type="text/css"/>
		<link href="FortAwesome/css/font-awesome.css" rel="stylesheet" type="text/css">
		<script src="js/validatorForgotPW.js"></script>	
	</head>
	<body>
	<div class="row-fluid">
		<div class="span12 well-white">
			<h1 class=" pull-left" style="color: #049cdb;" > <i class="icon-music"></i> eRadioConfig </h1>
			
			<div class=" pull-right" style="margin-bottom:0px; padding-bottom:0px">
					<a href="file.php" class="btn btn-primary"><i class="icon-home"></i> Back to File Page</a>
			</div>

		</div>
	</div>
	<form class="form-horizontal" name="SecretQA" onsubmit="return validator()" action="CheckAnswer.php" method="post">
	<fieldset>
	Answer your secret question:
	<?php
	include('config.php');
	session_start();
	if($_SESSION['ErrorRPW1']==2)
	{	echo "<br> Your answer was incorrect <br>";
	}
	
	$dbhandle = mysql_connect($hostname, $username, $password)
			or die("Unable to connect to MySQL");
			
	mysql_select_db($databaseName,$dbhandle);
	
	$myid=$_SESSION['UserID'];
	//echo $myid;
	
	$result= mysql_query("SELECT * FROM UserInfo WHERE UserID='$myid'");
	$row = mysql_fetch_array($result);
	$Question=$row['SecretQuestion'];

	echo"
	<div class=\"control-group\" id=\"secretQuestionGroup\">
					<label class=\"control-label\" for=\"answer\">Question</label>
					<div class=\"controls\">
						<input type=\"text\" class=\"input-xlarge\" id=\"answer\" name=\"answer\" readonly placeholder=\"$Question\">?
						<span class=\"help-inline\" id=\"AnswerHelp\"></span>
					</div>
				</div>
	";
	?>	
	<div class="control-group" id="secretQuestionGroup">
					<label class="control-label" for="answer">Answer</label>
					<div class="controls">
						<input type="text" class="input-xlarge" id="answer" name="answer">
						<span class="help-inline" id="AnswerHelp"></span>
					</div>
				</div>
	</fieldset>
	<div class="form-actions">
					<button value="submit" type="submit" class="btn btn-primary">Submit</button>
					<button class="btn" value="Reload Page" type="reset">Clear</button>
				</div>		
				
				
				
				
				